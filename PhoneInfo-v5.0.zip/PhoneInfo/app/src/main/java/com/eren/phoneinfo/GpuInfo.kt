package com.eren.phoneinfo

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20

object GpuInfo {
    /** (renderer, vendor, version) - EGL pbuffer ile ekran dışı bağlam açar. */
    fun query(): Triple<String, String, String>? {
        var display = EGL14.EGL_NO_DISPLAY
        var ctx = EGL14.EGL_NO_CONTEXT
        var surf = EGL14.EGL_NO_SURFACE
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val ver = IntArray(2)
            if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) return null
            val cfgAttr = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            EGL14.eglChooseConfig(display, cfgAttr, 0, cfgs, 0, 1, n, 0)
            if (n[0] == 0) return null
            val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            ctx = EGL14.eglCreateContext(display, cfgs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
            val sAttr = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
            surf = EGL14.eglCreatePbufferSurface(display, cfgs[0], sAttr, 0)
            if (!EGL14.eglMakeCurrent(display, surf, surf, ctx)) return null
            val renderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: "?"
            val vendor = GLES20.glGetString(GLES20.GL_VENDOR) ?: "?"
            val version = GLES20.glGetString(GLES20.GL_VERSION) ?: "?"
            return Triple(renderer, vendor, version)
        } catch (e: Throwable) {
            return null
        } finally {
            try {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, ctx)
            } catch (e: Throwable) {
            }
        }
    }
}
