package com.eren.phoneinfo

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** Dil: TR / EN. İlk açılışta seçilir, SharedPreferences'ta saklanır. */
object L {
    var tr: Boolean = true
    fun t(trText: String, enText: String): String = if (tr) trText else enText
}

object Palette {
    var dark: Boolean = true
    val bg: Int get() = if (dark) 0xFF0E1117.toInt() else 0xFFF1F4F9.toInt()
    val card: Int get() = if (dark) 0xFF171C26.toInt() else 0xFFFFFFFF.toInt()
    val card2: Int get() = if (dark) 0xFF1F2633.toInt() else 0xFFE8EDF5.toInt()
    val stroke: Int get() = if (dark) 0xFF2A3342.toInt() else 0xFFD5DCE8.toInt()
    val text: Int get() = if (dark) 0xFFE8ECF3.toInt() else 0xFF14181F.toInt()
    val sub: Int get() = if (dark) 0xFF8D98AA.toInt() else 0xFF5C6676.toInt()
    val accent: Int get() = if (dark) 0xFF4FC3F7.toInt() else 0xFF0277BD.toInt()
    val good: Int get() = if (dark) 0xFF66BB6A.toInt() else 0xFF2E7D32.toInt()
    val warn: Int get() = if (dark) 0xFFFFB74D.toInt() else 0xFFE65100.toInt()
    val danger: Int get() = if (dark) 0xFFEF5350.toInt() else 0xFFC62828.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundBg(ctx: Context, color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.RECTANGLE
    d.setColor(color)
    d.cornerRadius = ctx.dp(radiusDp).toFloat()
    if (strokeColor != null) d.setStroke(ctx.dp(1), strokeColor)
    return d
}

fun makeTv(ctx: Context, text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(ctx)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun makeButton(ctx: Context, text: String, onClick: () -> Unit): TextView {
    val b = makeTv(ctx, text, 14f, Palette.accent, true)
    b.gravity = Gravity.CENTER
    b.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
    b.background = roundBg(ctx, Palette.card2, 12, Palette.stroke)
    b.setOnClickListener { onClick() }
    return b
}

fun fmtBytes(b: Long): String {
    if (b < 0) return "—"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024.0 && i < units.size - 1) {
        v /= 1024.0
        i++
    }
    return if (i == 0) "${b} B" else String.format(Locale.US, "%.1f %s", v, units[i])
}

fun fmtTemp(c: Float?): String =
    if (c == null) "—" else String.format(Locale.US, "%.1f °C", c)

fun tempColor(c: Float?): Int = when {
    c == null -> Palette.sub
    c < 40f -> Palette.good
    c < 50f -> Palette.warn
    else -> Palette.danger
}

/** Başlıklı kart + etiket/değer satırları. */
class Card(private val ctx: Context, title: String, icon: String) {
    val root: LinearLayout = LinearLayout(ctx)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = roundBg(ctx, Palette.card, 16, Palette.stroke)
        root.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        val head = makeTv(ctx, "$icon  $title", 16f, Palette.accent, true)
        head.setPadding(0, 0, 0, ctx.dp(6))
        root.addView(head)
    }

    fun row(label: String, value: String = "—"): TextView {
        val line = LinearLayout(ctx)
        line.orientation = LinearLayout.HORIZONTAL
        line.setPadding(0, ctx.dp(5), 0, ctx.dp(5))
        val l = makeTv(ctx, label, 13f, Palette.sub)
        val v = makeTv(ctx, value, 13f, Palette.text, true)
        v.gravity = Gravity.END
        line.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.9f))
        line.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f))
        root.addView(line)
        return v
    }

    fun note(text: String): TextView {
        val n = makeTv(ctx, text, 12f, Palette.sub)
        n.setPadding(0, ctx.dp(6), 0, 0)
        root.addView(n)
        return n
    }

    fun add(v: View) {
        root.addView(v)
    }
}
