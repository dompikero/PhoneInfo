package com.eren.phoneinfo

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class InfoScreen(private val act: MainActivity) {

    private class BatteryData(
        val level: Int,
        val tempC: Float?,
        val voltageMv: Int,
        val status: String,
        val plugged: String,
        val health: String,
        val tech: String,
        val currentMa: Int?
    )

    private val ctx: Context = act
    val view: ScrollView = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var running = false
    private var gpuQueried = false

    private lateinit var tCpuTemp: TextView
    private lateinit var tGpuTemp: TextView
    private lateinit var tBatTemp: TextView
    private lateinit var tSkinTemp: TextView
    private lateinit var tStatus: TextView
    private lateinit var tHeadroom: TextView
    private lateinit var tSources: TextView
    private lateinit var tHint: TextView
    private lateinit var allSensorsBox: LinearLayout
    private var allSensorsVisible = false

    private lateinit var tBatLevel: TextView
    private lateinit var tBatStatus: TextView
    private lateinit var tBatVolt: TextView
    private lateinit var tBatCur: TextView
    private lateinit var tBatHealth: TextView
    private lateinit var tBatTech: TextView

    private lateinit var tRam: TextView
    private lateinit var tRamAvail: TextView
    private lateinit var tFreqs: TextView
    private lateinit var tGpuName: TextView
    private lateinit var tGpuVendor: TextView
    private lateinit var tGpuVer: TextView

    init {
        view.isFillViewport = false
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(16))
        view.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        build()
    }

    private fun addCard(c: Card) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, ctx.dp(12))
        col.addView(c.root, lp)
    }

    private fun build() {
        buildTempCard()
        buildDeviceCard()
        buildCpuCard()
        buildGpuCard()
        buildBatteryCard()
        buildMemoryCard()
        buildDisplayCard()
        buildSensorsCard()
    }

    // ---------------------------------------------------------------- Sıcaklık
    private fun buildTempCard() {
        val c = Card(ctx, L.t("Sıcaklıklar (canlı)", "Temperatures (live)"), "🌡")
        tCpuTemp = c.row("CPU")
        tGpuTemp = c.row("GPU")
        tBatTemp = c.row(L.t("Pil", "Battery"))
        tSkinTemp = c.row(L.t("Yüzey / Skin", "Skin"))
        tStatus = c.row(L.t("Android termal durumu", "Android thermal status"))
        tHeadroom = c.row(L.t("Termal yük (1.0 = kısıtlama)", "Thermal headroom (1.0 = throttle)"))
        tSources = c.row(L.t("Kaynak", "Source"))
        tHint = c.note("")
        tHint.visibility = View.GONE

        val btnRow = LinearLayout(ctx)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.setPadding(0, ctx.dp(10), 0, 0)
        val b1 = makeButton(ctx, L.t("CPU/GPU açılmıyor mu?", "CPU/GPU not showing?")) { showGuide() }
        val b2 = makeButton(ctx, L.t("Tüm sensörler", "All sensors")) {
            allSensorsVisible = !allSensorsVisible
            allSensorsBox.visibility = if (allSensorsVisible) View.VISIBLE else View.GONE
        }
        val lp1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp1.setMargins(0, 0, ctx.dp(6), 0)
        val lp2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp2.setMargins(ctx.dp(6), 0, 0, 0)
        btnRow.addView(b1, lp1)
        btnRow.addView(b2, lp2)
        c.add(btnRow)

        allSensorsBox = LinearLayout(ctx)
        allSensorsBox.orientation = LinearLayout.VERTICAL
        allSensorsBox.visibility = View.GONE
        allSensorsBox.setPadding(0, ctx.dp(8), 0, 0)
        c.add(allSensorsBox)
        addCard(c)
    }

    private fun showGuide() {
        val cmd = "adb shell pm grant com.eren.phoneinfo android.permission.DUMP"
        val msg = L.t(
            "Android 10 ve üstünde uygulamalar CPU/GPU sıcaklık dosyalarını (SELinux nedeniyle) okuyamıyor. " +
                "Bu kısıtlamayı uygulamanın içinden aşmak mümkün değil; ancak 3 yol var:\n\n" +
                "1) Bilgisayardan BİR KEZ şu komutu çalıştır (kalıcıdır):\n$cmd\n" +
                "Sonra uygulama sistem termal servisinden CPU/GPU değerlerini okur.\n\n" +
                "2) Cihaz rootluysa aşağıdan \"Root ile dene\"yi aç.\n\n" +
                "3) Bazı cihazlarda hiçbir yol yoktur; o zaman pil sıcaklığı ve Android termal durumu gösterilir.",
            "On Android 10+ apps cannot read the CPU/GPU temperature files (SELinux). " +
                "This restriction cannot be bypassed from inside the app, but there are 3 ways:\n\n" +
                "1) Run this once from a computer (it is permanent):\n$cmd\n" +
                "The app then reads CPU/GPU values from the system thermal service.\n\n" +
                "2) If the device is rooted, turn on \"Try root\" below.\n\n" +
                "3) On some devices there is no way; battery temperature and Android thermal status are shown then."
        )
        val rootLabel = if (ThermalReader.rootEnabled)
            L.t("Root: AÇIK (kapat)", "Root: ON (turn off)")
        else
            L.t("Root ile dene", "Try root")
        AlertDialog.Builder(ctx)
            .setTitle(L.t("CPU / GPU sıcaklığı", "CPU / GPU temperature"))
            .setMessage(msg)
            .setPositiveButton(L.t("Komutu kopyala", "Copy command")) { _, _ ->
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("adb", cmd))
                Toast.makeText(ctx, L.t("Kopyalandı", "Copied"), Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(rootLabel) { _, _ ->
                ThermalReader.rootEnabled = !ThermalReader.rootEnabled
                act.saveRootPref(ThermalReader.rootEnabled)
            }
            .setNegativeButton(L.t("Kapat", "Close"), null)
            .show()
    }

    // ---------------------------------------------------------------- Cihaz
    private fun buildDeviceCard() {
        val c = Card(ctx, L.t("Cihaz", "Device"), "📱")
        c.row(L.t("Model", "Model")).text = Build.MODEL
        c.row(L.t("Üretici", "Manufacturer")).text = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        c.row(L.t("Marka", "Brand")).text = Build.BRAND
        c.row(L.t("Cihaz kodu", "Device code")).text = Build.DEVICE
        c.row("Android").text = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        c.row(L.t("Güvenlik yaması", "Security patch")).text =
            if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "—"
        c.row(L.t("Kart", "Board")).text = Build.BOARD
        c.row(L.t("Donanım", "Hardware")).text = Build.HARDWARE
        if (Build.VERSION.SDK_INT >= 31) {
            c.row("SoC").text = (Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL).trim()
        }
        c.row(L.t("Mimari (ABI)", "Architecture (ABI)")).text = Build.SUPPORTED_ABIS.joinToString(", ")
        c.row("Build").text = Build.DISPLAY
        c.row(L.t("Çekirdek", "Kernel")).text = System.getProperty("os.version") ?: "—"
        addCard(c)
    }

    // ---------------------------------------------------------------- CPU
    private fun cpuHardware(): String {
        try {
            File("/proc/cpuinfo").bufferedReader().useLines { lines ->
                for (l in lines) {
                    if (l.startsWith("Hardware")) return l.substringAfter(":").trim()
                }
            }
        } catch (e: Throwable) {
        }
        return Build.HARDWARE
    }

    private fun buildCpuCard() {
        val c = Card(ctx, "CPU", "🧠")
        c.row(L.t("İşlemci", "Processor")).text = cpuHardware()
        c.row(L.t("Çekirdek sayısı", "Cores")).text = Runtime.getRuntime().availableProcessors().toString()
        tFreqs = c.note("…")
        tFreqs.setTextColor(Palette.text)
        addCard(c)
    }

    private fun readFreqs(): String {
        val n = Runtime.getRuntime().availableProcessors()
        val sb = StringBuilder()
        for (i in 0 until n) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = try { File(base + "scaling_cur_freq").readText().trim().toLongOrNull() } catch (e: Throwable) { null }
            val max = try { File(base + "cpuinfo_max_freq").readText().trim().toLongOrNull() } catch (e: Throwable) { null }
            val curS = if (cur != null) "${cur / 1000} MHz" else "—"
            val maxS = if (max != null) " / max ${max / 1000} MHz" else ""
            sb.append("cpu").append(i).append(":  ").append(curS).append(maxS).append('\n')
        }
        return sb.toString().trimEnd()
    }

    // ---------------------------------------------------------------- GPU
    private fun buildGpuCard() {
        val c = Card(ctx, "GPU", "🎮")
        tGpuName = c.row(L.t("Model", "Renderer"))
        tGpuVendor = c.row(L.t("Üretici", "Vendor"))
        tGpuVer = c.row("OpenGL ES")
        addCard(c)
    }

    // ---------------------------------------------------------------- Pil
    private fun buildBatteryCard() {
        val c = Card(ctx, L.t("Pil", "Battery"), "🔋")
        tBatLevel = c.row(L.t("Seviye", "Level"))
        tBatStatus = c.row(L.t("Durum", "Status"))
        tBatVolt = c.row(L.t("Voltaj", "Voltage"))
        tBatCur = c.row(L.t("Anlık akım", "Current"))
        tBatHealth = c.row(L.t("Sağlık", "Health"))
        tBatTech = c.row(L.t("Teknoloji", "Technology"))
        addCard(c)
    }

    private fun readBattery(): BatteryData {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val tempC = if (t == Int.MIN_VALUE) null else t / 10f
        val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pl = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val hl = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
        val tech = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "—"

        val status = when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> L.t("Şarj oluyor", "Charging")
            BatteryManager.BATTERY_STATUS_DISCHARGING -> L.t("Boşalıyor", "Discharging")
            BatteryManager.BATTERY_STATUS_FULL -> L.t("Dolu", "Full")
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> L.t("Şarj olmuyor", "Not charging")
            else -> "—"
        }
        val plugged = when (pl) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> L.t("Kablosuz", "Wireless")
            else -> "—"
        }
        val health = when (hl) {
            BatteryManager.BATTERY_HEALTH_GOOD -> L.t("İyi", "Good")
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> L.t("Aşırı ısınma", "Overheat")
            BatteryManager.BATTERY_HEALTH_DEAD -> L.t("Ölü", "Dead")
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> L.t("Aşırı voltaj", "Over voltage")
            BatteryManager.BATTERY_HEALTH_COLD -> L.t("Soğuk", "Cold")
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> L.t("Arıza", "Failure")
            else -> "—"
        }
        var cur: Int? = null
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (v != Int.MIN_VALUE && v != 0) cur = v / 1000
        } catch (e: Throwable) {
        }
        return BatteryData(pct, tempC, volt, status, plugged, health, tech, cur)
    }

    // ---------------------------------------------------------------- Bellek
    private fun buildMemoryCard() {
        val c = Card(ctx, L.t("Bellek ve Depolama", "Memory & Storage"), "💾")
        tRam = c.row("RAM")
        tRamAvail = c.row(L.t("Kullanılabilir RAM", "Available RAM"))
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            c.row(L.t("Dahili depolama", "Internal storage")).text = fmtBytes(total)
            c.row(L.t("Boş alan", "Free space")).text = fmtBytes(free)
        } catch (e: Throwable) {
        }
        addCard(c)
    }

    // ---------------------------------------------------------------- Ekran
    private fun buildDisplayCard() {
        val c = Card(ctx, L.t("Ekran", "Display"), "🖥")
        val dm = ctx.resources.displayMetrics
        c.row(L.t("Çözünürlük", "Resolution")).text = "${dm.widthPixels} x ${dm.heightPixels}"
        c.row(L.t("Yoğunluk", "Density")).text = "${dm.densityDpi} dpi"
        try {
            @Suppress("DEPRECATION")
            val hz = act.windowManager.defaultDisplay.refreshRate
            c.row(L.t("Yenileme hızı", "Refresh rate")).text = String.format(Locale.US, "%.0f Hz", hz)
        } catch (e: Throwable) {
        }
        addCard(c)
    }

    // ---------------------------------------------------------------- Sensörler
    private fun buildSensorsCard() {
        val c = Card(ctx, L.t("Sensörler", "Sensors"), "📡")
        try {
            val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val list = sm.getSensorList(android.hardware.Sensor.TYPE_ALL)
            c.row(L.t("Toplam", "Total")).text = list.size.toString()
            val names = list.map { it.name }.distinct().sorted()
            val t = c.note(names.joinToString("\n"))
            t.setTextColor(Palette.sub)
        } catch (e: Throwable) {
        }
        addCard(c)
    }

    // ---------------------------------------------------------------- Canlı güncelleme
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refreshAsync()
            handler.postDelayed(this, 2000)
        }
    }

    fun start() {
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    private fun refreshAsync() {
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            try {
                val bat = readBattery()
                val th = ThermalReader.snapshot(ctx, bat.tempC)
                val freqs = readFreqs()
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                var gpu: Triple<String, String, String>? = null
                if (!gpuQueried) {
                    gpuQueried = true
                    gpu = GpuInfo.query()
                }
                handler.post { applyData(bat, th, freqs, mi, gpu) }
            } catch (e: Throwable) {
            } finally {
                busy.set(false)
            }
        }
    }

    private fun applyData(
        bat: BatteryData,
        th: ThermalSnapshot,
        freqs: String,
        mi: ActivityManager.MemoryInfo,
        gpu: Triple<String, String, String>?
    ) {
        val na = L.t("Erişilemiyor", "Not accessible")
        tCpuTemp.text = if (th.cpu != null) fmtTemp(th.cpu) else na
        tCpuTemp.setTextColor(tempColor(th.cpu))
        tGpuTemp.text = if (th.gpu != null) fmtTemp(th.gpu) else na
        tGpuTemp.setTextColor(tempColor(th.gpu))
        tBatTemp.text = fmtTemp(th.battery)
        tBatTemp.setTextColor(tempColor(th.battery))
        tSkinTemp.text = if (th.skin != null) fmtTemp(th.skin) else "—"
        tSkinTemp.setTextColor(tempColor(th.skin))
        tStatus.text = th.statusText ?: "—"
        tHeadroom.text = if (th.headroom != null) String.format(Locale.US, "%.2f", th.headroom) else "—"
        tSources.text = if (th.sources.isEmpty()) L.t("yok (yalnızca pil)", "none (battery only)") else th.sources.joinToString(", ")

        if (th.cpu == null || th.gpu == null) {
            tHint.visibility = View.VISIBLE
            tHint.text = L.t(
                "CPU/GPU sensörü bu cihazda uygulamaya kapalı. Pil sıcaklığı ve Android termal durumu gerçek değerlerdir; CPU/GPU için yukarıdaki butona bak.",
                "The CPU/GPU sensor is hidden from apps on this device. Battery temperature and Android thermal status are real values; see the button above for CPU/GPU."
            )
        } else {
            tHint.visibility = View.GONE
        }

        if (allSensorsVisible) {
            allSensorsBox.removeAllViews()
            if (th.readings.isEmpty()) {
                allSensorsBox.addView(makeTv(ctx, L.t("Okunabilir sensör yok.", "No readable sensors."), 12f, Palette.sub))
            }
            for (r in th.readings.sortedByDescending { it.celsius }) {
                val line = makeTv(ctx, String.format(Locale.US, "%-28s %5.1f °C", r.name.take(28), r.celsius), 12f, tempColor(r.celsius))
                line.typeface = android.graphics.Typeface.MONOSPACE
                allSensorsBox.addView(line)
            }
        }

        tBatLevel.text = if (bat.level >= 0) "${bat.level}%" else "—"
        tBatStatus.text = bat.status + if (bat.plugged != "—") " (${bat.plugged})" else ""
        tBatVolt.text = if (bat.voltageMv > 0) "${bat.voltageMv} mV" else "—"
        tBatCur.text = if (bat.currentMa != null) "${bat.currentMa} mA" else "—"
        tBatHealth.text = bat.health
        tBatTech.text = bat.tech

        tRam.text = fmtBytes(mi.totalMem)
        tRamAvail.text = fmtBytes(mi.availMem)
        tFreqs.text = freqs
        if (gpu != null) {
            tGpuName.text = gpu.first
            tGpuVendor.text = gpu.second
            tGpuVer.text = gpu.third
        } else if (tGpuName.text.isNullOrEmpty() || tGpuName.text == "—") {
            tGpuName.text = "—"
            tGpuVendor.text = "—"
            tGpuVer.text = "—"
        }
    }
}
