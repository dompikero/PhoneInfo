package com.eren.phoneinfo

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

/** Dosya yöneticisi: tüm dahili depolama + SD/USB + kök dizin. Bilgisayardaki gezgin gibi çalışır. */
class FilesScreen(private val act: MainActivity) {

    /** kind: 0 = başlık, 1 = normal satır */
    private class Entry(
        val kind: Int,
        val file: File?,
        val title: String,
        val subtitle: String,
        val icon: String,
        val isDir: Boolean
    )

    private val ctx: Context = act
    val view: LinearLayout = LinearLayout(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private val pathView: TextView
    private val body: FrameLayout
    private val list: ListView
    private val permPanel: LinearLayout
    private val pasteBtn: TextView

    private var current: File? = null
    private var entries: List<Entry> = emptyList()
    private var showHidden = false
    private var sortMode = 0 // 0 ad, 1 tarih, 2 boyut
    private var clip: List<File> = emptyList()
    private var clipCut = false

    private val internalRoot: File = Environment.getExternalStorageDirectory()

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = entries.size
        override fun getItem(position: Int): Any = entries[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun areAllItemsEnabled(): Boolean = false
        override fun isEnabled(position: Int): Boolean = entries[position].kind == 1
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? RowView) ?: RowView(ctx)
            v.bind(entries[position])
            return v
        }
    }

    private inner class RowView(c: Context) : LinearLayout(c) {
        private val icon = TextView(c)
        private val title = TextView(c)
        private val sub = TextView(c)

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(12), c.dp(8), c.dp(12), c.dp(8))
            icon.textSize = 24f
            icon.gravity = Gravity.CENTER
            addView(icon, LinearLayout.LayoutParams(c.dp(44), ViewGroup.LayoutParams.WRAP_CONTENT))
            val colBox = LinearLayout(c)
            colBox.orientation = LinearLayout.VERTICAL
            title.textSize = 15f
            title.setTextColor(Palette.text)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.MIDDLE
            sub.textSize = 12f
            sub.setTextColor(Palette.sub)
            sub.maxLines = 1
            sub.ellipsize = TextUtils.TruncateAt.END
            colBox.addView(title)
            colBox.addView(sub)
            addView(colBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        fun bind(e: Entry) {
            if (e.kind == 0) {
                icon.text = ""
                title.text = e.title
                title.setTextColor(Palette.accent)
                title.textSize = 13f
                sub.visibility = View.GONE
                setPadding(context.dp(16), context.dp(14), context.dp(12), context.dp(4))
            } else {
                icon.text = e.icon
                title.text = e.title
                title.setTextColor(Palette.text)
                title.textSize = 15f
                sub.text = e.subtitle
                sub.visibility = View.VISIBLE
                setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
            }
        }
    }

    init {
        view.orientation = LinearLayout.VERTICAL

        // Araç çubuğu
        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(ctx.dp(8), ctx.dp(4), ctx.dp(8), ctx.dp(4))
        fun tool(symbol: String, onClick: () -> Unit): TextView {
            val t = TextView(ctx)
            t.text = symbol
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
            t.setOnClickListener { onClick() }
            bar.addView(t)
            return t
        }
        tool("⬆") { if (!goUp()) Toast.makeText(ctx, L.t("Zaten en üstte", "Already at top"), Toast.LENGTH_SHORT).show() }
        tool("🏠") { current = null; refresh() }
        tool("➕") { newFolderDialog() }
        pasteBtn = tool("📋") { paste() }
        pasteBtn.visibility = View.GONE
        tool("⇅") { sortDialog() }
        tool("👁") {
            showHidden = !showHidden
            Toast.makeText(
                ctx,
                if (showHidden) L.t("Gizli dosyalar gösteriliyor", "Hidden files shown") else L.t("Gizli dosyalar gizli", "Hidden files hidden"),
                Toast.LENGTH_SHORT
            ).show()
            refresh()
        }
        view.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        pathView = TextView(ctx)
        pathView.textSize = 12f
        pathView.setTextColor(Palette.sub)
        pathView.maxLines = 1
        pathView.ellipsize = TextUtils.TruncateAt.START
        pathView.setPadding(ctx.dp(16), 0, ctx.dp(16), ctx.dp(6))
        view.addView(pathView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        body = FrameLayout(ctx)
        view.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        list = ListView(ctx)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(0x33888888)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onClick(entries[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val e = entries[pos]
            if (e.kind == 1 && e.file != null) itemMenu(e.file, e.isDir)
            true
        }

        permPanel = LinearLayout(ctx)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(ctx.dp(28), ctx.dp(28), ctx.dp(28), ctx.dp(28))
        val pIcon = makeTv(ctx, "🗂", 48f, Palette.text)
        pIcon.gravity = Gravity.CENTER
        val pText = makeTv(
            ctx,
            L.t(
                "Telefondaki tüm dosyalara bilgisayardaki gibi erişmek için \"Tüm dosyalara erişim\" izni gerekir.",
                "To browse every file on the phone like on a PC, the \"All files access\" permission is required."
            ),
            14f,
            Palette.text
        )
        pText.gravity = Gravity.CENTER
        pText.setPadding(0, ctx.dp(12), 0, ctx.dp(16))
        permPanel.addView(pIcon)
        permPanel.addView(pText)
        permPanel.addView(makeButton(ctx, L.t("İzin ver", "Grant access")) { requestAccess() })
    }

    // ------------------------------------------------------------ izin
    private fun hasAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            } catch (e: Exception) {
                act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                act,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                100
            )
        }
    }

    // ------------------------------------------------------------ listeleme
    fun refresh() {
        body.removeAllViews()
        if (!hasAccess()) {
            pathView.text = ""
            body.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return
        }
        body.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        pasteBtn.visibility = if (clip.isEmpty()) View.GONE else View.VISIBLE
        val cur = current
        if (cur == null) {
            pathView.text = L.t("Bu cihaz", "This device")
            entries = homeEntries()
        } else {
            pathView.text = cur.absolutePath
            entries = folderEntries(cur)
        }
        adapter.notifyDataSetChanged()
        list.setSelection(0)
    }

    private fun volEntry(title: String, f: File, icon: String): Entry {
        var sub = f.absolutePath
        try {
            val st = StatFs(f.absolutePath)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            sub = L.t("${fmtBytes(free)} boş / ${fmtBytes(total)}", "${fmtBytes(free)} free / ${fmtBytes(total)}")
        } catch (e: Throwable) {
        }
        return Entry(1, f, title, sub, icon, true)
    }

    private fun homeEntries(): List<Entry> {
        val out = ArrayList<Entry>()
        out.add(Entry(0, null, L.t("DEPOLAMA", "STORAGE"), "", "", false))
        out.add(volEntry(L.t("Dahili depolama", "Internal storage"), internalRoot, "📱"))
        try {
            for (d in ctx.getExternalFilesDirs(null)) {
                if (d == null) continue
                val p = d.absolutePath
                val i = p.indexOf("/Android/data")
                if (i > 0) {
                    val root = File(p.substring(0, i))
                    if (root.absolutePath != internalRoot.absolutePath) {
                        out.add(volEntry(L.t("SD kart / USB", "SD card / USB"), root, "💾"))
                    }
                }
            }
        } catch (e: Throwable) {
        }
        out.add(Entry(1, File("/"), L.t("Kök dizin (/)", "Root directory (/)"), "/", "🗂", true))

        out.add(Entry(0, null, L.t("KISAYOLLAR", "SHORTCUTS"), "", "", false))
        val shortcuts = listOf(
            Triple("Download", L.t("İndirilenler", "Downloads"), "⬇️"),
            Triple("DCIM", L.t("Kamera (DCIM)", "Camera (DCIM)"), "📷"),
            Triple("Pictures", L.t("Resimler", "Pictures"), "🖼"),
            Triple("Movies", L.t("Videolar", "Movies"), "🎬"),
            Triple("Music", L.t("Müzik", "Music"), "🎵"),
            Triple("Documents", L.t("Belgeler", "Documents"), "📄"),
            Triple("Android", "Android", "🤖")
        )
        for (s in shortcuts) {
            val f = File(internalRoot, s.first)
            if (f.exists()) out.add(Entry(1, f, s.second, f.absolutePath, s.third, true))
        }
        return out
    }

    private fun folderEntries(dir: File): List<Entry> {
        val files = dir.listFiles()
        if (files == null) {
            return listOf(
                Entry(
                    0, null,
                    L.t("Bu klasöre erişilemiyor (Android kısıtlaması veya izin yok).", "Cannot access this folder (Android restriction or no permission)."),
                    "", "", false
                )
            )
        }
        val filtered = files.filter { showHidden || !it.name.startsWith(".") }
        val comparator: Comparator<File> = when (sortMode) {
            1 -> compareByDescending<File> { it.lastModified() }
            2 -> compareByDescending<File> { if (it.isDirectory) -1L else it.length() }
            else -> compareBy<File, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
        }
        val dirs = filtered.filter { it.isDirectory }.sortedWith(comparator)
        val regular = filtered.filter { !it.isDirectory }.sortedWith(comparator)
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val out = ArrayList<Entry>()
        if (filtered.isEmpty()) {
            out.add(Entry(0, null, L.t("Klasör boş", "Folder is empty"), "", "", false))
        }
        for (d in dirs) out.add(Entry(1, d, d.name, df.format(Date(d.lastModified())), "📁", true))
        for (f in regular) {
            out.add(Entry(1, f, f.name, fmtBytes(f.length()) + "  •  " + df.format(Date(f.lastModified())), iconFor(f), false))
        }
        return out
    }

    private fun iconFor(f: File): String {
        return when (f.extension.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic" -> "🖼"
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> "🎬"
            "mp3", "wav", "flac", "m4a", "ogg", "aac" -> "🎵"
            "zip", "rar", "7z", "tar", "gz" -> "🗜"
            "apk", "xapk" -> "🤖"
            "pdf" -> "📕"
            "txt", "md", "log", "json", "xml", "csv" -> "📝"
            "doc", "docx", "odt" -> "📘"
            "xls", "xlsx", "ods" -> "📗"
            "ppt", "pptx" -> "📙"
            else -> "📄"
        }
    }

    // ------------------------------------------------------------ gezinme
    private fun onClick(e: Entry) {
        val f = e.file ?: return
        if (e.isDir) {
            current = f
            refresh()
        } else {
            openFile(f)
        }
    }

    /** Geri tuşu / yukarı: true dönerse tüketildi. */
    fun goUp(): Boolean {
        val cur = current ?: return false
        val p = cur.parentFile
        if (p == null || cur.absolutePath == internalRoot.absolutePath || !p.canRead()) {
            current = null
        } else {
            current = p
        }
        refresh()
        return true
    }

    private fun openFile(f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, f.name))
        } catch (e: Exception) {
            toast(L.t("Bu dosya açılamadı", "Cannot open this file"))
        }
    }

    private fun shareFile(f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val i = Intent(Intent.ACTION_SEND)
            i.type = mime
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, f.name))
        } catch (e: Exception) {
            toast(L.t("Paylaşılamadı", "Cannot share"))
        }
    }

    // ------------------------------------------------------------ menüler
    private fun itemMenu(f: File, isDir: Boolean) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (!isDir) {
            labels.add(L.t("Aç", "Open")); actions.add { openFile(f) }
            labels.add(L.t("Paylaş", "Share")); actions.add { shareFile(f) }
        }
        labels.add(L.t("Kopyala", "Copy")); actions.add { clip = listOf(f); clipCut = false; refresh(); toast(L.t("Kopyalandı - bir klasörde 📋'e dokun", "Copied - tap 📋 in a folder")) }
        labels.add(L.t("Kes", "Cut")); actions.add { clip = listOf(f); clipCut = true; refresh(); toast(L.t("Kesildi - bir klasörde 📋'e dokun", "Cut - tap 📋 in a folder")) }
        labels.add(L.t("Yeniden adlandır", "Rename")); actions.add { renameDialog(f) }
        labels.add(L.t("Sil", "Delete")); actions.add { deleteDialog(f) }
        labels.add(L.t("Bilgi", "Info")); actions.add { infoDialog(f) }
        labels.add(L.t("Yolu kopyala", "Copy path")); actions.add {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("path", f.absolutePath))
            toast(L.t("Yol kopyalandı", "Path copied"))
        }
        AlertDialog.Builder(ctx)
            .setTitle(f.name)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun sortDialog() {
        val items = arrayOf(L.t("Ada göre", "By name"), L.t("Tarihe göre (yeni)", "By date (newest)"), L.t("Boyuta göre (büyük)", "By size (largest)"))
        AlertDialog.Builder(ctx)
            .setTitle(L.t("Sırala", "Sort"))
            .setSingleChoiceItems(items, sortMode) { d, which ->
                sortMode = which
                d.dismiss()
                refresh()
            }
            .show()
    }

    private fun prompt(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(ctx)
        et.setText(initial)
        et.setSingleLine(true)
        et.setSelection(initial.length)
        val box = FrameLayout(ctx)
        box.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), 0)
        box.addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty() && !s.contains('/')) onOk(s)
            }
            .setNegativeButton(L.t("İptal", "Cancel"), null)
            .show()
    }

    private fun newFolderDialog() {
        val dir = current
        if (dir == null) {
            toast(L.t("Önce bir klasör aç", "Open a folder first"))
            return
        }
        prompt(L.t("Yeni klasör", "New folder"), "") { name ->
            val ok = File(dir, name).mkdirs()
            toast(if (ok) L.t("Oluşturuldu", "Created") else L.t("Oluşturulamadı", "Failed"))
            refresh()
        }
    }

    private fun renameDialog(f: File) {
        prompt(L.t("Yeniden adlandır", "Rename"), f.name) { name ->
            val ok = f.renameTo(File(f.parentFile, name))
            toast(if (ok) L.t("Adı değişti", "Renamed") else L.t("Başarısız", "Failed"))
            refresh()
        }
    }

    private fun deleteDialog(f: File) {
        AlertDialog.Builder(ctx)
            .setTitle(L.t("Silinsin mi?", "Delete?"))
            .setMessage(f.absolutePath)
            .setPositiveButton(L.t("Sil", "Delete")) { _, _ ->
                exec.execute {
                    val ok = try { f.deleteRecursively() } catch (e: Throwable) { false }
                    handler.post {
                        toast(if (ok) L.t("Silindi", "Deleted") else L.t("Silinemedi", "Could not delete"))
                        refresh()
                    }
                }
            }
            .setNegativeButton(L.t("İptal", "Cancel"), null)
            .show()
    }

    private fun infoDialog(f: File) {
        exec.execute {
            var size = 0L
            var count = 0
            try {
                if (f.isDirectory) {
                    for (x in f.walkTopDown()) {
                        if (x.isFile) {
                            size += x.length()
                            count++
                        }
                    }
                } else {
                    size = f.length()
                }
            } catch (e: Throwable) {
            }
            val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM)
            val msg = StringBuilder()
            msg.append(L.t("Yol: ", "Path: ")).append(f.absolutePath).append('\n')
            msg.append(L.t("Boyut: ", "Size: ")).append(fmtBytes(size)).append('\n')
            if (f.isDirectory) msg.append(L.t("Dosya sayısı: ", "Files: ")).append(count).append('\n')
            msg.append(L.t("Değiştirilme: ", "Modified: ")).append(df.format(Date(f.lastModified()))).append('\n')
            msg.append(L.t("Okunabilir: ", "Readable: ")).append(f.canRead()).append('\n')
            msg.append(L.t("Yazılabilir: ", "Writable: ")).append(f.canWrite())
            handler.post {
                AlertDialog.Builder(ctx)
                    .setTitle(f.name)
                    .setMessage(msg.toString())
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    // ------------------------------------------------------------ kopyala / taşı
    private fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (t.exists()) {
            t = File(dir, base + " (" + i + ")" + ext)
            i++
        }
        return t
    }

    private fun copyRecursive(src: File, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            val kids = src.listFiles() ?: return
            for (k in kids) copyRecursive(k, File(dst, k.name))
        } else {
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun paste() {
        val dir = current
        if (dir == null) {
            toast(L.t("Önce hedef klasörü aç", "Open the target folder first"))
            return
        }
        val items = clip
        val cut = clipCut
        if (items.isEmpty()) return
        toast(L.t("İşleniyor…", "Working…"))
        exec.execute {
            var ok = 0
            var fail = 0
            for (src in items) {
                try {
                    if (src.isDirectory && dir.canonicalPath.startsWith(src.canonicalPath)) {
                        fail++
                        continue
                    }
                    val target = uniqueTarget(dir, src.name)
                    if (cut) {
                        if (!src.renameTo(target)) {
                            copyRecursive(src, target)
                            src.deleteRecursively()
                        }
                    } else {
                        copyRecursive(src, target)
                    }
                    ok++
                } catch (e: Throwable) {
                    fail++
                }
            }
            handler.post {
                if (cut) clip = emptyList()
                toast(L.t("$ok tamam, $fail hata", "$ok done, $fail failed"))
                refresh()
            }
        }
    }

    private fun toast(s: String) {
        Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    }
}
