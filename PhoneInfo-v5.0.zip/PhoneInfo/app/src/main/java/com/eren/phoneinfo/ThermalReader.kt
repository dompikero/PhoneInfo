package com.eren.phoneinfo

import android.content.Context
import android.os.Build
import android.os.HardwarePropertiesManager
import android.os.PowerManager
import java.io.File
import java.util.concurrent.TimeUnit

data class TempReading(val name: String, val celsius: Float, val source: String)

class ThermalSnapshot(
    val readings: List<TempReading>,
    val cpu: Float?,
    val gpu: Float?,
    val battery: Float?,
    val skin: Float?,
    val sources: Set<String>,
    val statusText: String?,
    val headroom: Float?
)

/**
 * Android 10+ uygulamaların /sys/class/thermal dosyalarını okumasını çoğu cihazda engeller.
 * Bu sınıf, uygulamanın kullanabileceği TÜM meşru yolları sırayla dener:
 *  1) sysfs (thermal_zone / hwmon / bilinen GPU yolları)
 *  2) Sistem termal servisi (dumpsys thermalservice) - adb ile DUMP izni verilirse
 *  3) HardwarePropertiesManager (sadece ayrıcalıklı uygulamalarda çalışır)
 *  4) Root (su) - sadece kullanıcı açarsa
 *  5) Android termal durumu + termal yük (headroom)
 */
object ThermalReader {

    @Volatile
    var rootEnabled: Boolean = false

    private val GPU_PATHS = listOf(
        "/sys/class/kgsl/kgsl-3d0/temp",
        "/sys/class/kgsl/kgsl-3d0/devfreq/temp",
        "/sys/class/misc/mali0/device/temp",
        "/sys/class/devfreq/gpu/temp",
        "/sys/devices/platform/gpu/temp",
        "/sys/kernel/gpu/gpu_temp"
    )

    private fun readLine(f: File): String? {
        return try {
            f.bufferedReader().use { it.readLine() }?.trim()
        } catch (e: Throwable) {
            null
        }
    }

    fun normalize(raw: Float): Float? {
        var v = raw
        if (v > 1000f) v /= 1000f else if (v > 200f) v /= 10f
        return if (v >= 1f && v <= 150f) v else null
    }

    fun readSysfs(): List<TempReading> {
        val out = ArrayList<TempReading>()
        try {
            val zones = File("/sys/class/thermal").listFiles()
            if (zones != null) {
                val sorted = zones.filter { it.name.startsWith("thermal_zone") }
                    .sortedBy { it.name.removePrefix("thermal_zone").toIntOrNull() ?: 0 }
                for (z in sorted) {
                    val type = readLine(File(z, "type")) ?: z.name
                    val raw = readLine(File(z, "temp"))?.toFloatOrNull() ?: continue
                    val c = normalize(raw) ?: continue
                    out.add(TempReading(type, c, "sysfs"))
                }
            }
        } catch (e: Throwable) {
        }
        try {
            val hw = File("/sys/class/hwmon").listFiles()
            if (hw != null) {
                for (h in hw) {
                    val name = readLine(File(h, "name")) ?: h.name
                    val files = h.listFiles() ?: continue
                    for (f in files) {
                        if (f.name.startsWith("temp") && f.name.endsWith("_input")) {
                            val raw = readLine(f)?.toFloatOrNull() ?: continue
                            val c = normalize(raw) ?: continue
                            out.add(TempReading(name + "/" + f.name.removeSuffix("_input"), c, "hwmon"))
                        }
                    }
                }
            }
        } catch (e: Throwable) {
        }
        for (p in GPU_PATHS) {
            val raw = readLine(File(p))?.toFloatOrNull() ?: continue
            val c = normalize(raw) ?: continue
            out.add(TempReading("gpu(" + p.substringAfterLast("/sys/") + ")", c, "sysfs"))
        }
        return out
    }

    private fun typeLabel(type: Int): String = when (type) {
        0 -> "CPU"
        1 -> "GPU"
        2 -> "BATTERY"
        3 -> "SKIN"
        4 -> "USB_PORT"
        5 -> "POWER_AMPLIFIER"
        else -> "OTHER"
    }

    fun readThermalService(): List<TempReading> {
        val out = ArrayList<TempReading>()
        try {
            val p = ProcessBuilder("dumpsys", "thermalservice").redirectErrorStream(true).start()
            val txt = p.inputStream.bufferedReader().readText()
            p.waitFor(3, TimeUnit.SECONDS)
            val re = Regex("Temperature\\{mValue=([-0-9.]+), mType=([0-9]+), mName=([^,}]+)")
            val seen = HashSet<String>()
            for (m in re.findAll(txt)) {
                val v = m.groupValues[1].toFloatOrNull() ?: continue
                val type = m.groupValues[2].toIntOrNull() ?: -1
                val name = m.groupValues[3].trim()
                if (v < 1f || v > 150f) continue
                val label = typeLabel(type) + ":" + name
                if (seen.add(label)) out.add(TempReading(label, v, "termal servis"))
            }
        } catch (e: Throwable) {
        }
        return out
    }

    private fun readHpm(ctx: Context): List<TempReading> {
        val out = ArrayList<TempReading>()
        try {
            val hpm = ctx.getSystemService(Context.HARDWARE_PROPERTIES_SERVICE) as? HardwarePropertiesManager
                ?: return out
            val types = intArrayOf(
                HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU,
                HardwarePropertiesManager.DEVICE_TEMPERATURE_GPU,
                HardwarePropertiesManager.DEVICE_TEMPERATURE_BATTERY,
                HardwarePropertiesManager.DEVICE_TEMPERATURE_SKIN
            )
            for (t in types) {
                val arr = hpm.getDeviceTemperatures(t, HardwarePropertiesManager.TEMPERATURE_CURRENT)
                for ((i, v) in arr.withIndex()) {
                    if (v > 1f && v < 150f) out.add(TempReading(typeLabel(t) + ":" + i, v, "HPM"))
                }
            }
        } catch (e: Throwable) {
        }
        return out
    }

    private fun hasSu(): Boolean {
        val paths = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/data/local/bin/su")
        return paths.any { File(it).exists() }
    }

    private fun readRoot(): List<TempReading> {
        val out = ArrayList<TempReading>()
        if (!hasSu()) return out
        try {
            val cmd = "for z in /sys/class/thermal/thermal_zone*; do echo \$(cat \$z/type)=\$(cat \$z/temp); done"
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val txt = p.inputStream.bufferedReader().readText()
            p.waitFor(4, TimeUnit.SECONDS)
            for (line in txt.lines()) {
                val i = line.lastIndexOf('=')
                if (i <= 0) continue
                val raw = line.substring(i + 1).trim().toFloatOrNull() ?: continue
                val c = normalize(raw) ?: continue
                out.add(TempReading(line.substring(0, i).trim(), c, "root"))
            }
        } catch (e: Throwable) {
        }
        return out
    }

    private fun statusName(s: Int): String = when (s) {
        0 -> "NONE"
        1 -> "LIGHT"
        2 -> "MODERATE"
        3 -> "SEVERE"
        4 -> "CRITICAL"
        5 -> "EMERGENCY"
        6 -> "SHUTDOWN"
        else -> "?"
    }

    private fun matches(name: String, keys: List<String>): Boolean {
        val n = name.lowercase()
        return keys.any { n.contains(it) }
    }

    private val CPU_KEYS = listOf("cpu", "tsens_tz", "mtktscpu", "cluster", "soc", "apc", "big", "little", "core", "ap_therm", "tj")
    private val GPU_KEYS = listOf("gpu", "kgsl", "mali", "g3d", "adreno")
    private val BAT_KEYS = listOf("battery", "bat")
    private val SKIN_KEYS = listOf("skin", "shell", "case", "xo-therm", "quiet")

    private fun pick(list: List<TempReading>, keys: List<String>): Float? {
        var best: Float? = null
        for (r in list) {
            if (matches(r.name, keys)) {
                if (best == null || r.celsius > best) best = r.celsius
            }
        }
        return best
    }

    fun snapshot(ctx: Context, batteryC: Float?): ThermalSnapshot {
        val all = ArrayList<TempReading>()
        all.addAll(readSysfs())
        all.addAll(readThermalService())
        all.addAll(readHpm(ctx))
        if (rootEnabled && all.none { matches(it.name, CPU_KEYS) }) all.addAll(readRoot())

        // Zaten sıralı CPU/GPU değerleri servis kaynağında tip adıyla gelir (CPU:xxx, GPU:xxx)
        val cpu = pick(all, CPU_KEYS)
        val gpu = pick(all, GPU_KEYS)
        val bat = batteryC ?: pick(all, BAT_KEYS)
        val skin = pick(all, SKIN_KEYS)

        var statusText: String? = null
        var headroom: Float? = null
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= 29) statusText = statusName(pm.currentThermalStatus)
            if (Build.VERSION.SDK_INT >= 30) {
                val h = pm.getThermalHeadroom(0)
                if (!h.isNaN()) headroom = h
            }
        } catch (e: Throwable) {
        }

        val sources = LinkedHashSet<String>()
        for (r in all) sources.add(r.source)
        return ThermalSnapshot(all, cpu, gpu, bat, skin, sources, statusText, headroom)
    }
}
