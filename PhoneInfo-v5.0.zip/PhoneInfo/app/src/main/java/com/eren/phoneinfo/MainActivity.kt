package com.eren.phoneinfo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var tabInfo: LinearLayout
    private lateinit var tabFiles: LinearLayout
    private var infoScreen: InfoScreen? = null
    private var filesScreen: FilesScreen? = null
    private var currentTab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("phoneinfo", Context.MODE_PRIVATE)
        Palette.dark = prefs.getBoolean("dark", true)
        AppCompatDelegate.setDefaultNightMode(
            if (Palette.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        ThermalReader.rootEnabled = prefs.getBoolean("root", false)
        currentTab = savedInstanceState?.getInt("tab", 0) ?: 0

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab == 1 && filesScreen?.goUp() == true) return
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })

        val lang = prefs.getString("lang", null)
        if (lang == null) {
            val blank = View(this)
            blank.setBackgroundColor(Palette.bg)
            setContentView(blank)
            askLanguage()
        } else {
            L.tr = lang == "tr"
            buildUi()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", currentTab)
    }

    fun saveRootPref(v: Boolean) {
        prefs.edit().putBoolean("root", v).apply()
    }

    private fun askLanguage() {
        AlertDialog.Builder(this)
            .setTitle("Dil / Language")
            .setCancelable(false)
            .setItems(arrayOf("Türkçe", "English")) { _, which ->
                val code = if (which == 0) "tr" else "en"
                prefs.edit().putString("lang", code).apply()
                L.tr = code == "tr"
                buildUi()
            }
            .show()
    }

    private fun buildUi() {
        window.statusBarColor = Palette.bg
        window.navigationBarColor = Palette.card
        val ctrl = WindowCompat.getInsetsController(window, window.decorView)
        ctrl.isAppearanceLightStatusBars = !Palette.dark
        ctrl.isAppearanceLightNavigationBars = !Palette.dark

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Palette.bg)
        root.fitsSystemWindows = true

        // Başlık
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(10), dp(8), dp(6))
        val title = makeTv(this, "PhoneInfo", 22f, Palette.text, true)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 22f
        gear.setTextColor(Palette.text)
        gear.setPadding(dp(12), dp(6), dp(12), dp(6))
        gear.setOnClickListener { showSettings() }
        header.addView(gear)
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // İçerik
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Alt çubuk: solda Device Info, sağda Files
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.setBackgroundColor(Palette.card)
        bottom.setPadding(0, dp(4), 0, dp(4))
        tabInfo = makeTab("📱", L.t("Cihaz Bilgisi", "Device Info")) { selectTab(0) }
        tabFiles = makeTab("📁", L.t("Dosyalar", "Files")) { selectTab(1) }
        bottom.addView(tabInfo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(tabFiles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val divider = View(this)
        divider.setBackgroundColor(Palette.stroke)
        root.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        root.addView(bottom, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
        selectTab(currentTab)
    }

    private fun makeTab(icon: String, label: String, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(6), 0, dp(6))
        val i = TextView(this)
        i.text = icon
        i.textSize = 22f
        i.gravity = Gravity.CENTER
        val l = TextView(this)
        l.text = label
        l.textSize = 12f
        l.gravity = Gravity.CENTER
        l.setTextColor(Palette.sub)
        t.addView(i)
        t.addView(l)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun markTab(tab: LinearLayout, selected: Boolean) {
        val label = tab.getChildAt(1) as TextView
        label.setTextColor(if (selected) Palette.accent else Palette.sub)
        label.setTypeface(label.typeface, if (selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        tab.getChildAt(0).alpha = if (selected) 1f else 0.55f
    }

    private fun selectTab(i: Int) {
        currentTab = i
        content.removeAllViews()
        markTab(tabInfo, i == 0)
        markTab(tabFiles, i == 1)
        if (i == 0) {
            val s = infoScreen ?: InfoScreen(this).also { infoScreen = it }
            (s.view.parent as? ViewGroup)?.removeView(s.view)
            content.addView(s.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            s.start()
        } else {
            infoScreen?.stop()
            val f = filesScreen ?: FilesScreen(this).also { filesScreen = it }
            (f.view.parent as? ViewGroup)?.removeView(f.view)
            content.addView(f.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            f.refresh()
        }
    }

    private fun showSettings() {
        val langLabel = L.t("Dil: Türkçe → English", "Language: English → Türkçe")
        val themeLabel = if (Palette.dark) L.t("Tema: Açık moda geç", "Theme: switch to light") else L.t("Tema: Koyu moda geç", "Theme: switch to dark")
        AlertDialog.Builder(this)
            .setTitle(L.t("Ayarlar", "Settings"))
            .setItems(arrayOf(langLabel, themeLabel, L.t("Hakkında", "About"))) { _, which ->
                when (which) {
                    0 -> {
                        val code = if (L.tr) "en" else "tr"
                        prefs.edit().putString("lang", code).apply()
                        L.tr = code == "tr"
                        recreate()
                    }
                    1 -> {
                        prefs.edit().putBoolean("dark", !Palette.dark).apply()
                        Palette.dark = !Palette.dark
                        AppCompatDelegate.setDefaultNightMode(
                            if (Palette.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
                        )
                        recreate()
                    }
                    else -> AlertDialog.Builder(this)
                        .setTitle("PhoneInfo v5.0")
                        .setMessage(
                            L.t(
                                "Cihaz bilgisi, canlı sıcaklıklar ve dosya yöneticisi.",
                                "Device info, live temperatures and a file manager."
                            )
                        )
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) {
            if (currentTab == 0) infoScreen?.start() else filesScreen?.refresh()
        }
    }

    override fun onPause() {
        super.onPause()
        infoScreen?.stop()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        filesScreen?.refresh()
    }

}
