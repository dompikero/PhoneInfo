# PhoneInfo v4.0 — Major update

## What changed

- A first-launch language welcome screen with clear Türkçe and English choices. The selection is saved, existing v3 users see the chooser once after updating, and it can be changed later in Settings.
- Expanded English localization for navigation, card titles, row labels, common status values, and diagnostic reports. Device-provided identifiers and sensor names remain as reported by Android.
- Redesigned language picker uses a rounded gradient header, native language names, flags, and full-width language cards.
- CPU/GPU temperature detection checks readable Android thermal zones, Linux hwmon sensors, device-specific GPU paths, Android HardwarePropertiesManager (best effort), and Android's thermal-service dump when access is available.
- Removed the misleading fallback that could label the hottest arbitrary thermal zone as CPU temperature. Missing values now show N/A / Yok rather than guessing or showing zero.
- Thermal-service probing runs on a background thread and is cached so the UI does not wait for shell output.
- Corrected raw sensor-unit normalization and stable thermal-zone row ordering.
- Updated the app to version 4.0 (versionCode 5) and the GitHub Actions artifact name to `PhoneInfo-v4.0-apk`.

## Important temperature limitation

Android does not provide ordinary third-party apps with unrestricted access to CPU/GPU thermistor readings. A device/vendor may deny access to sysfs, hwmon, or thermal-service output. On those devices, the app cannot truthfully show an exact CPU/GPU temperature without privileged/root access or a manufacturer API. It will report that the reading is unavailable; Android thermal status is displayed separately and is not converted into degrees.

## Build

Place `PhoneInfo-v4.1.zip` at the repository root and use `.github/workflows/build.yml` (or the supplied `build-v4.yml`). Run the workflow in GitHub Actions and download the `PhoneInfo-v4.0-apk` artifact.

The current editing environment has no installed Android SDK/Gradle distribution, so this source package has not been compiled into an APK here. GitHub Actions is configured to install Java 17 and Gradle 8.7 and build the debug APK.
