package com.eren.phoneinfo

import android.opengl.EGL14
import android.opengl.GLES20
import java.io.File
import java.util.Locale

// ──────────────────────────────────────────────────────────────
//  SysInfo — Activity'den bağımsız sistem bilgisi okuyucuları
//  (CPU çekirdekleri, /proc/cpuinfo, /proc/meminfo, mount'lar, GL)
// ──────────────────────────────────────────────────────────────

internal fun sysRead(path: String, maxChars: Int = 300_000): String? = try {
    val t = File(path).readText()
    (if (t.length > maxChars) t.substring(0, maxChars) + "\n…" else t).trim()
} catch (e: Throwable) { null }

internal fun freqText(khz: Long): String =
    if (khz <= 0L) "-"
    else if (khz < 1_000_000L) "${khz / 1000} MHz"
    else String.format(Locale.getDefault(), "%.2f GHz", khz / 1_000_000.0)

// ── CPU çekirdekleri ─────────────────────────────────────────
internal class CpuCore(
    val index: Int,
    val curKHz: Long,
    val minKHz: Long,
    val maxKHz: Long,
    val governor: String
) {
    val fraction: Float
        get() = if (curKHz > 0 && maxKHz > 0) (curKHz.toFloat() / maxKHz.toFloat()).coerceIn(0f, 1f) else 0f
}

internal fun readCpuCore(i: Int): CpuCore {
    val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
    val cur = sysRead(b + "scaling_cur_freq")?.toLongOrNull()
        ?: sysRead(b + "cpuinfo_cur_freq")?.toLongOrNull() ?: -1L
    val min = sysRead(b + "cpuinfo_min_freq")?.toLongOrNull()
        ?: sysRead(b + "scaling_min_freq")?.toLongOrNull() ?: -1L
    val max = sysRead(b + "cpuinfo_max_freq")?.toLongOrNull()
        ?: sysRead(b + "scaling_max_freq")?.toLongOrNull() ?: -1L
    val gov = sysRead(b + "scaling_governor") ?: ""
    return CpuCore(i, cur, min, max, gov)
}

internal fun readCpuCores(n: Int): List<CpuCore> = (0 until n).map { readCpuCore(it) }

// ── /proc/cpuinfo ────────────────────────────────────────────
internal class CpuInfoData(
    val raw: String,
    val hardware: String?,
    val features: Set<String>,
    val implementer: String?,
    val architecture: String?,
    val variant: String?,
    val revision: String?,
    val partByCore: Map<Int, String>
)

internal fun parseCpuInfo(): CpuInfoData {
    val raw = sysRead("/proc/cpuinfo") ?: ""
    val kv = LinkedHashMap<String, String>()
    val parts = HashMap<Int, String>()
    var proc = -1
    for (line in raw.lines()) {
        val idx = line.indexOf(':')
        if (idx <= 0) continue
        val k = line.substring(0, idx).trim()
        val v = line.substring(idx + 1).trim()
        if (k.equals("processor", true)) proc = v.toIntOrNull() ?: -1
        if (k.equals("CPU part", true) && proc >= 0) parts[proc] = v.lowercase(Locale.ROOT)
        if (!kv.containsKey(k)) kv[k] = v
    }
    val feat = (kv["Features"] ?: "").split(" ").filter { it.isNotBlank() }.toSet()
    return CpuInfoData(
        raw, kv["Hardware"], feat, kv["CPU implementer"], kv["CPU architecture"],
        kv["CPU variant"], kv["CPU revision"], parts
    )
}

private val armParts = mapOf(
    "0xd03" to "Cortex-A53", "0xd04" to "Cortex-A35", "0xd05" to "Cortex-A55",
    "0xd07" to "Cortex-A57", "0xd08" to "Cortex-A72", "0xd09" to "Cortex-A73",
    "0xd0a" to "Cortex-A75", "0xd0b" to "Cortex-A76", "0xd0d" to "Cortex-A77",
    "0xd41" to "Cortex-A78", "0xd44" to "Cortex-X1", "0xd46" to "Cortex-A510",
    "0xd47" to "Cortex-A710", "0xd48" to "Cortex-X2", "0xd4d" to "Cortex-A715",
    "0xd4e" to "Cortex-X3", "0xd80" to "Cortex-A520", "0xd81" to "Cortex-A720",
    "0xd82" to "Cortex-X4", "0xd85" to "Cortex-X925", "0xd87" to "Cortex-A725"
)

private val implementers = mapOf(
    "0x41" to "ARM", "0x42" to "Broadcom", "0x43" to "Cavium", "0x48" to "HiSilicon",
    "0x4e" to "NVIDIA", "0x50" to "APM", "0x51" to "Qualcomm", "0x53" to "Samsung",
    "0x56" to "Marvell", "0x61" to "Apple", "0x69" to "Intel"
)

internal fun implementerName(code: String?): String? =
    code?.lowercase(Locale.ROOT)?.let { implementers[it] ?: it }

internal fun coreName(info: CpuInfoData, core: Int): String {
    val part = info.partByCore[core] ?: return "?"
    val imp = implementerName(info.implementer) ?: ""
    val known = if (info.implementer?.lowercase(Locale.ROOT) == "0x41") armParts[part] else null
    return if (known != null) "$imp $known".trim() else "$imp $part".trim()
}

/** "4x ARM Cortex-A55 @ 2002 MHz" gibi küme satırları. */
internal fun describeClusters(cores: List<CpuCore>, info: CpuInfoData): List<String> {
    data class Key(val name: String, val max: Long)
    val order = ArrayList<Key>()
    val counts = HashMap<Key, Int>()
    for (c in cores) {
        val key = Key(coreName(info, c.index), c.maxKHz)
        if (!counts.containsKey(key)) order.add(key)
        counts[key] = (counts[key] ?: 0) + 1
    }
    return order.map { k ->
        val mhz = if (k.max > 0) " @ ${k.max / 1000} MHz" else ""
        "${counts[k]}x ${k.name}$mhz"
    }
}

// ── /proc/meminfo ────────────────────────────────────────────
internal fun parseMemInfo(): LinkedHashMap<String, Long> {
    val out = LinkedHashMap<String, Long>()
    val raw = sysRead("/proc/meminfo") ?: return out
    for (line in raw.lines()) {
        val idx = line.indexOf(':')
        if (idx <= 0) continue
        val key = line.substring(0, idx).trim()
        val num = line.substring(idx + 1).trim().split(" ").firstOrNull()?.toLongOrNull() ?: continue
        out[key] = num // kB
    }
    return out
}

// ── Mount noktaları ──────────────────────────────────────────
internal class MountEntry(val device: String, val point: String, val fs: String, val readOnly: Boolean)

internal fun readMounts(): List<MountEntry> {
    val raw = sysRead("/proc/mounts") ?: sysRead("/proc/self/mounts") ?: return emptyList()
    return raw.lines().mapNotNull { line ->
        val p = line.split(" ")
        if (p.size < 4) null
        else MountEntry(p[0], p[1], p[2], p[3].split(",").contains("ro"))
    }
}

// ── GPU: görünmez EGL bağlamı ile GL bilgisi ─────────────────
internal class GlInfo(
    val vendor: String,
    val renderer: String,
    val version: String,
    val glsl: String,
    val extensions: List<String>
)

internal fun queryGlInfo(): GlInfo? {
    var dpy: android.opengl.EGLDisplay? = null
    var ctx: android.opengl.EGLContext? = null
    var surf: android.opengl.EGLSurface? = null
    try {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (dpy == null || dpy == EGL14.EGL_NO_DISPLAY) return null
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return null
        val cfgAttrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(dpy, cfgAttrs, 0, cfgs, 0, 1, num, 0) || num[0] <= 0) return null
        val cfg = cfgs[0] ?: return null
        ctx = EGL14.eglCreateContext(
            dpy, cfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        if (ctx == null || ctx == EGL14.EGL_NO_CONTEXT) {
            ctx = EGL14.eglCreateContext(
                dpy, cfg, EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
        }
        if (ctx == null || ctx == EGL14.EGL_NO_CONTEXT) return null
        surf = EGL14.eglCreatePbufferSurface(
            dpy, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        if (surf == null || surf == EGL14.EGL_NO_SURFACE) return null
        if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) return null
        val ext = (GLES20.glGetString(GLES20.GL_EXTENSIONS) ?: "")
            .split(" ").filter { it.isNotBlank() }
        return GlInfo(
            GLES20.glGetString(GLES20.GL_VENDOR) ?: "-",
            GLES20.glGetString(GLES20.GL_RENDERER) ?: "-",
            GLES20.glGetString(GLES20.GL_VERSION) ?: "-",
            GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION) ?: "-",
            ext
        )
    } catch (e: Throwable) {
        return null
    } finally {
        try {
            val d = dpy
            if (d != null && d != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                val s = surf
                if (s != null && s != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(d, s)
                val c = ctx
                if (c != null && c != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(d, c)
            }
        } catch (_: Throwable) {}
    }
}

/** GPU saat/yük bilgisi (cihaza özel yollar; okunamazsa null). */
internal fun gpuClockText(): String? {
    sysRead("/sys/kernel/gpu/gpu_clock")?.toLongOrNull()?.let { return "$it MHz" }
    sysRead("/sys/class/kgsl/kgsl-3d0/gpuclk")?.toLongOrNull()?.let { return "${it / 1_000_000} MHz" }
    sysRead("/sys/class/misc/mali0/device/clock")?.toLongOrNull()?.let { return "$it MHz" }
    return null
}

internal fun gpuBusyText(): String? {
    sysRead("/sys/kernel/gpu/gpu_busy")?.replace("%", "")?.trim()?.toIntOrNull()?.let { return "$it%" }
    sysRead("/sys/class/misc/mali0/device/utilization")?.trim()?.toIntOrNull()?.let { return "$it%" }
    return null
}
