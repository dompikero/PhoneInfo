package com.eren.phoneinfo

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ──────────────────────────────────────────────────────────────
//  ArcGauge — animasyonlu, gradyanlı yay göstergesi (sıcaklık)
// ──────────────────────────────────────────────────────────────
class ArcGauge(ctx: Context) : View(ctx) {
    var label: String = ""
        set(v) { field = v; invalidate() }
    var subText: String = ""
        set(v) { field = v; invalidate() }

    private val density = ctx.resources.displayMetrics.density
    private var shown = 0f
    private var target = 0f
    private var has = false
    private var valueText = "—"
    private var valueColor = Color.WHITE
    private var trackColor = 0x33888888
    private var textColor = Color.WHITE
    private var subColor = Color.GRAY
    private var gradColors = intArrayOf(0xFF3FB950.toInt(), 0xFFCDDC39.toInt(), 0xFFFFA726.toInt(), 0xFFF85149.toInt())
    private var shader: SweepGradient? = null
    private var anim: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        letterSpacing = 0.08f
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
    private val rect = RectF()

    fun applyColors(track: Int, text: Int, sub: Int, g0: Int, g1: Int, g2: Int, g3: Int) {
        trackColor = track; textColor = text; subColor = sub
        gradColors = intArrayOf(g0, g1, g2, g3)
        shader = null
        invalidate()
    }

    /** t == null → "N/A" durumu. Aralık 20–100 °C. */
    fun setTemp(t: Double?, color: Int, na: String) {
        if (t == null) {
            has = false
            valueText = na
            valueColor = subColor
            animateTo(0f)
        } else {
            has = true
            valueText = "%.1f".format(t)
            valueColor = color
            animateTo(((t - 20.0) / 80.0).coerceIn(0.0, 1.0).toFloat())
        }
        invalidate()
    }

    private fun animateTo(f: Float) {
        if (kotlin.math.abs(f - target) < 0.002f) return
        target = f
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, f).apply {
            duration = 520
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val stroke = min(w, h) * 0.105f
        val r = (min(w, h * 0.80f) - stroke * 1.6f) / 2f
        val cx = w / 2f
        val cy = h * 0.43f
        rect.set(cx - r, cy - r, cx + r, cy + r)

        trackPaint.strokeWidth = stroke
        trackPaint.color = trackColor
        c.drawArc(rect, 135f, 270f, false, trackPaint)

        if (shader == null) {
            val s = SweepGradient(cx, cy, intArrayOf(gradColors[0], gradColors[1], gradColors[2], gradColors[3], gradColors[3]),
                floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f))
            val m = Matrix(); m.setRotate(135f, cx, cy); s.setLocalMatrix(m)
            shader = s
        }

        val sweep = 270f * shown
        if (has && sweep > 0.5f) {
            glowPaint.strokeWidth = stroke * 1.9f
            glowPaint.color = valueColor
            glowPaint.alpha = 46
            c.drawArc(rect, 135f, sweep, false, glowPaint)

            arcPaint.strokeWidth = stroke
            arcPaint.shader = shader
            c.drawArc(rect, 135f, sweep, false, arcPaint)

            val ang = Math.toRadians((135f + sweep).toDouble())
            val kx = cx + r * cos(ang).toFloat()
            val ky = cy + r * sin(ang).toFloat()
            knobPaint.color = Color.WHITE
            c.drawCircle(kx, ky, stroke * 0.34f, knobPaint)
        }

        valuePaint.color = valueColor
        valuePaint.textSize = r * (if (has) 0.62f else 0.46f)
        c.drawText(valueText, cx, cy + valuePaint.textSize * 0.30f, valuePaint)
        if (has) {
            unitPaint.color = subColor
            unitPaint.textSize = r * 0.24f
            c.drawText("°C", cx, cy + valuePaint.textSize * 0.30f + unitPaint.textSize * 1.35f, unitPaint)
        }

        labelPaint.color = textColor
        labelPaint.textSize = 11.5f * density
        c.drawText(label, cx, cy + r + stroke * 0.55f + labelPaint.textSize * 0.9f, labelPaint)

        if (subText.isNotEmpty()) {
            subPaint.color = subColor
            subPaint.textSize = 10.5f * density
            c.drawText(subText, cx, cy + r + stroke * 0.55f + labelPaint.textSize * 0.9f + subPaint.textSize * 1.5f, subPaint)
        }
    }
}

// ──────────────────────────────────────────────────────────────
//  SparkLine — çok serili, yumuşatılmış canlı çizgi grafik
// ──────────────────────────────────────────────────────────────
class SparkLine(ctx: Context) : View(ctx) {
    class Series(val name: String, val color: Int) {
        val data = ArrayList<Float>()
    }

    val series = ArrayList<Series>()
    var maxPoints = 150
    var gridColor = 0x22FFFFFF
    var textColor = Color.GRAY
    var emptyText = "—"
    // Opsiyonel ayarlar (varsayılanlar eski davranışı korur)
    var unit = "°"
    var showAxis = true
    var fixedMin: Float? = null
    var fixedMax: Float? = null

    private val density = ctx.resources.displayMetrics.density
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun addSeries(name: String, color: Int): Series {
        val s = Series(name, color)
        series.add(s)
        return s
    }

    fun push(s: Series, v: Double?) {
        s.data.add(v?.toFloat() ?: Float.NaN)
        while (s.data.size > maxPoints) s.data.removeAt(0)
    }

    private fun withAlpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        series.forEach { s -> s.data.forEach { if (!it.isNaN()) { lo = min(lo, it); hi = max(hi, it) } } }

        val left = (if (showAxis) 34f else 6f) * density
        val right = w - 6f * density
        val top = 8f * density
        val bottom = h - 8f * density
        val plotW = right - left
        val plotH = bottom - top

        textPaint.textSize = 10f * density
        textPaint.color = textColor

        if (lo == Float.MAX_VALUE) {
            textPaint.textAlign = Paint.Align.CENTER
            c.drawText(emptyText, w / 2f, h / 2f, textPaint)
            return
        }

        var yMin = fixedMin ?: floor(lo - 3f)
        var yMax = fixedMax ?: ceil(hi + 3f)
        if (fixedMin == null || fixedMax == null) {
            if (yMax - yMin < 10f) { val mid = (yMax + yMin) / 2f; yMin = mid - 5f; yMax = mid + 5f }
        }

        gridPaint.strokeWidth = 1f * density
        gridPaint.color = gridColor
        textPaint.textAlign = Paint.Align.RIGHT
        for (i in 0..3) {
            val y = top + plotH * i / 3f
            c.drawLine(left, y, right, y, gridPaint)
            val value = yMax - (yMax - yMin) * i / 3f
            if (showAxis) c.drawText("%.0f".format(value) + unit, left - 5f * density, y + 3.5f * density, textPaint)
        }

        val stepX = plotW / (maxPoints - 1).coerceAtLeast(1)
        fun yOf(v: Float) = bottom - (v - yMin) / (yMax - yMin) * plotH

        for (s in series) {
            val n = s.data.size
            if (n == 0) continue
            val line = Path()
            val fill = Path()
            var inSeg = false
            var px = 0f
            var py = 0f
            var segStartX = 0f
            var lastX = 0f

            fun endSeg() {
                if (inSeg) {
                    fill.lineTo(lastX, bottom)
                    fill.lineTo(segStartX, bottom)
                    fill.close()
                    inSeg = false
                }
            }

            for (i in 0 until n) {
                val v = s.data[i]
                if (v.isNaN()) { endSeg(); continue }
                val x = right - (n - 1 - i) * stepX
                val y = yOf(v)
                if (!inSeg) {
                    line.moveTo(x, y)
                    fill.moveTo(x, bottom)
                    fill.lineTo(x, y)
                    segStartX = x
                    inSeg = true
                } else {
                    val mx = (px + x) / 2f
                    val my = (py + y) / 2f
                    line.quadTo(px, py, mx, my)
                    fill.quadTo(px, py, mx, my)
                }
                px = x; py = y; lastX = x
            }
            if (inSeg) {
                line.lineTo(px, py)
                fill.lineTo(px, py)
            }
            endSeg()

            fillPaint.shader = LinearGradient(0f, top, 0f, bottom, withAlpha(s.color, 70), withAlpha(s.color, 0), Shader.TileMode.CLAMP)
            c.drawPath(fill, fillPaint)
            fillPaint.shader = null

            linePaint.strokeWidth = 2.2f * density
            linePaint.color = s.color
            c.drawPath(line, linePaint)

            val lastV = s.data[n - 1]
            if (!lastV.isNaN()) {
                val ly = yOf(lastV)
                dotPaint.color = withAlpha(s.color, 60)
                c.drawCircle(right, ly, 7f * density, dotPaint)
                dotPaint.color = s.color
                c.drawCircle(right, ly, 3.6f * density, dotPaint)
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────
//  PillBar — animasyonlu yuvarlak ilerleme çubuğu
// ──────────────────────────────────────────────────────────────
class PillBar(ctx: Context) : View(ctx) {
    private var shown = 0f
    private var target = -1f
    private var trackColor = 0x33888888
    private var c1 = Color.CYAN
    private var c2 = Color.BLUE
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun setColors(track: Int, from: Int, to: Int) {
        trackColor = track; c1 = from; c2 = to
        invalidate()
    }

    fun setFraction(f: Float) {
        val t = f.coerceIn(0f, 1f)
        if (kotlin.math.abs(t - target) < 0.004f) return
        target = t
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, t).apply {
            duration = 420
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        paint.shader = null
        paint.color = trackColor
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, paint)
        val fw = max(h, w * shown)
        if (shown > 0.001f) {
            paint.shader = LinearGradient(0f, 0f, fw, 0f, c1, c2, Shader.TileMode.CLAMP)
            rect.set(0f, 0f, fw, h)
            c.drawRoundRect(rect, r, r, paint)
            paint.shader = null
        }
    }
}

// ──────────────────────────────────────────────────────────────
//  GlowHeader — dekoratif ışık halkalı, köşeleri kırpılmış başlık
// ──────────────────────────────────────────────────────────────
class GlowHeader(ctx: Context) : LinearLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val bounds = RectF()
    private val radius = 32f * ctx.resources.displayMetrics.density

    init { setWillNotDraw(false) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        clip.reset()
        bounds.set(0f, 0f, w, h)
        clip.addRoundRect(bounds, floatArrayOf(0f, 0f, 0f, 0f, radius, radius, radius, radius), Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.color = 0x16FFFFFF
        c.drawCircle(w * 0.95f, h * 0.10f, h * 0.62f, p)
        p.color = 0x0EFFFFFF
        c.drawCircle(w * 0.04f, h * 1.02f, h * 0.55f, p)
        p.color = 0x12FFFFFF
        c.drawCircle(w * 0.64f, h * 0.98f, h * 0.24f, p)
        c.restore()
    }
}
