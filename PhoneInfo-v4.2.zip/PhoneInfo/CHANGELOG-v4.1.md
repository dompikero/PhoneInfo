# Changelog — PhoneInfo v4.1

### Added
- New "Panel" (Dashboard) tab: animated CPU / GPU / battery temperature gauges, live temperature history chart, RAM / storage / battery meters.
- One-time permission card: `adb shell pm grant com.eren.phoneinfo android.permission.DUMP` lets the app read `dumpsys thermalservice` (HAL CPU/GPU temperatures) without root.
- Android thermal headroom (API 30+) shown as a heat-load percentage.
- `android.permission.DUMP` declared in the manifest.
- Power-supply sysfs temperature as an additional battery source.

### Fixed
- Thermal service parser no longer mixes cooling-device values into temperatures; only the live HAL section is read.

### UI
- Redesigned header (glow circles, device model line, status pills), icon-bubble card titles, hairline row dividers, wrapped right-aligned values, accent bars on stat cards, gradient page background.
- Thermal tab now uses the same gauges (with min / max).
