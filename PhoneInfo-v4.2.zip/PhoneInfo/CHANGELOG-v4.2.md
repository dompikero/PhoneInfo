# Changelog — PhoneInfo v4.2

The Dashboard ("Panel") tab is unchanged: thermal gauges, temperature history and the RAM / storage / battery meters are exactly as in v4.1.

### CPU tab (redesigned)
- Summary cards: cores, clock load, CPU temperature.
- Processor details: SoC, hardware, core clusters (e.g. 4x ARM Cortex-A55 @ 2002 MHz), instruction set, CPU revision, clock range, governor, ABIs (all / 32-bit / 64-bit), AES / NEON / PMULL / SHA1 / SHA2 / CRC32 / FP16 / dot-product flags, system load average, expandable `/proc/cpuinfo`.
- CPU Usage: per-core bars (current clock / max clock), two columns.
- CPU Frequency: overall percentage with live graph plus one live graph per core with its min–max range.
- CPU Temperature: live graph with current CPU / GPU / battery readings.
- GPU Summary: vendor, renderer, OpenGL ES version (read through an off-screen EGL context), GPU clock / load when the kernel exposes them.
- RAM: cached memory and swap usage, expandable `/proc/meminfo`. Storage: internal total.

### Other tabs (data from the AIDA64 report)
- Device: platform, device class, full fingerprint, code name, incremental, build type, tags, baseband, kernel architecture; new Runtime & Libraries card (Java VM, heap, ICU, Google Play Services, HMS, WebView); Memory & Storage card.
- Display: physical size in mm, orientation, max refresh rate; GPU card with GL extension list; Vulkan card (API version, level, compute).
- Battery: power source, charge cycles (Android 14+), Android capacity estimate, design capacity, time to full.
- Network: IPv4 / IPv6, hidden SSID, signal quality, Wi-Fi standard, gateway, netmask, DNS1, DHCP lease, 5 GHz support; cellular network code, SIM code / country / state, phone type, network type, data state / activity, ICC card; new Connectivity Features card (Bluetooth, BLE, NFC, HCE, GPS, Wi-Fi Direct / Aware / Passpoint, USB, IMS).
- Sensors: key-sensor availability summary (incl. fingerprint / face).
- Camera: video resolution, focus modes, video stabilization, OIS, zoom, AE / AWB lock.
- Codecs: decoder / encoder counts and HW / SW tags. Security: patch level, biometrics, hardware keystore, file-based encryption.
- New "Files" tab: directories, external storage paths, mount points and the system files from the report (`/proc/*`, `build.prop`, `hosts`, …) — tap a row to read or copy the file.

### Notes
- Values Android does not expose to normal apps (manufacturing process, RAM type, Vulkan device limits, fingerprint-sensor vendor, some `/proc` files) are not shown or are marked unavailable.
- Version 4.2 (versionCode 7). Put `PhoneInfo-v4.2.zip` at the repository root; the workflow builds artifact `PhoneInfo-v4.2-apk`.
