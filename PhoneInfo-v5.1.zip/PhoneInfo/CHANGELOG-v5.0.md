# Changelog — PhoneInfo v5.0

## Yeni gezinme
- Altta iki sekme: **Device Infos** (solda, eski tüm sekmeler) ve **Files** (sağda).
- Eski "Dosyalar" sekmesi Device Infos içinde **Yollar / Paths** adını aldı.

## Files — dosya yöneticisi
- Klasör gezintisi, hızlı konumlar (Dahili, Download, DCIM, Pictures, Android/data, Android/obb, SD kart, Kök /).
- Kopyala, Kes, Yapıştır, Sil, Yeniden adlandır, Yeni klasör/dosya, Zip / Zip aç, Paylaş, Bilgi.
- **Upload**: cihazdan dosya seçip bulunduğun klasöre ekle.
- Uzun basarak çoklu seçim, sıralama (ad/boyut/tarih), gizli dosyalar, arama, yola git.
- Metin ve resim görüntüleyici, diğer dosyalar için "Uygulamayla aç".
- Android/data ve Android/obb: Android 11+ bunu normal uygulamalara kapatır. Shizuku veya root izni verildiğinde dosyalara kabuk üzerinden erişilir.
- Tüm dosyalara erişim (MANAGE_EXTERNAL_STORAGE) izni gerekir.

## GPU sıcaklığı
- Shizuku veya root ile `/sys/class/thermal/*`, kgsl ve `dumpsys thermalservice` okunur; GPU sıcaklığı Panel, CPU ve Performans sekmelerine yansır.
- Ayrıcalıklı erişim penceresi: Shizuku izni iste, Root kontrol, ADB `pm grant DUMP` komutunu kopyala.
- Not: izin verilmeden bazı cihazlarda GPU sensörü hâlâ görünmez; bu Android'in kısıtıdır.

## Performans Laboratuvarı
- CPU: matris çarpımı + SHA-256 + trigonometri karışık yük, en yüksek thread önceliği, varsayılan yük %100.
- GPU: daha ağır shader, çok geçişli çizim, glFinish ile gerçek GPU kullanımı, canlı GPU FPS göstergesi, büyük önizleme.
- Yeni testler: **RAM**, **I/O**, **HER ŞEY** (CPU+GPU+RAM+I/O), **GPU tam ekran**.
- Güvenlik kilitleri (pil 44°C, CPU/GPU 88°C, Android termal durum) korunur.

## Araçlar
- Hoparlör testi (sol/sağ), ekran yenileme/FPS ölçer, su terazisi, RAM hız testi, ping, ekranı açık tut, raporu .txt kaydet, ayrıcalıklı erişim.

## Sürüm
- v5.0 (versionCode 8). Repo köküne `PhoneInfo-v5.0.zip` koy; workflow `PhoneInfo-v5.0-apk` çıktısını üretir.
