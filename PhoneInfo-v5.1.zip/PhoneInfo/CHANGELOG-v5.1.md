# Changelog — PhoneInfo v5.1

## Animasyonlar
- **Sayfa geçişi**: Device Infos ↔ Files arasında yatay kayma + solma animasyonu; üst başlık yumuşakça kaybolur/belirir.
- **Alt menü**: seçilen sekmenin hap arka planı yumuşakça açılır, simge yaylanarak büyür.
- **Sekmeler (Device Infos)**: sekme sırasına göre sağdan/soldan kayarak değişir, seçilen sekme otomatik ortalanır.
- **Files**:
  - Klasöre girerken liste sağdan, geri dönerken soldan kademeli (stagger) olarak akar.
  - Satıra / çipe / butona dokununca küçülüp bırakınca yaylanma efekti.
  - Seçim tiki “pop” animasyonuyla gelir; seçim moduna girince araç çubuğu ve ＋ butonu animasyonla değişir.
  - Arama kutusu kayarak açılır/kapanır, boş klasör ekranı yumuşakça belirir.
  - Depolama çubuğu dolarak açılır.

## Files — yeni arayüz
- Büyük başlık + **depolama kartı** (doluluk çubuğu, %85 üstü turuncu, %95 üstü kırmızı).
- **Tıklanabilir yol çubuğu** (📱 Dahili › Download › …): herhangi bir parçaya dokunarak o klasöre atla, ✎ ile yola git, ↑ ile üst klasör.
- Hızlı konumlarda bulunduğun yer vurgulanır.
- Liste artık tek büyük kart yerine **ayrı kartlar**: dosya türüne göre renkli simge kutusu, klasörlerde ›, seçilince vurgulu çerçeve.
- Kesilen dosyalar soluk, gizli dosyalar hafif soluk görünür.
- Yüzen **＋ (Yeni)** butonu; araç çubuğunda Yükle, Sırala, Gizli, Ara, Yenile, Bilgi.
- Boş klasör / sonuç yok / kilitli klasör için ayrı boş durum ekranları.

## Sürüm
- v5.1 (versionCode 9). Repo köküne `PhoneInfo-v5.1.zip` koy; workflow `PhoneInfo-v5.1-apk` çıktısını üretir.
