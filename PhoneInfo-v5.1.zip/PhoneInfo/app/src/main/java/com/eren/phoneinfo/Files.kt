package com.eren.phoneinfo

import android.Manifest
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.animation.ValueAnimator
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.DecelerateInterpolator
import android.view.animation.LayoutAnimationController
import android.view.animation.OvershootInterpolator
import android.view.animation.TranslateAnimation
import android.webkit.MimeTypeMap
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

// ──────────────────────────────────────────────────────────────
//  Dosya yöneticisi (v5.0)
//  - Normal erişim: java.io.File (Tüm dosyalar erişimi ile)
//  - Android/data, Android/obb ve okunamayan yollar: Shizuku veya root
//    varsa kabuk (ls/stat/cp/mv/rm) üzerinden
// ──────────────────────────────────────────────────────────────
private class FEntry(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long
)

class FileManager(private val act: MainActivity, private val pal: Palette, private val lang: String) {

    companion object {
        const val REQ_UPLOAD = 7101
        const val REQ_STORAGE = 7102
    }

    private val internalRoot: String = Environment.getExternalStorageDirectory().path
    private var cwd: String = internalRoot
    private var all: List<FEntry> = emptyList()
    private var shown: List<FEntry> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var clip: List<String> = emptyList()
    private var clipCut = false
    private var showHidden = false
    private var sortMode = 0 // 0 ad, 1 boyut, 2 tarih
    private var filter = ""
    private var navId = 0
    private var firstShown = false

    private val restrictedRe = Regex("""^/(storage/emulated/\d+|storage/self/primary|sdcard|mnt/sdcard|data/media/\d+|storage/[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4})/Android/(data|obb)(/.*)?$""")
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    private fun tr(t: String, e: String) = if (lang == "en") e else t
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()

    // ── UI ────────────────────────────────────────────────────
    private val crumbRow = LinearLayout(act)
    private val pathScroll = HorizontalScrollView(act)
    private val spaceTv = TextView(act)
    private val modeTv = TextView(act)
    private val bannerCard = LinearLayout(act)
    private val quickRow = LinearLayout(act)
    private val actionRow = LinearLayout(act)
    private val searchEt = EditText(act)
    private val emptyBox = LinearLayout(act)
    private val emptyEmoji = TextView(act)
    private val emptyTv = TextView(act)
    private val listView = ListView(act)
    private val storageBar = StorageBar(act, pal.stroke, pal.accent, pal.accent2, pal.warn, pal.danger)
    private val fab = TextView(act)
    private val quickViews = LinkedHashMap<String, TextView>()
    private var popPath: String? = null
    private var selMode = false
    private var searchOpen = false

    val view: View

    init {
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(8))
        }

        // Başlık satırı
        val titleRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, 0, dp(12))
        }
        titleRow.addView(TextView(act).apply {
            text = tr("Dosyalar", "Files")
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            setTextColor(pal.text)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        modeTv.apply {
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { act.showAccessDialog() }
        }
        pressable(modeTv, 0.94f)
        titleRow.addView(modeTv)
        root.addView(titleRow)

        // Depolama kartı
        val storageCard = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(12), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        val storageTop = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        storageTop.addView(TextView(act).apply {
            text = "💾 " + tr("Dahili depolama", "Internal storage")
            textSize = 12.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(pal.text)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        spaceTv.apply { textSize = 11.5f; setTextColor(pal.sub) }
        storageTop.addView(spaceTv)
        storageCard.addView(storageTop)
        storageCard.addView(storageBar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(10) })
        root.addView(storageCard)

        // İzin bandı
        bannerCard.apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor((pal.warn and 0x00FFFFFF) or 0x26000000)
                setStroke(dp(1), pal.warn)
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        bannerCard.addView(TextView(act).apply {
            text = tr(
                "Tüm dosyalara erişmek için “Tüm dosyalara erişim” izni gerekir.",
                "“All files access” permission is required to browse every file."
            )
            textSize = 12f
            setTextColor(pal.text)
        })
        bannerCard.addView(chip(tr("İzin ver", "Grant access"), true) { requestAllFiles() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8)
        })
        root.addView(bannerCard)

        // Yol kartı: ↑ + tıklanabilir yol parçaları + yola git
        val pathCard = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg()
            setPadding(dp(8), dp(6), dp(4), dp(6))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        }
        pathCard.addView(iconBtn("↑") { goUp() })
        crumbRow.orientation = LinearLayout.HORIZONTAL
        crumbRow.gravity = Gravity.CENTER_VERTICAL
        pathScroll.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(crumbRow)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        pathCard.addView(pathScroll)
        pathCard.addView(iconBtn("✎") { gotoDialog() })
        root.addView(pathCard)

        // Hızlı konumlar
        quickRow.orientation = LinearLayout.HORIZONTAL
        root.addView(HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(quickRow)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        })

        // Eylemler
        actionRow.orientation = LinearLayout.HORIZONTAL
        actionRow.gravity = Gravity.CENTER_VERTICAL
        root.addView(HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(actionRow)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        })

        // Arama
        searchEt.apply {
            hint = tr("Bu klasörde ara…", "Search this folder…")
            setHintTextColor(pal.sub)
            setTextColor(pal.text)
            textSize = 13.5f
            setSingleLine(true)
            visibility = View.GONE
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(pal.card)
                setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    filter = s?.toString() ?: ""
                    applyView()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(searchEt)

        // Liste + boş durum + FAB
        val listHost = android.widget.FrameLayout(act)
        listView.apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            setSelector(ColorDrawable(Color.TRANSPARENT))
            cacheColorHint = Color.TRANSPARENT
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setPadding(0, dp(2), 0, dp(96))
        }
        listHost.addView(listView, android.widget.FrameLayout.LayoutParams(-1, -1))

        emptyBox.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setOnClickListener { if (restrictedRe.matches(cwd)) act.showAccessDialog() }
        }
        emptyEmoji.apply { textSize = 46f; gravity = Gravity.CENTER }
        emptyTv.apply {
            textSize = 13.5f
            setTextColor(pal.sub)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        emptyBox.addView(emptyEmoji)
        emptyBox.addView(emptyTv)
        listHost.addView(emptyBox, android.widget.FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        fab.apply {
            text = "＋"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.accent, pal.accent2)).apply {
                shape = GradientDrawable.OVAL
            }
            elevation = dp(8).toFloat()
            setOnClickListener {
                rotation = 0f
                animate().cancel()
                animate().rotation(90f).setDuration(180).withEndAction { rotation = 0f }.start()
                newMenu()
            }
        }
        pressable(fab, 0.9f)
        listHost.addView(fab, android.widget.FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = dp(14)
            marginEnd = dp(4)
        })
        root.addView(listHost, LinearLayout.LayoutParams(-1, 0, 1f))

        view = root
        buildQuick()
        rebuildActions()
    }

    // ── Görünüm yardımcıları ──────────────────────────────────
    private fun cardBg() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.card, pal.card2)).apply {
        cornerRadius = dp(22).toFloat()
        setStroke(dp(1), pal.stroke)
    }

    private fun chipBackground(primary: Boolean): GradientDrawable =
        if (primary) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.accent, pal.accent2)).apply { cornerRadius = dp(22).toFloat() }
        } else {
            GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(pal.card)
                setStroke(dp(1), pal.stroke)
            }
        }

    /** Dokununca küçülüp bırakınca yaylanarak geri dönen buton efekti. Tıklamayı engellemez. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun pressable(v: View, scale: Float = 0.92f) {
        v.setOnTouchListener { target, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    target.animate().cancel()
                    target.animate().scaleX(scale).scaleY(scale).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    target.animate().scaleX(1f).scaleY(1f).setDuration(190).setInterpolator(OvershootInterpolator(2.5f)).start()
                }
            }
            false
        }
    }

    private fun chip(label: String, primary: Boolean = false, onLong: (() -> Unit)? = null, onClick: () -> Unit): TextView =
        TextView(act).apply {
            text = label
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (primary) Color.WHITE else pal.text)
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = chipBackground(primary)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
            pressable(this)
        }

    private fun iconBtn(label: String, active: Boolean = false, onClick: () -> Unit): TextView =
        TextView(act).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (active) Color.WHITE else pal.text)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (active) {
                    setColors(intArrayOf(pal.accent, pal.accent2))
                    setOrientation(GradientDrawable.Orientation.TL_BR)
                } else {
                    setColor(pal.card2)
                }
            }
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(6) }
            setOnClickListener { onClick() }
            pressable(this)
        }

    private fun extOf(e: FEntry) = e.name.substringAfterLast('.', "").lowercase()

    private fun iconFor(e: FEntry): String {
        if (e.isDir) return "📁"
        return when (extOf(e)) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg" -> "🖼"
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> "🎬"
            "mp3", "wav", "flac", "ogg", "m4a", "aac", "opus" -> "🎵"
            "zip", "rar", "7z", "tar", "gz", "xz" -> "🗜"
            "apk", "xapk", "apks" -> "📦"
            "pdf" -> "📕"
            "txt", "log", "md", "json", "xml", "csv", "prop", "conf", "ini", "yml", "yaml", "sh", "kt", "java", "js", "html", "css", "py" -> "📝"
            else -> "📄"
        }
    }

    /** Dosya türüne göre simge kutusu rengi. */
    private fun tintFor(e: FEntry): Int {
        if (e.isDir) return 0xFFFFB300.toInt()
        return when (extOf(e)) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg" -> 0xFFAB47BC.toInt()
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> 0xFFEF5350.toInt()
            "mp3", "wav", "flac", "ogg", "m4a", "aac", "opus" -> 0xFF26A69A.toInt()
            "zip", "rar", "7z", "tar", "gz", "xz" -> 0xFFFF7043.toInt()
            "apk", "xapk", "apks" -> 0xFF66BB6A.toInt()
            "pdf" -> 0xFFE53935.toInt()
            "txt", "log", "md", "json", "xml", "csv", "prop", "conf", "ini", "yml", "yaml", "sh", "kt", "java", "js", "html", "css", "py" -> 0xFF42A5F5.toInt()
            else -> pal.sub
        }
    }

    private fun sizeText(b: Long): String {
        val u = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = 0
        while (v >= 1024 && i < 4) { v /= 1024; i++ }
        return if (i == 0) "${b} B" else String.format(Locale.US, "%.1f %s", v, u[i])
    }

    private fun dateText(ms: Long) = if (ms <= 0L) "-" else dateFmt.format(Date(ms))

    private fun rowBg(selected: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat()
        if (selected) {
            setColor((pal.accent and 0x00FFFFFF) or 0x2E000000)
            setStroke(dp(1), pal.accent)
        } else {
            setColor(pal.card)
            setStroke(dp(1), pal.stroke)
        }
    }

    /** Klasör açılırken listeye giren animasyon. kind: 0 = yumuşak belirme, 1 = sağdan, 2 = soldan (geri). */
    private fun listAnim(kind: Int): LayoutAnimationController {
        val set = AnimationSet(true)
        set.addAnimation(AlphaAnimation(0f, 1f))
        if (kind == 0) {
            set.addAnimation(TranslateAnimation(0f, 0f, dp(10).toFloat(), 0f))
        } else {
            set.addAnimation(
                TranslateAnimation(
                    Animation.RELATIVE_TO_SELF, if (kind == 1) 0.14f else -0.14f,
                    Animation.RELATIVE_TO_SELF, 0f,
                    Animation.RELATIVE_TO_SELF, 0f,
                    Animation.RELATIVE_TO_SELF, 0f
                )
            )
        }
        set.duration = 280
        set.interpolator = DecelerateInterpolator(1.6f)
        return LayoutAnimationController(set, 0.06f)
    }

    // ── Liste adaptörü ────────────────────────────────────────
    private inner class Holder(
        val root: PressRow,
        val icon: TextView,
        val name: TextView,
        val sub: TextView,
        val arrow: TextView,
        val check: TextView
    )

    private fun makeHolder(): Holder {
        val root = PressRow(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = AbsListView.LayoutParams(-1, -2)
        }
        val icon = TextView(act).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(12) }
        }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val name = TextView(act).apply {
            textSize = 14.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(pal.text)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        val sub = TextView(act).apply {
            textSize = 11.5f
            setTextColor(pal.sub)
            maxLines = 1
            setPadding(0, dp(2), 0, 0)
        }
        col.addView(name)
        col.addView(sub)
        val arrow = TextView(act).apply {
            text = "›"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(pal.sub)
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(30))
        }
        val check = TextView(act).apply {
            text = "✓"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(pal.accent)
            }
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(26))
            visibility = View.GONE
        }
        root.addView(icon)
        root.addView(col)
        root.addView(arrow)
        root.addView(check)
        return Holder(root, icon, name, sub, arrow, check)
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h: Holder
            val v: View
            if (convertView == null) {
                h = makeHolder()
                v = h.root
                v.tag = h
            } else {
                v = convertView
                h = v.tag as Holder
            }
            val e = shown[position]
            h.root.animate().cancel()
            h.root.scaleX = 1f
            h.root.scaleY = 1f
            h.icon.text = iconFor(e)
            h.icon.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor((tintFor(e) and 0x00FFFFFF) or 0x2B000000)
            }
            h.name.text = e.name
            h.sub.text = if (e.isDir) dateText(e.modified) else sizeText(e.size) + "  ·  " + dateText(e.modified)
            val sel = selected.contains(e.path)
            h.root.background = rowBg(sel)
            h.root.alpha = when {
                clipCut && clip.contains(e.path) -> 0.45f
                e.name.startsWith(".") -> 0.62f
                else -> 1f
            }
            h.arrow.visibility = if (sel || !e.isDir) View.GONE else View.VISIBLE
            h.check.animate().cancel()
            if (sel) {
                h.check.visibility = View.VISIBLE
                if (popPath == e.path) {
                    popPath = null
                    h.check.scaleX = 0f
                    h.check.scaleY = 0f
                    h.check.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(3f)).start()
                } else {
                    h.check.scaleX = 1f
                    h.check.scaleY = 1f
                }
            } else {
                h.check.visibility = View.GONE
            }
            return v
        }
    }

    init {
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ -> onTap(shown[pos]) }
        listView.setOnItemLongClickListener { _, _, pos, _ -> toggleSel(shown[pos].path); true }
    }

    // ── Yaşam döngüsü ─────────────────────────────────────────
    fun onShow() {
        storageBar.reset()
        updateStatus()
        if (!firstShown) {
            firstShown = true
            openDir(cwd)
        } else {
            openDir(cwd)
        }
    }

    fun onResume() {
        updateStatus()
    }

    private fun hasAllFiles(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        Build.VERSION.SDK_INT >= 23 -> act.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else -> true
    }

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName)))
            } catch (_: Throwable) {
                try { act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Throwable) {}
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            act.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
        }
    }

    private fun updateStatus() {
        bannerCard.visibility = if (hasAllFiles()) View.GONE else View.VISIBLE
        val ready = Priv.ready()
        modeTv.text = if (ready) "🔓 " + Priv.label() else "🔒 " + tr("Standart erişim", "Standard access")
        modeTv.setTextColor(if (ready) Color.WHITE else pal.sub)
        modeTv.background = if (ready) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.ok, pal.accent)).apply { cornerRadius = dp(18).toFloat() }
        } else {
            GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(pal.card)
                setStroke(dp(1), pal.stroke)
            }
        }
        try {
            val st = StatFs(internalRoot)
            val total = st.totalBytes
            val free = st.availableBytes
            spaceTv.text = tr("Boş: ", "Free: ") + sizeText(free) + " / " + sizeText(total)
            storageBar.setFraction(if (total > 0L) ((total - free).toDouble() / total.toDouble()).toFloat() else 0f)
        } catch (_: Throwable) {
            spaceTv.text = ""
        }
    }

    private fun buildQuick() {
        quickRow.removeAllViews()
        quickViews.clear()
        fun add(label: String, path: String) {
            val c = chip(label) { openDir(path) }
            quickViews[path] = c
            quickRow.addView(c)
        }
        add("📱 " + tr("Dahili", "Internal"), internalRoot)
        add("⬇ Download", "$internalRoot/Download")
        add("📷 DCIM", "$internalRoot/DCIM")
        add("🖼 Pictures", "$internalRoot/Pictures")
        add("🤖 Android/data", "$internalRoot/Android/data")
        add("🎮 Android/obb", "$internalRoot/Android/obb")
        add("🏠 " + tr("Uygulama", "App"), act.filesDir.parent ?: act.filesDir.path)
        try {
            File("/storage").listFiles()?.forEach { f ->
                if (f.name != "emulated" && f.name != "self" && f.isDirectory) add("💽 " + f.name, f.path)
            }
        } catch (_: Throwable) {}
        add("⚙ " + tr("Kök", "Root") + " /", "/")
    }

    // ── Gezinme ───────────────────────────────────────────────
    private fun isRestricted(path: String) = restrictedRe.matches(path)

    private fun needsShell(path: String): Boolean = Priv.ready() && (isRestricted(path) || !File(path).canRead())

    private fun listDir(dir: String): List<FEntry>? {
        if (needsShell(dir)) return listShell(dir)
        val files = File(dir).listFiles() ?: return if (Priv.ready()) listShell(dir) else null
        return files.map { f -> FEntry(f.name, f.path, f.isDirectory, if (f.isDirectory) 0L else f.length(), f.lastModified()) }
    }

    private fun listShell(dir: String): List<FEntry>? {
        val d = Priv.q(dir)
        val r = Priv.exec(
            "cd $d 2>/dev/null || { echo __ERR__; exit 1; }; stat -L -c '%F|%s|%Y|%n' ./* ./.[!.]* ./..?* 2>/dev/null",
            15000L
        ) ?: return null
        if (r.second.contains("__ERR__")) return null
        val base = dir.trimEnd('/')
        val out = ArrayList<FEntry>()
        for (line in r.second.lineSequence()) {
            val parts = line.split("|", limit = 4)
            if (parts.size < 4) continue
            val name = parts[3].removePrefix("./")
            if (name.isEmpty()) continue
            out.add(
                FEntry(
                    name, "$base/$name", parts[0].startsWith("directory"),
                    parts[1].toLongOrNull() ?: 0L, (parts[2].toLongOrNull() ?: 0L) * 1000L
                )
            )
        }
        return out
    }

    fun openDir(dir: String) {
        val id = ++navId
        Thread {
            val res = try { listDir(dir) } catch (_: Throwable) { null }
            act.runOnUiThread {
                if (id != navId) return@runOnUiThread
                if (res == null) {
                    toast(tr("Bu klasöre erişilemiyor: ", "Cannot access this folder: ") + dir)
                    if (isRestricted(dir)) act.showAccessDialog()
                    return@runOnUiThread
                }
                val d = dir.trimEnd('/')
                val kind = when {
                    dir == cwd -> 0
                    cwd.startsWith("$d/") -> 2
                    else -> 1
                }
                cwd = dir
                all = res
                selected.clear()
                searchEt.setText("")
                filter = ""
                buildCrumbs(dir)
                updateQuickSel()
                listView.layoutAnimation = listAnim(kind)
                applyView()
                rebuildActions()
                updateStatus()
            }
        }.start()
    }

    private fun refresh() = openDir(cwd)

    private fun goUp() {
        val p = File(cwd).parent
        if (p != null) openDir(p)
    }

    /** Geri tuşu: true = tüketildi. */
    fun onBack(): Boolean {
        if (selected.isNotEmpty()) { clearSel(); return true }
        if (searchOpen) { toggleSearch(); return true }
        if (cwd != internalRoot && cwd != "/") { goUp(); return true }
        return false
    }

    private fun applyView() {
        val q = filter.trim().lowercase()
        val l = all.filter { (showHidden || !it.name.startsWith(".")) && (q.isEmpty() || it.name.lowercase().contains(q)) }
        val sorted = when (sortMode) {
            1 -> l.sortedWith(compareByDescending<FEntry> { it.size })
            2 -> l.sortedWith(compareByDescending<FEntry> { it.modified })
            else -> l.sortedWith(Comparator<FEntry> { a, b -> a.name.compareTo(b.name, ignoreCase = true) })
        }
        shown = sorted.sortedBy { if (it.isDir) 0 else 1 }
        adapter.notifyDataSetChanged()
        if (shown.isEmpty()) {
            val locked = isRestricted(cwd) && !Priv.ready() && Build.VERSION.SDK_INT >= 30
            emptyEmoji.text = if (locked) "🔒" else if (q.isNotEmpty()) "🔍" else "📭"
            emptyTv.text = if (locked)
                tr("Android 11+ bu klasörü normal uygulamalara kapatır.\nShizuku veya root ile açmak için dokun.",
                    "Android 11+ hides this folder from normal apps.\nTap to enable Shizuku or root access.")
            else if (q.isNotEmpty()) tr("Sonuç bulunamadı", "No results")
            else tr("Klasör boş", "Folder is empty")
            if (emptyBox.visibility != View.VISIBLE) {
                emptyBox.visibility = View.VISIBLE
                emptyBox.alpha = 0f
                emptyBox.scaleX = 0.92f
                emptyBox.scaleY = 0.92f
                emptyBox.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
            }
        } else {
            emptyBox.animate().cancel()
            emptyBox.visibility = View.GONE
        }
    }

    // ── Seçim ─────────────────────────────────────────────────
    private fun toggleSel(path: String) {
        if (!selected.remove(path)) { selected.add(path); popPath = path }
        adapter.notifyDataSetChanged()
        rebuildActions()
    }

    private fun clearSel() {
        selected.clear()
        adapter.notifyDataSetChanged()
        rebuildActions()
    }

    private fun onTap(e: FEntry) {
        if (selected.isNotEmpty()) { toggleSel(e.path); return }
        if (e.isDir) { openDir(e.path); return }
        openFile(e)
    }

    private fun rebuildActions() {
        val nowSel = selected.isNotEmpty()
        actionRow.removeAllViews()
        if (nowSel) {
            actionRow.addView(chip("✕ ${selected.size}", true) { clearSel() })
            actionRow.addView(chip("☑ " + tr("Tümü", "All")) {
                selected.clear()
                shown.forEach { selected.add(it.path) }
                adapter.notifyDataSetChanged()
                rebuildActions()
            })
            actionRow.addView(chip("📄 " + tr("Kopyala", "Copy")) { setClip(false) })
            actionRow.addView(chip("✂ " + tr("Kes", "Cut")) { setClip(true) })
            actionRow.addView(chip("🗑 " + tr("Sil", "Delete")) { confirmDelete() })
            if (selected.size == 1) actionRow.addView(chip("✏ " + tr("Ad değiştir", "Rename")) { renameSel() })
            actionRow.addView(chip("📤 " + tr("Paylaş", "Share")) { shareSel() })
            actionRow.addView(chip("🗜 Zip") { zipSel() })
            if (selected.size == 1 && selected.first().lowercase().endsWith(".zip")) {
                actionRow.addView(chip("📂 " + tr("Zip aç", "Unzip")) { unzipFile(selected.first()) })
            }
            actionRow.addView(chip("ℹ " + tr("Bilgi", "Info")) { infoFor(selected.first()) })
        } else {
            actionRow.addView(chip("⬆ " + tr("Yükle", "Upload")) { pickUpload() })
            if (clip.isNotEmpty()) {
                actionRow.addView(chip("📋 " + tr("Yapıştır", "Paste") + " (${clip.size})", true) { paste() })
            }
            actionRow.addView(chip("⇅ " + sortLabel()) {
                sortMode = (sortMode + 1) % 3
                listView.layoutAnimation = listAnim(0)
                applyView()
                rebuildActions()
            })
            actionRow.addView(iconBtn("👁", showHidden) {
                showHidden = !showHidden
                listView.layoutAnimation = listAnim(0)
                applyView()
                rebuildActions()
            })
            actionRow.addView(iconBtn("🔍", searchOpen) { toggleSearch() })
            actionRow.addView(iconBtn("⟳") { refresh() })
            actionRow.addView(iconBtn("ℹ") { infoFor(cwd) })
        }
        if (nowSel != selMode) {
            selMode = nowSel
            actionRow.animate().cancel()
            actionRow.alpha = 0f
            actionRow.translationY = -dp(8).toFloat()
            actionRow.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
            setFabVisible(!nowSel)
        }
    }

    private fun toggleSearch() {
        searchOpen = !searchOpen
        searchEt.animate().cancel()
        if (searchOpen) {
            searchEt.visibility = View.VISIBLE
            searchEt.alpha = 0f
            searchEt.translationY = -dp(6).toFloat()
            searchEt.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
            searchEt.requestFocus()
        } else {
            searchEt.setText("")
            searchEt.animate().alpha(0f).translationY(-dp(6).toFloat()).setDuration(150).withEndAction {
                if (!searchOpen) searchEt.visibility = View.GONE
            }.start()
        }
        rebuildActions()
    }

    private fun setFabVisible(show: Boolean) {
        fab.animate().cancel()
        if (show) {
            fab.visibility = View.VISIBLE
            fab.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
        } else {
            fab.animate().scaleX(0.3f).scaleY(0.3f).alpha(0f).setDuration(150).setInterpolator(DecelerateInterpolator()).withEndAction {
                if (selected.isNotEmpty()) fab.visibility = View.GONE
            }.start()
        }
    }

    /** Yolu tıklanabilir parçalara böler (📱 Dahili › Download › Alt klasör). */
    private fun buildCrumbs(dir: String) {
        crumbRow.removeAllViews()
        val parts = ArrayList<Pair<String, String>>()
        val d = dir.trimEnd('/')
        val base: String
        if (d == internalRoot || d.startsWith("$internalRoot/")) {
            parts.add(Pair("📱 " + tr("Dahili", "Internal"), internalRoot))
            base = internalRoot
        } else {
            parts.add(Pair("⚙ /", "/"))
            base = ""
        }
        var acc = base
        for (seg in d.removePrefix(base).split('/').filter { it.isNotEmpty() }) {
            acc = "$acc/$seg"
            parts.add(Pair(seg, acc))
        }
        for (i in parts.indices) {
            val label = parts[i].first
            val target = parts[i].second
            val last = i == parts.size - 1
            if (i > 0) {
                crumbRow.addView(TextView(act).apply {
                    text = "›"
                    textSize = 16f
                    setTextColor(pal.sub)
                    setPadding(dp(2), 0, dp(2), 0)
                })
            }
            val tv = TextView(act).apply {
                text = label
                textSize = 12.5f
                maxLines = 1
                setTypeface(null, if (last) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (last) Color.WHITE else pal.text)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                if (last) {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.accent, pal.accent2)).apply {
                        cornerRadius = dp(14).toFloat()
                    }
                }
                setOnClickListener { if (!last) openDir(target) }
                setOnLongClickListener { gotoDialog(); true }
            }
            pressable(tv, 0.94f)
            crumbRow.addView(tv)
            if (last) {
                tv.alpha = 0f
                tv.scaleX = 0.85f
                tv.scaleY = 0.85f
                tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(2f)).start()
            }
        }
        pathScroll.postDelayed({ pathScroll.smoothScrollTo(crumbRow.width, 0) }, 60L)
    }

    /** Bulunulan klasöre en yakın hızlı konum çipini vurgular. */
    private fun updateQuickSel() {
        var best: String? = null
        for (p in quickViews.keys) {
            val d = p.trimEnd('/')
            if (cwd == p || cwd.startsWith("$d/")) {
                val cur = best
                if (cur == null || p.length > cur.length) best = p
            }
        }
        for ((p, tv) in quickViews) {
            val sel = p == best
            tv.background = chipBackground(sel)
            tv.setTextColor(if (sel) Color.WHITE else pal.text)
        }
    }

    private fun sortLabel() = when (sortMode) {
        1 -> tr("Boyut", "Size")
        2 -> tr("Tarih", "Date")
        else -> tr("Ad", "Name")
    }

    // ── İşlem çalıştırıcı ─────────────────────────────────────
    private fun runOp(title: String, op: () -> String?, after: () -> Unit = {}) {
        val lay = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }
        lay.addView(ProgressBar(act))
        lay.addView(TextView(act).apply {
            text = title
            textSize = 14f
            setPadding(dp(16), 0, 0, 0)
        })
        val dlg = AlertDialog.Builder(act).setView(lay).setCancelable(false).create()
        dlg.show()
        Thread {
            val err = try { op() } catch (e: Throwable) { e.message ?: e.toString() }
            act.runOnUiThread {
                try { dlg.dismiss() } catch (_: Throwable) {}
                if (err != null) toast(err)
                after()
            }
        }.start()
    }

    // ── Kopyala / Kes / Yapıştır ──────────────────────────────
    private fun setClip(cut: Boolean) {
        clip = selected.toList()
        clipCut = cut
        selected.clear()
        adapter.notifyDataSetChanged()
        rebuildActions()
        toast((if (cut) tr("Kesildi: ", "Cut: ") else tr("Kopyalandı: ", "Copied: ")) + clip.size)
    }

    private fun paste() {
        val srcs = clip
        val move = clipCut
        val dst = cwd
        runOp(if (move) tr("Taşınıyor…", "Moving…") else tr("Kopyalanıyor…", "Copying…"), { doTransfer(srcs, dst, move) }) {
            if (move) clip = emptyList()
            refresh()
        }
    }

    private fun uniquePath(dir: String, name: String, shell: Boolean): String {
        val d = dir.trimEnd('/')
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var cand = "$d/$name"
        var i = 1
        while (if (shell) existsShell(cand) else File(cand).exists()) {
            cand = "$d/$base ($i)$ext"
            i++
        }
        return cand
    }

    private fun existsShell(p: String): Boolean =
        Priv.exec("[ -e ${Priv.q(p)} ] && echo Y")?.second?.contains("Y") == true

    private fun doTransfer(srcs: List<String>, dstDir: String, move: Boolean): String? {
        val errs = ArrayList<String>()
        for (s in srcs) {
            val name = File(s).name
            try {
                if (dstDir == s || dstDir.startsWith("$s/")) {
                    errs.add(name + ": " + tr("Klasör kendi içine kopyalanamaz", "Cannot copy a folder into itself"))
                    continue
                }
                val shell = needsShell(s) || needsShell(dstDir)
                val target = uniquePath(dstDir, name, shell)
                if (shell) {
                    val cmd = (if (move) "mv " else "cp -a ") + Priv.q(s) + " " + Priv.q(target)
                    val r = Priv.exec(cmd, 900_000L)
                    if (r == null || r.first != 0) errs.add(name + ": " + (r?.second?.trim()?.take(120) ?: tr("Erişim yok", "No access")))
                } else {
                    val src = File(s)
                    val dst = File(target)
                    if (move) {
                        if (!src.renameTo(dst)) {
                            if (src.copyRecursively(dst, false)) src.deleteRecursively() else errs.add(name)
                        }
                    } else if (!src.copyRecursively(dst, false)) {
                        errs.add(name)
                    }
                }
            } catch (e: Throwable) {
                errs.add(name + ": " + (e.message ?: "error"))
            }
        }
        return if (errs.isEmpty()) null else errs.joinToString("\n")
    }

    // ── Sil ───────────────────────────────────────────────────
    private fun confirmDelete() {
        val items = selected.toList()
        AlertDialog.Builder(act)
            .setTitle(tr("Silinsin mi?", "Delete?"))
            .setMessage(
                (if (items.size == 1) File(items[0]).name else "${items.size} " + tr("öğe", "items")) + "\n\n" +
                    tr("Bu işlem geri alınamaz.", "This cannot be undone.")
            )
            .setPositiveButton(tr("Sil", "Delete")) { _, _ ->
                runOp(tr("Siliniyor…", "Deleting…"), {
                    val errs = ArrayList<String>()
                    for (p in items) {
                        try {
                            if (needsShell(p)) {
                                val r = Priv.exec("rm -rf " + Priv.q(p), 600_000L)
                                if (r == null || r.first != 0) errs.add(File(p).name)
                            } else if (!File(p).deleteRecursively()) errs.add(File(p).name)
                        } catch (_: Throwable) { errs.add(File(p).name) }
                    }
                    if (errs.isEmpty()) null else tr("Silinemedi: ", "Could not delete: ") + errs.joinToString(", ")
                }) { refresh() }
            }
            .setNegativeButton(tr("İptal", "Cancel"), null)
            .show()
    }

    // ── Yeniden adlandır / Yeni ───────────────────────────────
    private fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(act).apply {
            setText(initial)
            setSelection(initial.length)
            setSingleLine(true)
            setTextColor(pal.text)
        }
        val lay = LinearLayout(act).apply {
            setPadding(dp(22), dp(10), dp(22), 0)
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setView(lay)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty() || n.contains("/")) toast(tr("Geçersiz ad", "Invalid name")) else onOk(n)
            }
            .setNegativeButton(tr("İptal", "Cancel"), null)
            .show()
    }

    private fun renameSel() {
        val p = selected.firstOrNull() ?: return
        val f = File(p)
        askName(tr("Yeniden adlandır", "Rename"), f.name) { n ->
            val target = f.parent.orEmpty().trimEnd('/') + "/" + n
            runOp(tr("Çalışıyor…", "Working…"), {
                if (needsShell(p) || needsShell(target)) {
                    val r = Priv.exec("mv " + Priv.q(p) + " " + Priv.q(target))
                    if (r == null || r.first != 0) r?.second?.trim()?.take(150) ?: tr("Erişim yok", "No access") else null
                } else {
                    if (File(target).exists()) tr("Bu adla bir dosya var", "Name already exists")
                    else if (f.renameTo(File(target))) null else tr("Yeniden adlandırılamadı", "Rename failed")
                }
            }) { selected.clear(); refresh(); rebuildActions() }
        }
    }

    private fun newMenu() {
        AlertDialog.Builder(act)
            .setItems(arrayOf("📁 " + tr("Yeni klasör", "New folder"), "📄 " + tr("Yeni dosya", "New file"))) { _, which ->
                askName(if (which == 0) tr("Klasör adı", "Folder name") else tr("Dosya adı", "File name"), "") { n ->
                    val target = cwd.trimEnd('/') + "/" + n
                    runOp(tr("Çalışıyor…", "Working…"), {
                        if (needsShell(cwd)) {
                            val cmd = if (which == 0) "mkdir -p " + Priv.q(target) else ": > " + Priv.q(target)
                            val r = Priv.exec(cmd)
                            if (r == null || r.first != 0) r?.second?.trim()?.take(150) ?: tr("Erişim yok", "No access") else null
                        } else {
                            val f = File(target)
                            val ok = if (which == 0) f.mkdirs() else try { f.createNewFile() } catch (_: IOException) { false }
                            if (ok) null else tr("Oluşturulamadı", "Could not create")
                        }
                    }) { refresh() }
                }
            }
            .show()
    }

    // ── Yükle (cihazdan dosya seç) ────────────────────────────
    private fun pickUpload() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            act.startActivityForResult(i, REQ_UPLOAD)
        } catch (_: Throwable) {
            toast(tr("Dosya seçici açılamadı", "Cannot open file picker"))
        }
    }

    fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != REQ_UPLOAD || res != android.app.Activity.RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        val cd = data.clipData
        if (cd != null) for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        if (uris.isEmpty()) return
        val dst = cwd
        runOp(tr("Yükleniyor…", "Uploading…"), {
            var fail = 0
            for (u in uris.distinct()) {
                try { importUri(u, dst) } catch (_: Throwable) { fail++ }
            }
            if (fail == 0) null else tr("Yüklenemeyen dosya: ", "Failed files: ") + fail
        }) { refresh() }
    }

    private fun displayName(u: Uri): String {
        var n: String? = null
        try {
            act.contentResolver.query(u, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) n = c.getString(idx)
            }
        } catch (_: Throwable) {}
        return n ?: (u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    private fun importUri(u: Uri, dstDir: String) {
        val name = displayName(u)
        val shell = needsShell(dstDir)
        if (!shell) {
            val out = File(uniquePath(dstDir, name, false))
            act.contentResolver.openInputStream(u)?.use { ins -> FileOutputStream(out).use { ins.copyTo(it) } }
                ?: throw IOException("open failed")
        } else {
            val stage = File(act.getExternalFilesDir(null) ?: throw IOException("no staging"), ".staging")
            stage.mkdirs()
            val tmp = File(stage, "up_" + System.nanoTime())
            act.contentResolver.openInputStream(u)?.use { ins -> FileOutputStream(tmp).use { ins.copyTo(it) } }
                ?: throw IOException("open failed")
            tmp.setReadable(true, false)
            val target = uniquePath(dstDir, name, true)
            val r = Priv.exec("cp " + Priv.q(tmp.path) + " " + Priv.q(target), 600_000L)
            tmp.delete()
            if (r == null || r.first != 0) throw IOException(r?.second ?: "cp failed")
        }
    }

    // ── Dosya açma / görüntüleme ──────────────────────────────
    private val textExt = setOf("txt", "log", "md", "json", "xml", "csv", "prop", "conf", "ini", "yml", "yaml", "sh", "kt", "java", "js", "html", "css", "py", "cfg", "properties", "gradle", "rc", "list", "hosts", "pro", "sql")
    private val imgExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")

    private fun openFile(e: FEntry) {
        val ext = e.name.substringAfterLast('.', "").lowercase()
        when {
            ext == "zip" -> AlertDialog.Builder(act)
                .setTitle(e.name)
                .setItems(arrayOf("📂 " + tr("Burada aç (Zip)", "Extract here"), "↗ " + tr("Uygulamayla aç", "Open with…"))) { _, w ->
                    if (w == 0) unzipFile(e.path) else viewExternal(e)
                }.show()
            ext in imgExt -> showImage(e)
            ext in textExt || (e.size == 0L) || (e.size in 1..400_000 && ext.isEmpty()) -> showText(e)
            else -> viewExternal(e)
        }
    }

    private fun showText(e: FEntry) {
        Thread {
            val txt = readHead(e.path, 200_000)
            act.runOnUiThread {
                if (txt == null) { toast(tr("Dosya okunamadı", "Cannot read file")); return@runOnUiThread }
                val tv = TextView(act).apply {
                    text = if (txt.isEmpty()) tr("(boş)", "(empty)") else txt
                    textSize = 11f
                    typeface = Typeface.MONOSPACE
                    setTextIsSelectable(true)
                    setTextColor(pal.text)
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                }
                val sv = ScrollView(act).apply { setBackgroundColor(pal.card); addView(tv) }
                AlertDialog.Builder(act)
                    .setTitle(e.name)
                    .setView(sv)
                    .setPositiveButton(tr("Kapat", "Close"), null)
                    .setNeutralButton(tr("Kopyala", "Copy")) { _, _ ->
                        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText(e.name, txt))
                        Toast.makeText(act, tr("Kopyalandı", "Copied"), Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
        }.start()
    }

    private fun readHead(path: String, max: Int): String? = try {
        if (needsShell(path)) {
            Priv.exec("head -c $max " + Priv.q(path), 20000L)?.second
        } else {
            FileInputStream(path).use { ins ->
                val buf = ByteArray(max)
                val n = ins.read(buf)
                if (n <= 0) "" else String(buf, 0, n, Charsets.UTF_8)
            }
        }
    } catch (_: Throwable) { null }

    private fun materialize(path: String): File? {
        if (!needsShell(path)) return File(path)
        val dir = File(act.getExternalFilesDir(null) ?: return null, ".staging")
        dir.mkdirs()
        val out = File(dir, File(path).name)
        val r = Priv.exec("cp -f " + Priv.q(path) + " " + Priv.q(out.path) + " && chmod 666 " + Priv.q(out.path), 300_000L)
        return if (r != null && r.first == 0 && out.exists()) out else null
    }

    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(act, act.packageName + ".fileprovider", f)

    private fun showImage(e: FEntry) {
        Thread {
            val f = materialize(e.path)
            var bmp: android.graphics.Bitmap? = null
            if (f != null) {
                try {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(f.path, o)
                    var s = 1
                    while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
                    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                    bmp = BitmapFactory.decodeFile(f.path, o2)
                } catch (_: Throwable) {}
            }
            act.runOnUiThread {
                if (bmp == null) { viewExternal(e); return@runOnUiThread }
                val iv = ImageView(act).apply {
                    setImageBitmap(bmp)
                    adjustViewBounds = true
                    setBackgroundColor(Color.BLACK)
                }
                AlertDialog.Builder(act)
                    .setTitle(e.name)
                    .setView(iv)
                    .setPositiveButton(tr("Kapat", "Close"), null)
                    .setNeutralButton(tr("Uygulamayla aç", "Open with…")) { _, _ -> viewExternal(e) }
                    .show()
            }
        }.start()
    }

    private fun viewExternal(e: FEntry) {
        Thread {
            val f = materialize(e.path)
            act.runOnUiThread {
                if (f == null) { toast(tr("Dosya hazırlanamadı", "Could not prepare file")); return@runOnUiThread }
                try {
                    val ext = e.name.substringAfterLast('.', "").lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                    val i = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uriFor(f), mime)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    act.startActivity(i)
                } catch (_: ActivityNotFoundException) {
                    toast(tr("Bu dosyayı açacak uygulama yok", "No app can open this file"))
                } catch (t: Throwable) {
                    toast(t.message ?: "error")
                }
            }
        }.start()
    }

    // ── Paylaş ────────────────────────────────────────────────
    private fun shareSel() {
        val files = selected.filter { !File(it).isDirectory || needsShell(it) }
        if (files.isEmpty()) {
            toast(tr("Klasörleri paylaşmak için önce Zip yap.", "Zip folders first to share them."))
            return
        }
        Thread {
            val list = files.mapNotNull { p ->
                try { materialize(p)?.takeIf { it.isFile } } catch (_: Throwable) { null }
            }
            act.runOnUiThread {
                if (list.isEmpty()) { toast(tr("Paylaşılamadı", "Could not share")); return@runOnUiThread }
                try {
                    val uris = ArrayList<Uri>(list.map { uriFor(it) })
                    val i = if (uris.size == 1) {
                        Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
                    } else {
                        Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
                    }
                    i.type = "*/*"
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    act.startActivity(Intent.createChooser(i, tr("Paylaş", "Share")))
                } catch (t: Throwable) {
                    toast(t.message ?: "error")
                }
            }
        }.start()
    }

    // ── Zip ───────────────────────────────────────────────────
    private fun zipSel() {
        val items = selected.toList()
        if (items.any { needsShell(it) } || needsShell(cwd)) {
            toast(tr("Zip bu klasörlerde henüz desteklenmiyor (önce başka klasöre kopyala).", "Zip is not supported in privileged folders yet (copy elsewhere first)."))
            return
        }
        val first = File(items[0])
        val base = if (items.size == 1) first.nameWithoutExtension.ifEmpty { first.name } else "archive"
        val out = File(uniquePath(cwd, "$base.zip", false))
        runOp(tr("Zip oluşturuluyor…", "Creating zip…"), {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
                for (p in items) {
                    val s = File(p)
                    val parent = s.parentFile ?: File("/")
                    s.walkTopDown().forEach { f ->
                        if (f.absolutePath != out.absolutePath) {
                            val rel = f.relativeTo(parent).path
                            if (f.isDirectory) {
                                zos.putNextEntry(ZipEntry("$rel/"))
                                zos.closeEntry()
                            } else {
                                zos.putNextEntry(ZipEntry(rel))
                                FileInputStream(f).use { it.copyTo(zos) }
                                zos.closeEntry()
                            }
                        }
                    }
                }
            }
            null
        }) { selected.clear(); refresh(); rebuildActions() }
    }

    private fun unzipFile(path: String) {
        if (needsShell(path) || needsShell(cwd)) {
            toast(tr("Zip bu klasörlerde henüz desteklenmiyor.", "Zip is not supported in privileged folders yet."))
            return
        }
        val zip = File(path)
        val outDir = File(uniquePath(cwd, zip.nameWithoutExtension.ifEmpty { "extracted" }, false))
        runOp(tr("Zip açılıyor…", "Extracting…"), {
            outDir.mkdirs()
            val canon = outDir.canonicalPath
            ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    val f = File(outDir, e.name)
                    val cp = f.canonicalPath
                    if (cp != canon && !cp.startsWith(canon + File.separator)) throw IOException("Unsafe zip entry")
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }
            null
        }) { selected.clear(); refresh(); rebuildActions() }
    }

    // ── Bilgi / Git ───────────────────────────────────────────
    private fun infoFor(path: String) {
        Thread {
            val sb = StringBuilder()
            sb.append(tr("Yol", "Path")).append(": ").append(path).append('\n')
            try {
                if (needsShell(path)) {
                    val r = Priv.exec("stat -L -c '%F|%s|%Y|%A|%U|%G' " + Priv.q(path) + "; du -sk " + Priv.q(path) + " 2>/dev/null | cut -f1")
                    val lines = r?.second?.lines().orEmpty()
                    val p = lines.getOrNull(0)?.split("|").orEmpty()
                    if (p.size >= 6) {
                        sb.append(tr("Tür", "Type")).append(": ").append(p[0]).append('\n')
                        sb.append(tr("Boyut", "Size")).append(": ")
                            .append(sizeText((lines.getOrNull(1)?.trim()?.toLongOrNull() ?: 0L) * 1024L)).append('\n')
                        sb.append(tr("Değiştirilme", "Modified")).append(": ").append(dateText((p[2].toLongOrNull() ?: 0L) * 1000L)).append('\n')
                        sb.append(tr("İzinler", "Permissions")).append(": ").append(p[3]).append("  ").append(p[4]).append(':').append(p[5]).append('\n')
                    }
                    sb.append(tr("Erişim", "Access")).append(": ").append(Priv.label())
                } else {
                    val f = File(path)
                    sb.append(tr("Tür", "Type")).append(": ").append(if (f.isDirectory) tr("Klasör", "Folder") else tr("Dosya", "File")).append('\n')
                    if (f.isDirectory) {
                        var n = 0
                        var total = 0L
                        f.walkTopDown().forEach { x -> if (x != f) { n++; if (x.isFile) total += x.length() } }
                        sb.append(tr("İçerik", "Contents")).append(": ").append(n).append(' ').append(tr("öğe", "items")).append('\n')
                        sb.append(tr("Boyut", "Size")).append(": ").append(sizeText(total)).append('\n')
                    } else {
                        sb.append(tr("Boyut", "Size")).append(": ").append(sizeText(f.length())).append('\n')
                    }
                    sb.append(tr("Değiştirilme", "Modified")).append(": ").append(dateText(f.lastModified())).append('\n')
                    sb.append(tr("Okunabilir", "Readable")).append(": ").append(f.canRead()).append("   ")
                        .append(tr("Yazılabilir", "Writable")).append(": ").append(f.canWrite())
                }
            } catch (t: Throwable) {
                sb.append(t.message ?: "error")
            }
            act.runOnUiThread {
                val tv = TextView(act).apply {
                    text = sb.toString()
                    textSize = 12.5f
                    setTextIsSelectable(true)
                    setTextColor(pal.text)
                    setPadding(dp(20), dp(14), dp(20), dp(14))
                }
                AlertDialog.Builder(act)
                    .setTitle(tr("Bilgi", "Info"))
                    .setView(ScrollView(act).apply { setBackgroundColor(pal.card); addView(tv) })
                    .setPositiveButton(tr("Kapat", "Close"), null)
                    .show()
            }
        }.start()
    }

    private fun gotoDialog() {
        val et = EditText(act).apply {
            setText(cwd)
            setSelection(cwd.length)
            setSingleLine(true)
            setTextColor(pal.text)
        }
        val lay = LinearLayout(act).apply {
            setPadding(dp(22), dp(10), dp(22), 0)
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(act)
            .setTitle(tr("Yola git", "Go to path"))
            .setView(lay)
            .setPositiveButton("OK") { _, _ ->
                val p = et.text.toString().trim().ifEmpty { "/" }
                openDir(p)
            }
            .setNegativeButton(tr("İptal", "Cancel"), null)
            .show()
    }
}


// ──────────────────────────────────────────────────────────────
//  Yardımcı görünümler
// ──────────────────────────────────────────────────────────────

/** Basılınca küçülüp bırakınca yaylanarak geri dönen liste satırı. */
internal class PressRow(ctx: Context) : LinearLayout(ctx) {
    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (!changed) return
        animate().cancel()
        if (pressed) {
            animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
        } else {
            animate().scaleX(1f).scaleY(1f).setDuration(190).setInterpolator(OvershootInterpolator(2.2f)).start()
        }
    }
}

/** Animasyonlu depolama doluluk çubuğu. */
internal class StorageBar(
    ctx: Context,
    private val track: Int,
    private val c1: Int,
    private val c2: Int,
    private val warn: Int,
    private val danger: Int
) : View(ctx) {
    private var frac = -1f
    private var shownF = 0f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun reset() {
        anim?.cancel()
        shownF = 0f
        frac = -1f
        invalidate()
    }

    fun setFraction(f: Float) {
        val t = f.coerceIn(0f, 1f)
        if (kotlin.math.abs(t - frac) < 0.001f) return
        frac = t
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shownF, t).apply {
            duration = 750
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { shownF = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        shownF = frac.coerceAtLeast(0f)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        paint.shader = null
        paint.color = track
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, paint)
        val fw = (w * shownF).coerceAtLeast(if (shownF > 0f) h else 0f)
        if (fw > 0f) {
            val a = if (frac > 0.95f) danger else if (frac > 0.85f) warn else c1
            val b = if (frac > 0.95f) danger else if (frac > 0.85f) warn else c2
            paint.shader = LinearGradient(0f, 0f, fw, 0f, a, b, Shader.TileMode.CLAMP)
            rect.set(0f, 0f, fw, h)
            c.drawRoundRect(rect, r, r, paint)
            paint.shader = null
        }
    }
}
