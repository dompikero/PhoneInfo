package com.eren.phoneinfo

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

// ──────────────────────────────────────────────────────────────
//  Priv — ayrıcalıklı kabuk erişimi (Shizuku veya root)
//  Normal uygulamalara kapalı olan GPU sıcaklığı, /sys/class/thermal,
//  dumpsys thermalservice ve Android/data klasörlerini okumak için.
//  Güvenlik duvarı "aşılmaz": kullanıcı Shizuku iznini ya da root
//  iznini kendisi verir.
// ──────────────────────────────────────────────────────────────
object Priv {
    @Volatile private var rootOk = false
    @Volatile var rootProbed = false
        private set

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestShizuku(): Boolean = try {
        if (Shizuku.pingBinder()) { Shizuku.requestPermission(4242); true } else false
    } catch (_: Throwable) { false }

    fun rootAvailable(): Boolean = rootOk

    /** Arka plan thread'inde çağır: su ile uid=0 kontrolü. */
    fun probeRoot() {
        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val out = StringBuilder()
            val t = Thread {
                try { out.append(p.inputStream.bufferedReader().readText()) } catch (_: Throwable) {}
            }
            t.isDaemon = true
            t.start()
            t.join(6000)
            if (t.isAlive) p.destroy()
            rootOk = out.contains("uid=0")
        } catch (_: Throwable) {
            rootOk = false
        }
        rootProbed = true
    }

    fun ready(): Boolean = shizukuGranted() || rootOk

    fun label(): String = when {
        shizukuGranted() -> "Shizuku (shell)"
        rootOk -> "Root (su)"
        else -> ""
    }

    private fun newShizukuProcess(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    /** Komutu ayrıcalıklı çalıştırır. (çıkış kodu, stdout+stderr) veya erişim yoksa null. */
    fun exec(cmd: String, timeoutMs: Long = 8000L): Pair<Int, String>? {
        val wrapped = "( $cmd ) 2>&1"
        val p: Process = try {
            when {
                shizukuGranted() -> newShizukuProcess(arrayOf("sh", "-c", wrapped))
                rootOk -> Runtime.getRuntime().exec(arrayOf("su", "-c", wrapped))
                else -> return null
            }
        } catch (_: Throwable) { return null }

        val sb = StringBuilder()
        val reader = Thread {
            try {
                p.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(8192)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        synchronized(sb) { if (sb.length < 4_000_000) sb.append(buf, 0, n) }
                    }
                }
            } catch (_: Throwable) {}
        }
        reader.isDaemon = true
        reader.start()
        reader.join(timeoutMs)
        if (reader.isAlive) {
            try { p.destroy() } catch (_: Throwable) {}
            return Pair(-1, synchronized(sb) { sb.toString() })
        }
        val code = try { p.waitFor() } catch (_: Throwable) { 0 }
        return Pair(code, synchronized(sb) { sb.toString() })
    }

    /** Tek tırnaklı kabuk argümanı. */
    fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"
}
