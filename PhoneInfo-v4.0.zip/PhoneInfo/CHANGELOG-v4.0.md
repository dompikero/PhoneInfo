# Changelog — PhoneInfo v4.0

### Added
- Polished first-run language chooser for Turkish and English.
- Broader English UI translations across common diagnostic screens and reports.
- Asynchronous, cached thermal-service fallback scan.

### Fixed
- Do not report an unrelated high-temperature zone as CPU temperature.
- Handle common millidegree/deci-degree sensor formats more consistently.
- Keep thermal names and readings aligned as values change.
- Show an explicit unavailable state when a CPU/GPU sensor cannot be read.

### Updated
- Version name 4.0; version code 5.
- GitHub Actions build artifact: `PhoneInfo-v4.0-apk`.
