package com.eren.phoneinfo

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.res.ColorStateList
import android.content.pm.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.hardware.camera2.*
import android.media.*
import android.net.*
import android.net.wifi.WifiManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.*
import android.os.HardwarePropertiesManager
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.*
import java.util.concurrent.TimeUnit
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

// ──────────────────────────────────────────────────────────────
//  Yardımcılar
// ──────────────────────────────────────────────────────────────
private fun rd(p: String): String? = try { File(p).readText().trim() } catch (e: Throwable) { null }
private fun sh(c: String): String = try { Runtime.getRuntime().exec(arrayOf("sh", "-c", c)).inputStream.bufferedReader().readText().trim() } catch (e: Throwable) { "" }
private fun mhz(s: String?) = s?.toLongOrNull()?.let { "${it / 1000} MHz" } ?: "-"
private fun ip(i: Int) = "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
private fun fmt(b: Long): String { val u = arrayOf("B","KB","MB","GB","TB"); var v = b.toDouble(); var i = 0; while (v >= 1024 && i < 4) { v /= 1024; i++ }; return "%.2f %s".format(v, u[i]) }
private fun dur(ms: Long, lang: String = "tr"): String { val s = ms / 1000; return if (lang == "en") "${s/86400}d ${s/3600%24}h ${s/60%60}m ${s%60}s" else "${s/86400}g ${s/3600%24}s ${s/60%60}dk ${s%60}sn" }

data class Tz(val zone: String, val type: String, val temp: Double)

private fun normalizedTemp(raw: Double): Double? {
    val magnitude = kotlin.math.abs(raw)
    val value = when {
        magnitude >= 10_000.0 -> raw / 1000.0 // millidegrees Celsius
        magnitude > 150.0 -> raw / 10.0       // common deci-degree vendor values
        else -> raw                            // already degrees Celsius
    }
    return value.takeIf { it in -20.0..150.0 }
}

@Volatile private var thermalCacheAt = 0L
@Volatile private var thermalCache: List<Tz> = emptyList()
@Volatile private var thermalHalCacheAt = 0L
@Volatile private var thermalHalCache: List<Tz> = emptyList()
@Volatile private var thermalHalScanRunning = false
private val thermalHalLock = Any()

private fun readThermalServiceZones(): List<Tz> {
    // Some Android builds expose HAL temperatures in dumpsys even when sysfs is hidden.
    // This is best-effort only: third-party apps may be denied access to dumpsys.
    val process = try {
        Runtime.getRuntime().exec(arrayOf("sh", "-c", "dumpsys thermalservice"))
    } catch (_: Throwable) { return emptyList() }
    return try {
        // Process timed waiting is available from Android 8; older versions keep sysfs only.
        if (Build.VERSION.SDK_INT < 26) {
            process.destroy()
            return emptyList()
        }
        if (!process.waitFor(1_500, TimeUnit.MILLISECONDS)) {
            process.destroyForcibly()
            return emptyList()
        }
        val output = process.inputStream.bufferedReader().use { it.readText() }
        if (output.isBlank() || output.contains("Permission Denial", true) || output.contains("not allowed", true)) return emptyList()
        val results = mutableListOf<Tz>()
        output.lineSequence().forEachIndexed { index, line ->
            if (!line.contains("mValue", true)) return@forEachIndexed
            val v = Regex("mValue\\s*=\\s*(-?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                ?: return@forEachIndexed
            val type = Regex("mType\\s*=\\s*(\\d+)", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.toIntOrNull()
            val name = Regex("mName\\s*=\\s*([^,}]+)", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            normalizedTemp(v)?.let { temp ->
                val className = when (type) {
                    0 -> "CPU"
                    1 -> "GPU"
                    2 -> "Battery"
                    else -> name.ifBlank { "Thermal HAL $index" }
                }
                results.add(Tz("thermalservice_${type ?: -1}_$index", "$className${if (name.isNotBlank() && name != className) " · $name" else ""}", temp))
            }
        }
        results
    } catch (_: Throwable) {
        runCatching { process.destroyForcibly() }
        emptyList()
    }
}

@Synchronized private fun readZones(): List<Tz> {
    val now = SystemClock.elapsedRealtime()
    if (thermalCacheAt != 0L && now - thermalCacheAt < 1_200L) return thermalCache

    val list = mutableListOf<Tz>()
    // Android/OEM thermal zones. Access is device-dependent; some builds hide these from apps.
    File("/sys/class/thermal").listFiles()?.forEach { f ->
        if (!f.name.startsWith("thermal_zone")) return@forEach
        val type = rd(f.path + "/type") ?: f.name
        val raw = rd(f.path + "/temp")?.toDoubleOrNull() ?: return@forEach
        normalizedTemp(raw)?.let { list.add(Tz(f.name, type.trim(), it)) }
    }

    // Some vendors publish CPU/GPU thermistors through hwmon.
    File("/sys/class/hwmon").listFiles()?.forEach { hw ->
        val chipName = rd(hw.path + "/name")?.takeIf { it.isNotBlank() } ?: hw.name
        hw.listFiles()?.filter { it.name.matches(Regex("temp\\d+_input")) }?.forEach inputLoop@{ input ->
            val raw = rd(input.path)?.toDoubleOrNull() ?: return@inputLoop
            val suffix = input.name.removeSuffix("_input")
            val label = rd(hw.path + "/${suffix}_label")?.takeIf { it.isNotBlank() }
            normalizedTemp(raw)?.let { list.add(Tz("${hw.name}_${suffix}", label ?: chipName, it)) }
        }
    }

    // Thermal service probing runs in the background so refreshing the UI never waits for dumpsys.
    val halNow = SystemClock.elapsedRealtime()
    if ((thermalHalCacheAt == 0L || halNow - thermalHalCacheAt > 8_000L) && !thermalHalScanRunning) {
        synchronized(thermalHalLock) {
            if (!thermalHalScanRunning && (thermalHalCacheAt == 0L || halNow - thermalHalCacheAt > 8_000L)) {
                thermalHalScanRunning = true
                Thread({
                    try {
                        thermalHalCache = readThermalServiceZones()
                        thermalHalCacheAt = SystemClock.elapsedRealtime()
                    } finally {
                        thermalHalScanRunning = false
                    }
                }, "PhoneInfo-ThermalHAL").apply { isDaemon = true; start() }
            }
        }
    }
    list.addAll(thermalHalCache)
    val fresh = list.distinctBy { "${it.zone}:${it.type}" }
    thermalCache = fresh
    thermalCacheAt = now
    return fresh
}

private fun zoneKind(z: Tz): String {
    val t = (z.type + " " + z.zone).lowercase(Locale.ROOT).replace('-', '_').replace(' ', '_')
    return when {
        listOf("gpu", "g3d", "kgsl", "mali", "adreno", "graphics", "thermalservice_1_").any { t.contains(it) } -> "gpu"
        listOf("batt", "battery", "bms", "fuel_gauge", "thermalservice_2_").any { t.contains(it) } -> "bat"
        listOf("cpu", "soc", "ap_", "tsens", "core", "cluster", "big", "little", "cpuss", "processor", "thermalservice_0_").any { t.contains(it) } -> "cpu"
        else -> "other"
    }
}

private fun extraGpuTemp(): Double? {
    val paths = listOf(
        "/sys/class/kgsl/kgsl-3d0/temp",
        "/sys/class/kgsl/kgsl-3d0/devfreq/temp",
        "/sys/class/misc/mali0/device/temp",
        "/sys/kernel/gpu/gpu_temp",
        "/sys/devices/platform/gpu/temp",
        "/sys/class/devfreq/gpu/temp"
    )
    for (p in paths) {
        val v = rd(p)?.toDoubleOrNull() ?: continue
        normalizedTemp(v)?.let { return it }
    }
    return readZones().filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp
}

private fun thermalStatusLabel(context: Context, lang: String = "tr"): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return if (lang == "en") "Requires API 29+" else "API 29+ gerekli"
    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    return when (pm.currentThermalStatus) {
        PowerManager.THERMAL_STATUS_NONE -> if (lang == "en") "Normal" else "Normal"
        PowerManager.THERMAL_STATUS_LIGHT -> if (lang == "en") "Light" else "Hafif"
        PowerManager.THERMAL_STATUS_MODERATE -> if (lang == "en") "Moderate" else "Orta"
        PowerManager.THERMAL_STATUS_SEVERE -> if (lang == "en") "Severe — throttling may occur" else "Yüksek — performans kısılabilir"
        PowerManager.THERMAL_STATUS_CRITICAL -> if (lang == "en") "Critical" else "Kritik"
        PowerManager.THERMAL_STATUS_EMERGENCY -> if (lang == "en") "Emergency" else "Acil"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> if (lang == "en") "Shutdown level" else "Kapanma seviyesi"
        else -> if (lang == "en") "Unknown" else "Bilinmiyor"
    }
}

// ──────────────────────────────────────────────────────────────
//  Tema paleti
// ──────────────────────────────────────────────────────────────
data class Palette(
    val bg: Int, val card: Int, val card2: Int, val stroke: Int,
    val text: Int, val sub: Int, val accent: Int, val accent2: Int,
    val danger: Int, val warn: Int, val ok: Int
)
private fun palette(dark: Boolean) = if (dark) Palette(
    bg = 0xFF0B0E13.toInt(),
    card = 0xFF151A23.toInt(),
    card2 = 0xFF1C2230.toInt(),
    stroke = 0xFF232B3A.toInt(),
    text = 0xFFE6EDF3.toInt(),
    sub = 0xFF8B949E.toInt(),
    accent = 0xFF4FC3F7.toInt(),
    accent2 = 0xFF7C4DFF.toInt(),
    danger = 0xFFF85149.toInt(),
    warn = 0xFFFFA726.toInt(),
    ok = 0xFF3FB950.toInt()
) else Palette(
    bg = 0xFFF5F7FA.toInt(),
    card = 0xFFFFFFFF.toInt(),
    card2 = 0xFFF0F4F8.toInt(),
    stroke = 0xFFE1E7ED.toInt(),
    text = 0xFF1F2937.toInt(),
    sub = 0xFF6B7280.toInt(),
    accent = 0xFF0288D1.toInt(),
    accent2 = 0xFF5E35B1.toInt(),
    danger = 0xFFD32F2F.toInt(),
    warn = 0xFFF57C00.toInt(),
    ok = 0xFF388E3C.toInt()
)

// ──────────────────────────────────────────────────────────────
//  Dil
// ──────────────────────────────────────────────────────────────
object L {
    private val tr = mapOf(
        "subtitle" to "Cihaz Teşhis Aracı",
        "tab_device" to "Cihaz", "tab_display" to "Ekran", "tab_cpu" to "CPU",
        "tab_battery" to "Pil", "tab_net" to "Ağ", "tab_sensors" to "Sensör",
        "tab_camera" to "Kamera", "tab_features" to "Özellik", "tab_apps" to "Uygulama",
        "tab_codecs" to "Kodek", "tab_security" to "Güvenlik", "tab_thermal" to "Isı",
        "tab_live" to "Canlı", "tab_stress" to "Yük", "tab_tools" to "Araçlar",
        "tab_settings" to "Ayarlar",
        "c_identity" to "Kimlik", "c_software" to "Yazılım", "c_time" to "Zaman",
        "c_resolution" to "Çözünürlük", "c_refresh" to "Yenileme",
        "c_cpu" to "İşlemci", "c_ram" to "Bellek (RAM)", "c_storage" to "Depolama",
        "c_temp" to "Sıcaklık", "c_battery" to "Pil", "c_power" to "Güç",
        "c_network" to "Bağlantı", "c_wifi" to "Wi-Fi", "c_cell" to "Hücresel",
        "c_ifaces" to "Ağ Arayüzleri",
        "st_title" to "Ayarlar",
        "st_appearance" to "Görünüm", "st_dark" to "Karanlık Mod",
        "st_lang" to "Dil", "st_refresh" to "Yenileme Hızı",
        "st_refresh_hint" to "Canlı verilerin güncellenme sıklığı",
        "st_about" to "Hakkında",
        "st_about_body" to "PhoneInfo v4.0\nModern cihaz teşhis aracı.\n\nTermal izleme, CPU/GPU yük testleri, sensör verileri ve çok daha fazlası.",
        "first_lang_title" to "Choose your language",
        "st_cpu" to "İşlemci (CPU)", "st_gpu" to "Grafik (GPU)", "st_bat" to "Pil",
        "st_now" to "Şu an", "st_min" to "Min", "st_max" to "Maks",
        "st_zones" to "Tüm termal bölgeler",
        "st_none" to "Termal sensör bulunamadı.",
        "st_stress_cpu" to "CPU Yük Testi", "st_stress_gpu" to "GPU Yük Testi",
        "st_stress_both" to "Birleşik Yük Testi", "st_stress_stop" to "Durdur",
        "st_stress_dur" to "Süre (saniye)", "st_stress_start" to "Başlat",
        "st_stress_idle" to "Hazır. Bir test başlatın.",
        "st_stress_running" to "Çalışıyor…", "st_stress_done" to "Test tamamlandı",
        "st_stress_threads" to "İş parçacığı", "st_stress_elapsed" to "Geçen süre",
        "st_stress_peak" to "Zirve sıcaklıklar",
        "tools_vib" to "📳 Titreşim", "tools_torch" to "🔦 Fener", "tools_beep" to "🔊 Bip",
        "tools_color" to "🖥 Ölü piksel", "tools_touch" to "👆 Çoklu dokunma",
        "tools_cpubench" to "⚡ CPU Benchmark", "tools_disk" to "💾 Depo Hızı",
        "tools_settings" to "⚙ Sistem Ayarları", "tools_copy" to "📋 Raporu Kopyala",
        "tools_share" to "📤 Raporu Paylaş", "tools_brightness" to "Parlaklık"
    )
    private val en = mapOf(
        "subtitle" to "Device Diagnostics Suite",
        "tab_device" to "Device", "tab_display" to "Display", "tab_cpu" to "CPU",
        "tab_battery" to "Battery", "tab_net" to "Network", "tab_sensors" to "Sensors",
        "tab_camera" to "Camera", "tab_features" to "Features", "tab_apps" to "Apps",
        "tab_codecs" to "Codecs", "tab_security" to "Security", "tab_thermal" to "Thermal",
        "tab_live" to "Live", "tab_stress" to "Stress", "tab_tools" to "Tools",
        "tab_settings" to "Settings",
        "c_identity" to "Identity", "c_software" to "Software", "c_time" to "Time",
        "c_resolution" to "Resolution", "c_refresh" to "Refresh",
        "c_cpu" to "Processor", "c_ram" to "Memory (RAM)", "c_storage" to "Storage",
        "c_temp" to "Temperature", "c_battery" to "Battery", "c_power" to "Power",
        "c_network" to "Connection", "c_wifi" to "Wi-Fi", "c_cell" to "Cellular",
        "c_ifaces" to "Network Interfaces",
        "st_title" to "Settings",
        "st_appearance" to "Appearance", "st_dark" to "Dark Mode",
        "st_lang" to "Language", "st_refresh" to "Refresh Rate",
        "st_refresh_hint" to "How often live values update",
        "st_about" to "About",
        "st_about_body" to "PhoneInfo v4.0\nModern device diagnostics tool.\n\nThermal monitor, CPU/GPU stress tests, sensor data and much more.",
        "first_lang_title" to "Choose your language",
        "st_cpu" to "CPU", "st_gpu" to "GPU", "st_bat" to "Battery",
        "st_now" to "Now", "st_min" to "Min", "st_max" to "Max",
        "st_zones" to "All thermal zones",
        "st_none" to "No readable thermal sensor was exposed by this device.",
        "st_stress_cpu" to "CPU Stress Test", "st_stress_gpu" to "GPU Stress Test",
        "st_stress_both" to "Combined Stress Test", "st_stress_stop" to "Stop",
        "st_stress_dur" to "Duration (seconds)", "st_stress_start" to "Start",
        "st_stress_idle" to "Ready. Start a test.",
        "st_stress_running" to "Running…", "st_stress_done" to "Test complete",
        "st_stress_threads" to "Threads", "st_stress_elapsed" to "Elapsed",
        "st_stress_peak" to "Peak temperatures",
        "tools_vib" to "📳 Vibrate", "tools_torch" to "🔦 Torch", "tools_beep" to "🔊 Beep",
        "tools_color" to "🖥 Dead Pixel", "tools_touch" to "👆 Multi-touch",
        "tools_cpubench" to "⚡ CPU Benchmark", "tools_disk" to "💾 Storage Speed",
        "tools_settings" to "⚙ System Settings", "tools_copy" to "📋 Copy Report",
        "tools_share" to "📤 Share Report", "tools_brightness" to "Brightness"
    )
    fun get(lang: String, k: String): String = (if (lang == "en") en else tr)[k] ?: k
}

// English fallback for legacy labels that were originally written inline.
// Device-provided identifiers and values are intentionally kept unchanged.
private val inlineEnglish = mapOf(
    "Üretici" to "Manufacturer", "Marka" to "Brand", "Cihaz kodu" to "Device code", "Ürün" to "Product",
    "Kart" to "Board", "Donanım" to "Hardware", "Güvenlik yaması" to "Security patch", "Çekirdek" to "Kernel",
    "Açık kalma" to "Uptime", "Şu an" to "Current time", "Gerçek" to "Physical", "Uygulama" to "Application",
    "Yoğunluk" to "Density", "xdpi / ydpi" to "xdpi / ydpi", "Ekran boyutu" to "Screen size", "Font ölçeği" to "Font scale",
    "Geniş renk gamı" to "Wide color gamut", "Düşük RAM cihazı" to "Low-RAM device", "Teknoloji" to "Technology",
    "Durum" to "Status", "Sağlık" to "Health", "Pil tasarrufu" to "Battery saver", "Ekran" to "Display",
    "Tür" to "Type", "İndirme" to "Download", "Yükleme" to "Upload", "İnternet" to "Internet",
    "Doğrulanmış" to "Validated", "Sınırsız" to "Unmetered", "Arayüz" to "Interface", "DNS" to "DNS",
    "Hata" to "Error", "Operatör" to "Carrier", "SIM" to "SIM", "Ülke" to "Country", "Roaming" to "Roaming",
    "Hız" to "Speed", "Frekans" to "Frequency", "Sinyal" to "Signal", "Diyafram" to "Aperture",
    "Hücresel" to "Cellular", "inç" to "in", "Kullanılabilir" to "Available",
    "Birleşik" to "Combined", "Hazır" to "Ready", "Çalışıyor" to "Running", "Durduruldu" to "Stopped", "Başarılı" to "Successful",
    "Yonga seti" to "Chipset", "Sistem" to "System", "Kimlik" to "Identity",
    "İşletim sistemi" to "Operating system", "Saat" to "Clock", "Boş alan" to "Free space",
    "Yön" to "Facing", "Yönlendirme" to "Orientation", "Donanım seviyesi" to "Hardware level", "Odak uzaklığı" to "Focal length",
    "Çözünürlük" to "Resolution", "Flaş" to "Flash", "Kullanıcı" to "User", "Örnekleme" to "Sample rate",
    "Tampon" to "Buffer", "Medya ses" to "Media volume", "Root izi" to "Root indicators", "Emülatör" to "Emulator",
    "Ekran kilidi" to "Screen lock", "USB hata ayıklama" to "USB debugging", "Geliştirici seçenekleri" to "Developer options",
    "Şifreleme" to "Encryption", "Saat dilimi" to "Time zone", "Dil" to "Language", "Online" to "Online",
    "Toplam" to "Total", "Mod" to "Mode", "Mimari" to "Architecture", "HDR" to "HDR", "Açık" to "On", "Kapalı" to "Off",
    "Yok" to "No", "Erişilemiyor" to "Unavailable", "Var" to "Yes", "VAR!" to "DETECTED!", "EVET" to "YES", "hayır" to "No", "Evet" to "Yes",
    "Hayır" to "No", "açık" to "on", "kapalı" to "off", "AÇIK" to "ON", "İyi" to "Good", "Şarj oluyor" to "Charging",
    "Boşalıyor" to "Discharging", "Şarj olmuyor" to "Not charging", "Dolu" to "Full", "Aşırı ısınmış" to "Overheated",
    "Ölü" to "Dead", "Aşırı voltaj" to "Over-voltage", "Soğuk" to "Cold", "Normal" to "Normal",
    "Kamera" to "Camera", "Ön" to "Front", "Arka" to "Rear", "Harici" to "External",
    "Sensörler" to "Sensors", "Özellikler" to "Features", "Medya Kodekleri" to "Media codecs", "Ses" to "Audio",
    "Güvenlik" to "Security", "Şarj / Akım" to "Charging / Current", "Uygulama Özeti" to "App summary",
    "Kullanıcı Uygulamaları" to "User apps", "Anlık" to "Current", "Kullanılan" to "Used", "Boş" to "Free",
    "Doluluk" to "Usage", "Heap" to "Heap", "Dahili (kullanılan)" to "Internal (used)", "Dahili (boş)" to "Internal (free)",
    "Harici (boş)" to "External (free)", "Seviye" to "Level", "Sıcaklık" to "Temperature", "Voltaj" to "Voltage",
    "Anlık akım" to "Current", "Ortalama akım" to "Average current", "Şarj sayacı" to "Charge counter",
    "Gerçek zaman" to "Real-time", "Bağlantı yok" to "No connection", "Yüksek" to "High", "Orta" to "Moderate",
    "Hafif" to "Light", "Kritik" to "Critical", "Bilinmiyor" to "Unknown", "Kapanma seviyesi" to "Shutdown level",
    "Ağ" to "Network", "Pil" to "Battery", "İşlemci" to "Processor", "Bellek" to "Memory", "Depolama" to "Storage"
)

private fun inlineUiText(value: String, lang: String): String {
    if (lang != "en") return value
    inlineEnglish[value]?.let { return it }
    var output = value
    // Translate known Turkish words/phrases in combined strings without touching parts of model names.
    inlineEnglish.keys.sortedByDescending { it.length }.forEach { source ->
        val translated = inlineEnglish[source] ?: return@forEach
        if (source == translated || source.isBlank()) return@forEach
        val token = Regex("(?<![\\p{L}\\p{N}])${Regex.escape(source)}(?![\\p{L}\\p{N}])", setOf(RegexOption.IGNORE_CASE))
        output = token.replace(output) { translated }
    }
    if (output.startsWith("Sensörler (")) output = output.replaceFirst("Sensörler", "Sensors")
    if (output.startsWith("Özellikler (")) output = output.replaceFirst("Özellikler", "Features")
    if (output.startsWith("Kamera ")) output = output.replaceFirst("Kamera", "Camera")
    if (output.startsWith("Mod ")) output = output.replaceFirst("Mod ", "Mode ")
    if (output.startsWith("Hata: ")) output = output.replaceFirst("Hata:", "Error:")
    // Text dumps usually contain one label per line; translate a label before its colon.
    return output.lines().joinToString("\n") { line ->
        val colon = line.indexOf(':')
        if (colon > 0) {
            val rawKey = line.substring(0, colon).trim()
            val key = inlineEnglish[rawKey]
            if (key != null) line.replaceFirst(rawKey, key) else line
        } else inlineEnglish[line.trim()] ?: line
    }
}

// ──────────────────────────────────────────────────────────────
//  MainActivity
// ──────────────────────────────────────────────────────────────
@Suppress("DEPRECATION", "MissingPermission", "HardwareIds", "NewApi")
class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private var lang = "tr"
    private var dark = true
    private var refreshMs = 500L
    private lateinit var pal: Palette

    private lateinit var sm: SensorManager
    private lateinit var content: LinearLayout
    private lateinit var tabRow: LinearLayout
    private val tabViews = linkedMapOf<String, TextView>()

    private var current = ""
    private val liveUpdaters = mutableListOf<() -> Unit>()
    private val ticker = Handler(Looper.getMainLooper())
    private var ticking = false

    private var torch = false
    private val liveVals = LinkedHashMap<String, String>()
    private var lastUi = 0L

    @Volatile private var stressRunning = false
    private val stressThreads = mutableListOf<Thread>()
    private var stressStart = 0L
    private var stressMode = ""
    private var stressStatus: TextView? = null
    private var stressGpuView: GpuStressView? = null
    private var stressProgress: ProgressBar? = null
    private var stressUpdater: Runnable? = null
    private var selectedStressSeconds = 60
    private var selectedStressIntensity = 0.75f
    private var stressCpuPeak: Double? = null
    private var stressGpuPeak: Double? = null
    private var stressBatteryPeak: Double? = null
    @Volatile private var gpuError: String? = null
    @Volatile private var cpuSink = 0.0

    private fun s(k: String) = L.get(lang, k)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Volatile private var hwThermalCacheAt = 0L
    @Volatile private var hwThermalCache: List<Tz> = emptyList()
    @Volatile private var hwThermalScanRunning = false
    private val hwThermalLock = Any()

    private fun thermalZones(): List<Tz> {
        val now = SystemClock.elapsedRealtime()
        if (Build.VERSION.SDK_INT >= 24 && (hwThermalCacheAt == 0L || now - hwThermalCacheAt > 8_000L) && !hwThermalScanRunning) {
            synchronized(hwThermalLock) {
                if (!hwThermalScanRunning && (hwThermalCacheAt == 0L || now - hwThermalCacheAt > 8_000L)) {
                    hwThermalScanRunning = true
                    Thread({
                        try {
                            val manager = applicationContext.getSystemService(Context.HARDWARE_PROPERTIES_SERVICE) as? HardwarePropertiesManager
                            val found = mutableListOf<Tz>()
                            if (manager != null) {
                                val sources = listOf(
                                    HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU to "CPU",
                                    HardwarePropertiesManager.DEVICE_TEMPERATURE_GPU to "GPU",
                                    HardwarePropertiesManager.DEVICE_TEMPERATURE_BATTERY to "Battery"
                                )
                                sources.forEach { (type, label) ->
                                    try {
                                        manager.getDeviceTemperatures(type, HardwarePropertiesManager.TEMPERATURE_CURRENT)
                                            .forEachIndexed { index, value ->
                                                if (value.isFinite() && value in -20f..150f) {
                                                    found.add(Tz("hardwareproperties_${label.lowercase(Locale.ROOT)}_$index", "$label #${index + 1}", value.toDouble()))
                                                }
                                            }
                                    } catch (_: SecurityException) {
                                        // Android limits this API to privileged/device-owner contexts on many builds.
                                    } catch (_: Throwable) { }
                                }
                            }
                            hwThermalCache = found
                        } catch (_: Throwable) {
                            hwThermalCache = emptyList()
                        } finally {
                            hwThermalCacheAt = SystemClock.elapsedRealtime()
                            hwThermalScanRunning = false
                        }
                    }, "PhoneInfo-HardwareThermals").apply { isDaemon = true; start() }
                }
            }
        }
        return (readZones() + hwThermalCache).distinctBy { "${it.zone}:${it.type}" }
    }

    // ──────────────────────────────────────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("phoneinfo", MODE_PRIVATE)
        lang = prefs.getString("lang", "") ?: ""
        dark = prefs.getBoolean("dark", true)
        refreshMs = prefs.getLong("refresh", 500L)
        pal = palette(dark)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        if (lang.isEmpty() || !prefs.getBoolean("language_picker_v4_shown", false)) askLanguageFirst() else buildUi()
    }

    override fun onPause() {
        if (stressRunning) stopStress(if (lang == "en") "Test stopped because the app went to the background." else "Uygulama arka plana geçtiği için test durduruldu.")
        stressGpuView?.setLoadEnabled(false, selectedStressIntensity)
        stressGpuView?.onPause()
        super.onPause()
        stopTicker()
        sm.unregisterListener(this)
    }

    override fun onResume() {
        super.onResume()
        stressGpuView?.onResume()
        startTicker()
        if (current == "live") startLiveSensors()
    }

    override fun onDestroy() {
        stopStress(null)
        stressGpuView?.onPause()
        stressGpuView = null
        super.onDestroy()
    }

    private fun askLanguageFirst() {
        val dialog = Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(20))
            background = GradientDrawable().apply {
                setColor(pal.card)
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), pal.stroke)
            }
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.accent, pal.accent2)).apply {
                cornerRadius = dp(22).toFloat()
            }
            setPadding(dp(18), dp(24), dp(18), dp(24))
        }
        hero.addView(TextView(this).apply {
            text = "📱"
            textSize = 34f
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = "Welcome to PhoneInfo"
            textSize = 22f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(4))
        })
        hero.addView(TextView(this).apply {
            text = "Choose your language / Dilini seç"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xEFFFFFFF.toInt())
        })
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        root.addView(TextView(this).apply {
            text = "The app will remember your choice. / Seçimin kaydedilecek."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(pal.sub)
            setPadding(0, 0, 0, dp(14))
        })

        fun option(flag: String, title: String, subtitle: String, code: String) {
            val surface = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(15), dp(14), dp(15), dp(14))
                background = GradientDrawable().apply {
                    setColor(pal.card2)
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), pal.stroke)
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    lang = code
                    prefs.edit().putString("lang", code).putBoolean("language_picker_v4_shown", true).apply()
                    dialog.dismiss()
                    buildUi()
                }
            }
            surface.addView(TextView(this).apply {
                text = flag
                textSize = 27f
                setPadding(0, 0, dp(13), 0)
            })
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            labels.addView(TextView(this).apply {
                text = title
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(pal.text)
            })
            labels.addView(TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(pal.sub)
                setPadding(0, dp(3), 0, 0)
            })
            surface.addView(labels)
            surface.addView(TextView(this).apply {
                text = "›"
                textSize = 28f
                setTextColor(pal.accent)
            })
            root.addView(surface, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        option("🇹🇷", "Türkçe", "Tüm menüler Türkçe", "tr")
        option("🇬🇧", "English", "Use PhoneInfo in English", "en")

        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.window?.let { window ->
            window.setBackgroundDrawableResource(android.R.color.transparent)
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.attributes = window.attributes.apply { dimAmount = 0.58f }
            window.setLayout((resources.displayMetrics.widthPixels - dp(32)).coerceAtMost(dp(440)), WindowManager.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(32)).coerceAtMost(dp(440)), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    // ──────────────────────────────────────────────────────────
    //  UI iskeleti
    // ──────────────────────────────────────────────────────────
    private fun buildUi() {
        pal = palette(dark)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        // Gradient header
        root.addView(buildHeader())

        // Sekmeler
        tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        })

        // İçerik
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(40))
        }
        root.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 23) {
            val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= 31) p.add("android.permission.BLUETOOTH_CONNECT")
            requestPermissions(p.toTypedArray(), 1)
        }

        buildTabs()
        selectTab("device")
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                pal.accent, pal.accent2
            )).apply {
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat())
            }
            setPadding(dp(22), dp(42), dp(22), dp(22))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = "🔍"; textSize = 34f
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(TextView(this).apply {
            text = "PhoneInfo"; textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        col.addView(TextView(this).apply {
            text = s("subtitle"); textSize = 12f
            setTextColor(0xCCFFFFFF.toInt())
        })
        row.addView(col)
        row.addView(TextView(this).apply {
            text = "⚙"; textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { selectTab("settings") }
        })
        h.addView(row)
        val badge = TextView(this).apply {
            text = "● DEVICE INTELLIGENCE   •   v4.0"
            textSize = 10f
            letterSpacing = 0.06f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xDFFFFFFF.toInt())
            setPadding(dp(2), dp(12), 0, 0)
        }
        h.addView(badge)
        h.alpha = 0f
        h.translationY = dp(-8).toFloat()
        h.animate().alpha(1f).translationY(0f).setDuration(360).start()
        return h
    }

    private fun buildTabs() {
        val tabs = listOf(
            "device" to "⚙ " + s("tab_device"),
            "display" to "🖥 " + s("tab_display"),
            "cpu" to "⚡ " + s("tab_cpu"),
            "battery" to "🔋 " + s("tab_battery"),
            "net" to "📶 " + s("tab_net"),
            "sensors" to "📡 " + s("tab_sensors"),
            "camera" to "📷 " + s("tab_camera"),
            "features" to "✨ " + s("tab_features"),
            "apps" to "📱 " + s("tab_apps"),
            "codecs" to "🎬 " + s("tab_codecs"),
            "security" to "🔒 " + s("tab_security"),
            "thermal" to "🌡 " + s("tab_thermal"),
            "live" to "📊 " + s("tab_live"),
            "stress" to "🔥 " + s("tab_stress"),
            "tools" to "🧪 " + s("tab_tools"),
            "settings" to "⚙ " + s("tab_settings")
        )
        tabViews.clear()
        tabRow.removeAllViews()
        tabs.forEach { (key, label) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setTextColor(pal.text)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = chipBg(false)
                setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); selectTab(key) }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }
            }
            tabViews[key] = tv
            tabRow.addView(tv)
        }
    }

    private fun chipBg(selected: Boolean) = if (selected) {
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.accent, pal.accent2)).apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), pal.accent)
        }
    } else {
        GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(pal.card)
            setStroke(dp(1), pal.stroke)
        }
    }

    private fun selectTab(key: String) {
        if (current == "stress" && key != "stress") {
            if (stressRunning) stopStress(if (lang == "en") "Test stopped after changing tabs." else "Sekme değiştirildiği için test durduruldu.")
            stressGpuView?.setLoadEnabled(false, selectedStressIntensity)
            stressGpuView?.onPause()
            stressGpuView = null
        }
        current = key
        liveUpdaters.clear()
        tabViews.forEach { (k, v) ->
            val sel = k == key
            v.background = chipBg(sel)
            v.setTextColor(if (sel) Color.WHITE else pal.text)
            v.animate().cancel()
            v.animate().scaleX(if (sel) 1.04f else 1f).scaleY(if (sel) 1.04f else 1f)
                .setDuration(150).start()
            if (sel) v.elevation = dp(4).toFloat() else v.elevation = 0f
        }
        if (key != "live") sm.unregisterListener(this)
        content.animate().cancel()
        content.animate().alpha(0.12f).translationY(dp(8).toFloat()).setDuration(80)
            .withEndAction {
                if (current != key || isFinishing) return@withEndAction
                content.removeAllViews()
                when (key) {
                    "device" -> renderDevice()
                    "display" -> renderDisplay()
                    "cpu" -> renderCpu()
                    "battery" -> renderBattery()
                    "net" -> renderNetwork()
                    "sensors" -> renderSensors()
                    "camera" -> renderCamera()
                    "features" -> renderFeatures()
                    "apps" -> renderApps()
                    "codecs" -> renderCodecs()
                    "security" -> renderSecurity()
                    "thermal" -> renderThermal()
                    "live" -> renderLive()
                    "stress" -> renderStress()
                    "tools" -> renderTools()
                    "settings" -> renderSettings()
                }
                content.alpha = 0f
                content.translationY = dp(10).toFloat()
                content.animate().alpha(1f).translationY(0f).setDuration(210).start()
            }.start()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        selectTab(current)
    }

    // ──────────────────────────────────────────────────────────
    //  Ticker (canlı güncelleme)
    // ──────────────────────────────────────────────────────────
    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!ticking) return
            for (f in liveUpdaters.toList()) runCatching { f() }
            ticker.postDelayed(this, refreshMs)
        }
    }
    private fun startTicker() { if (!ticking) { ticking = true; ticker.post(tickRunnable) } }
    private fun stopTicker() { ticking = false; ticker.removeCallbacks(tickRunnable) }

    // ──────────────────────────────────────────────────────────
    //  Kart yapıcıları
    // ──────────────────────────────────────────────────────────
    private fun makeCard(title: String, emoji: String = ""): Card {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.card, pal.card2)).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(18), dp(16), dp(18), dp(16))
            elevation = dp(2).toFloat()
            alpha = 0f
            translationY = dp(12).toFloat()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (emoji.isNotEmpty()) {
            titleRow.addView(TextView(this).apply {
                text = emoji; textSize = 18f
                setPadding(0, 0, dp(10), 0)
            })
        }
        val titleTv = TextView(this).apply {
            text = inlineUiText(title, lang); textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(pal.text)
        }
        titleRow.addView(titleTv)
        card.addView(titleRow)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        card.addView(body)
        content.addView(card)
        val delay = ((content.childCount - 1) * 24L).coerceAtMost(180L)
        card.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(220).start()
        return Card(body)
    }

    inner class Card(val body: LinearLayout) {
        fun row(k: String, v: String, color: Int? = null): Card {
            val r = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            r.addView(TextView(this@MainActivity).apply {
                text = inlineUiText(k, lang); textSize = 13f
                setTextColor(pal.sub)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            r.addView(TextView(this@MainActivity).apply {
                text = inlineUiText(v, lang); textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(color ?: pal.text)
            })
            body.addView(r)
            return this
        }
        fun rowLive(k: String, initial: String): Pair<TextView, Card> {
            val r = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            r.addView(TextView(this@MainActivity).apply {
                text = inlineUiText(k, lang); textSize = 13f
                setTextColor(pal.sub)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            val tv = TextView(this@MainActivity).apply {
                text = inlineUiText(initial, lang); textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(pal.text)
            }
            r.addView(tv)
            body.addView(r)
            return tv to this
        }
        fun text(t: String): Card {
            body.addView(TextView(this@MainActivity).apply {
                text = inlineUiText(t, lang)
                textSize = 11.5f
                typeface = Typeface.MONOSPACE
                setTextColor(pal.text)
                setTextIsSelectable(true)
            })
            return this
        }
        fun custom(f: (LinearLayout) -> Unit): Card { f(body); return this }
    }

    private fun statCard(parent: LinearLayout, label: String, initial: String, accent: Int): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.card2, pal.card)).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), pal.stroke)
            }
            elevation = dp(1).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginEnd = dp(6); marginStart = dp(6)
                bottomMargin = dp(10)
            }
        }
        card.addView(TextView(this).apply {
            text = inlineUiText(label, lang); textSize = 11f
            setTextColor(pal.sub)
            setTypeface(null, Typeface.BOLD)
        })
        val tv = TextView(this).apply {
            text = initial; textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(accent)
            setPadding(0, dp(6), 0, 0)
        }
        card.addView(tv)
        parent.addView(card)
        return tv
    }

    private fun statRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(4); bottomMargin = dp(4)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Cihaz
    // ──────────────────────────────────────────────────────────
    private fun renderDevice() {
        val quick = statRow()
        val coresQuick = statCard(quick, if (lang == "en") "CPU CORES" else "CPU ÇEKİRDEK", Runtime.getRuntime().availableProcessors().toString(), pal.accent)
        val batteryQuick = statCard(quick, if (lang == "en") "BATTERY" else "PİL", "—", pal.ok)
        val tempQuick = statCard(quick, if (lang == "en") "BATTERY TEMP" else "PİL SICAKLIĞI", "—", pal.warn)
        content.addView(quick, 0)
        liveUpdaters.add {
            val batt = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = if (batt != null) batt.getIntExtra("level", 0) * 100 / batt.getIntExtra("scale", 100).coerceAtLeast(1) else -1
            batteryQuick.text = if (level >= 0) "$level%" else "—"
            batteryQuick.setTextColor(when { level >= 40 -> pal.ok; level >= 15 -> pal.warn; else -> pal.danger })
            val temp = batteryTemp()
            tempQuick.text = temp?.let { "%.1f°".format(it) } ?: if (lang == "en") "N/A" else "Yok"
            tempQuick.setTextColor(temp?.let { tempColor(it) } ?: pal.sub)
        }

        val c1 = makeCard(s("c_identity"), "📱")
        c1.row("Üretici", Build.MANUFACTURER)
            .row("Marka", Build.BRAND)
            .row("Model", Build.MODEL)
            .row("Cihaz kodu", Build.DEVICE)
            .row("Ürün", Build.PRODUCT)
            .row("Kart", Build.BOARD)
            .row("Donanım", Build.HARDWARE)
        if (Build.VERSION.SDK_INT >= 31) {
            c1.row("SoC", Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL)
        }
        c1.row("Android ID", (Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "-").take(16) + "…")

        val c2 = makeCard(s("c_software"), "🤖")
        c2.row("Android", Build.VERSION.RELEASE)
            .row("API", Build.VERSION.SDK_INT.toString())
            .row("Güvenlik yaması", Build.VERSION.SECURITY_PATCH)
            .row("Build ID", Build.ID)
            .row("Fingerprint", Build.FINGERPRINT.take(24) + "…")
            .row("Bootloader", Build.BOOTLOADER)
            .row("Çekirdek", System.getProperty("os.version") ?: "-")
            .row("ABI", Build.SUPPORTED_ABIS.joinToString(", "))

        val c3 = makeCard(s("c_time"), "⏱")
        c3.row("Dil", Locale.getDefault().toString())
            .row("Saat dilimi", TimeZone.getDefault().id)
            .row("Açık kalma", dur(SystemClock.elapsedRealtime(), lang))
            .row("Şu an", java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ekran
    // ──────────────────────────────────────────────────────────
    private fun renderDisplay() {
        val d = windowManager.defaultDisplay
        val dm = DisplayMetrics(); d.getRealMetrics(dm)
        val ap = resources.displayMetrics
        val diag = sqrt(((dm.widthPixels / dm.xdpi).toDouble().let { it * it }) + ((dm.heightPixels / dm.ydpi).toDouble().let { it * it }))

        val c1 = makeCard(s("c_resolution"), "🖥")
        c1.row("Gerçek", "${dm.widthPixels} × ${dm.heightPixels}")
            .row("Uygulama", "${ap.widthPixels} × ${ap.heightPixels}")
            .row("Yoğunluk", "${dm.densityDpi} dpi")
            .row("xdpi / ydpi", "%.1f / %.1f".format(dm.xdpi, dm.ydpi))
            .row("Ekran boyutu", "%.2f inç".format(diag))
            .row("Font ölçeği", resources.configuration.fontScale.toString())
            .row("Geniş renk gamı", if (resources.configuration.isScreenWideColorGamut) "✓" else "✗")
            .row("HDR", if (resources.configuration.isScreenHdr) "✓" else "✗")

        val c2 = makeCard(s("c_refresh"), "🔄")
        val (refTv, _) = c2.rowLive("Anlık", "%.0f Hz".format(d.refreshRate))
        d.supportedModes.forEach { m ->
            c2.row("Mod ${m.modeId}", "${m.physicalWidth}×${m.physicalHeight} @ %.1f Hz".format(m.refreshRate))
        }
        liveUpdaters.add {
            val r = windowManager.defaultDisplay.refreshRate
            refTv.text = "%.0f Hz".format(r)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: CPU (canlı kart bazlı)
    // ──────────────────────────────────────────────────────────
    private fun renderCpu() {
        val n = Runtime.getRuntime().availableProcessors()

        // CPU kart
        val cCpu = makeCard(s("c_cpu"), "⚡")
        cCpu.row(if (lang == "en") "Cores" else "Çekirdek", n.toString())
            .row("Mimari", System.getProperty("os.arch") ?: "-")
            .row("Online", rd("/sys/devices/system/cpu/online") ?: "-")
        val cpuRows = mutableListOf<Pair<Int, TextView>>()
        for (i in 0 until n) {
            val (tv, _) = cCpu.rowLive("CPU$i", "…")
            cpuRows.add(i to tv)
        }

        // RAM kart
        val cRam = makeCard(s("c_ram"), "💾")
        val (ramUsedTv, _) = cRam.rowLive("Kullanılan", "…")
        val (ramFreeTv, _) = cRam.rowLive("Boş", "…")
        val (ramPctTv, _) = cRam.rowLive("Doluluk", "…")
        val (heapTv, _) = cRam.rowLive("Heap", "…")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        cRam.row("Toplam", fmt((ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }).totalMem))
        cRam.row("Düşük RAM cihazı", if (am.isLowRamDevice) "✓" else "✗")
        heapTv.text = "${am.memoryClass} MB"

        // Depolama kart
        val cSt = makeCard(s("c_storage"), "📦")
        val dataPath = Environment.getDataDirectory().path
        val extPath = Environment.getExternalStorageDirectory().path
        val (stDataTv, _) = cSt.rowLive("Dahili (kullanılan)", "…")
        val (stDataFree, _) = cSt.rowLive("Dahili (boş)", "…")
        val (stExtTv, _) = cSt.rowLive("Harici (boş)", "…")

        // Termal özet kart
        val cTemp = makeCard(s("c_temp"), "🌡")
        val (tCpuTv, _) = cTemp.rowLive(s("st_cpu"), "…")
        val (tGpuTv, _) = cTemp.rowLive(s("st_gpu"), "…")
        val (tBatTv, _) = cTemp.rowLive(s("st_bat"), "…")

        liveUpdaters.add {
            // CPU
            for ((i, tv) in cpuRows) {
                val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
                val cur = mhz(rd(b + "scaling_cur_freq"))
                val max = mhz(rd(b + "cpuinfo_max_freq"))
                val gov = rd(b + "scaling_governor") ?: ""
                tv.text = "$cur / $max  ($gov)"
            }
            // RAM
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            val used = mi.totalMem - mi.availMem
            val pct = used.toDouble() / mi.totalMem * 100
            ramUsedTv.text = fmt(used)
            ramFreeTv.text = fmt(mi.availMem)
            ramPctTv.text = "%.1f%%".format(pct)
            ramPctTv.setTextColor(when {
                pct < 70 -> pal.ok; pct < 88 -> pal.warn; else -> pal.danger
            })
            // Storage
            val s = android.os.StatFs(dataPath)
            val usedD = s.totalBytes - s.availableBytes
            stDataTv.text = fmt(usedD)
            stDataFree.text = fmt(s.availableBytes)
            val s2 = android.os.StatFs(extPath)
            stExtTv.text = fmt(s2.availableBytes)
            // Thermal
            val zones = thermalZones()
            val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
            val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
            val batT = batteryTemp()
            fun set(tv: TextView, t: Double?) {
                tv.text = t?.let { "%.1f °C".format(it) } ?: if (lang == "en") "Unavailable" else "Erişilemiyor"
                tv.setTextColor(t?.let { tempColor(it) } ?: pal.sub)
            }
            set(tCpuTv, cpuT)
            set(tGpuTv, gpuT)
            set(tBatTv, batT)
        }
    }

    private fun tempColor(t: Double) = when {
        t < 45 -> pal.ok
        t < 60 -> 0xFFCDDC39.toInt()
        t < 75 -> pal.warn
        else -> pal.danger
    }

    private fun batteryTemp(): Double? = try {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i?.getIntExtra("temperature", 0)?.div(10.0)?.takeIf { it > 0.0 }
    } catch (e: Throwable) { null }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Pil
    // ──────────────────────────────────────────────────────────
    private fun renderBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val sc = i?.getIntExtra("scale", 100) ?: 100

        val c1 = makeCard(s("c_battery"), "🔋")
        val (lvlTv, _) = c1.rowLive("Seviye", "…")
        val (tempTv, _) = c1.rowLive("Sıcaklık", "…")
        val (voltTv, _) = c1.rowLive("Voltaj", "…")
        c1.row("Teknoloji", i?.getStringExtra("technology") ?: "-")

        val c2 = makeCard("Şarj / Akım", "⚡")
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val (curTv, _) = c2.rowLive("Anlık akım", "…")
        val (avgTv, _) = c2.rowLive("Ortalama akım", "…")
        val (counterTv, _) = c2.rowLive("Şarj sayacı", "…")
        c2.row("Durum", mapOf(2 to "Şarj oluyor", 3 to "Boşalıyor", 4 to "Şarj olmuyor", 5 to "Dolu")
            .getOrDefault(i?.getIntExtra("status", 1) ?: 1, "?"))
            .row("Sağlık", mapOf(2 to "İyi", 3 to "Aşırı ısınmış", 4 to "Ölü", 5 to "Aşırı voltaj", 6 to "Hata", 7 to "Soğuk")
                .getOrDefault(i?.getIntExtra("health", 1) ?: 1, "?"))

        val c3 = makeCard(s("c_power"), "🔌")
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        c3.row("Pil tasarrufu", if (pm.isPowerSaveMode) "AÇIK" else "kapalı")
            .row("Ekran", if (pm.isInteractive) "açık" else "kapalı")

        liveUpdaters.add {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return@add
            val lvl = b.getIntExtra("level", -1) * 100 / (b.getIntExtra("scale", 100))
            lvlTv.text = "$lvl%"
            lvlTv.setTextColor(when { lvl > 40 -> pal.ok; lvl > 15 -> pal.warn; else -> pal.danger })
            val t = b.getIntExtra("temperature", 0) / 10.0
            tempTv.text = "%.1f °C".format(t)
            tempTv.setTextColor(tempColor(t))
            voltTv.text = "${b.getIntExtra("voltage", 0)} mV"
            val c = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000
            curTv.text = "$c mA"
            avgTv.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) / 1000} mA"
            counterTv.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000} mAh"
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ağ
    // ──────────────────────────────────────────────────────────
    private fun renderNetwork() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork

        val c1 = makeCard(s("c_network"), "📶")
        if (n == null) c1.row("Durum", "Bağlantı yok")
        else {
            cm.getNetworkCapabilities(n)?.let { c ->
                val transports = listOf(
                    NetworkCapabilities.TRANSPORT_WIFI to "Wi-Fi",
                    NetworkCapabilities.TRANSPORT_CELLULAR to "Hücresel",
                    NetworkCapabilities.TRANSPORT_BLUETOOTH to "Bluetooth",
                    NetworkCapabilities.TRANSPORT_ETHERNET to "Ethernet",
                    NetworkCapabilities.TRANSPORT_VPN to "VPN"
                ).filter { c.hasTransport(it.first) }.joinToString { it.second }
                c1.row("Tür", transports)
                    .row("İndirme", "${c.linkDownstreamBandwidthKbps / 1000} Mbps")
                    .row("Yükleme", "${c.linkUpstreamBandwidthKbps / 1000} Mbps")
                    .row("İnternet", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) "✓" else "✗")
                    .row("Doğrulanmış", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "✓" else "✗")
                    .row("Sınırsız", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) "✓" else "✗")
            }
            cm.getLinkProperties(n)?.let { lp ->
                c1.row("Arayüz", lp.interfaceName ?: "-")
                    .row("DNS", lp.dnsServers.joinToString { it.hostAddress ?: "" })
            }
        }

        val c2 = makeCard(s("c_wifi"), "📡")
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val wi = wm.connectionInfo
            c2.row("SSID", wi.ssid ?: "-")
                .row("BSSID", wi.bssid ?: "-")
                .row("Sinyal", "${wi.rssi} dBm")
                .row("Hız", "${wi.linkSpeed} Mbps")
                .row("Frekans", "${wi.frequency} MHz")
                .row("IP", ip(wi.ipAddress))
        } catch (e: Throwable) { c2.row("Hata", e.message ?: "?") }

        val c3 = makeCard(s("c_cell"), "📞")
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            c3.row("Operatör", tm.networkOperatorName ?: "-")
                .row("SIM", tm.simOperatorName ?: "-")
                .row("Ülke", tm.networkCountryIso ?: "-")
                .row("Roaming", if (tm.isNetworkRoaming) "✓" else "✗")
        } catch (e: Throwable) { c3.row("Hata", e.message ?: "?") }

        val c4 = makeCard(s("c_ifaces"), "🔌")
        NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
            val mac = ni.hardwareAddress?.joinToString(":") { "%02X".format(it) } ?: "-"
            c4.row(ni.name, "up=${if (ni.isUp) "✓" else "✗"}  mac=$mac")
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Sensörler
    // ──────────────────────────────────────────────────────────
    private fun renderSensors() {
        val list = sm.getSensorList(Sensor.TYPE_ALL)
        val c = makeCard("Sensörler (${list.size})", "📡")
        val sb = StringBuilder()
        list.forEach { s ->
            sb.append("• ${s.name}\n")
            sb.append("  ${s.stringType}\n")
            sb.append("  ${s.vendor} v${s.version}  ·  max ${s.maximumRange}  ·  ${s.power} mA\n\n")
        }
        c.text(sb.toString())
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Kamera
    // ──────────────────────────────────────────────────────────
    private fun renderCamera() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        cm.cameraIdList.forEach { id ->
            val ch = cm.getCameraCharacteristics(id)
            val c = makeCard("Kamera $id", "📷")
            c.row("Yön", when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Ön"
                CameraCharacteristics.LENS_FACING_BACK -> "Arka"
                else -> "Harici"
            })
            c.row("Yönlendirme", "${ch.get(CameraCharacteristics.SENSOR_ORIENTATION)}°")
            c.row("Donanım seviyesi", mapOf(0 to "LIMITED", 1 to "FULL", 2 to "LEGACY", 3 to "LEVEL_3", 4 to "EXTERNAL")
                .get(ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) ?: "?")
            c.row("Odak uzaklığı", ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString() ?: "-")
            c.row("Diyafram", ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString() ?: "-")
            ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let {
                c.row("Çözünürlük", "${it.width}×${it.height} (%.1f MP)".format(it.width * it.height / 1e6))
            }
            c.row("Flaş", if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) "✓" else "✗")
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Özellikler / Uygulamalar / Kodek / Güvenlik
    // ──────────────────────────────────────────────────────────
    private fun renderFeatures() {
        val f = packageManager.systemAvailableFeatures.mapNotNull { it.name }.sorted()
        val c = makeCard("Özellikler (${f.size})", "✨")
        c.text(f.joinToString("\n"))
    }

    private fun renderApps() {
        val pk = packageManager.getInstalledPackages(0)
        fun sys(p: PackageInfo) = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
        val c1 = makeCard("Uygulama Özeti", "📱")
        c1.row("Toplam", pk.size.toString())
            .row("Sistem", pk.count { sys(it) }.toString())
            .row("Kullanıcı", pk.count { !sys(it) }.toString())
        val c2 = makeCard("Kullanıcı Uygulamaları", "👤")
        val sb = StringBuilder()
        pk.filter { !sys(it) }.sortedBy { it.packageName }.forEach {
            val name = it.applicationInfo?.let { a -> packageManager.getApplicationLabel(a) }
            sb.append("• $name\n  ${it.packageName}\n  v${it.versionName ?: "?"}\n\n")
        }
        c2.text(sb.toString())
    }

    private fun renderCodecs() {
        val c = makeCard("Medya Kodekleri", "🎬")
        val sb = StringBuilder()
        MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.sortedBy { it.name }.forEach { ci ->
            sb.append("${if (ci.isEncoder) "[ENC]" else "[DEC]"} ${ci.name}\n  ${ci.supportedTypes.joinToString()}\n\n")
        }
        c.text(sb.toString())

        val c2 = makeCard("Widevine DRM", "🔐")
        try {
            val md = MediaDrm(UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"))
            listOf("vendor", "version", "description", "securityLevel").forEach {
                c2.row(it, md.getPropertyString(it) ?: "-")
            }
            md.release()
        } catch (e: Throwable) { c2.row("Hata", e.message ?: "?") }

        val c3 = makeCard("Ses", "🔊")
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        c3.row("Örnekleme", am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) ?: "-")
            .row("Tampon", am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER) ?: "-")
            .row("Medya ses", "${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}")
    }

    private fun renderSecurity() {
        val c = makeCard("Güvenlik", "🔒")
        val roots = listOf("/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su","/data/local/bin/su").filter { File(it).exists() }
        c.row("Root izi", if (roots.isEmpty()) "Yok" else "VAR!", if (roots.isEmpty()) pal.ok else pal.danger)
            .row("Test-keys", if (Build.TAGS?.contains("test-keys") == true) "EVET" else "hayır")
            .row("Emülatör", if (Build.FINGERPRINT.contains("generic")) "Evet" else "Hayır")
            .row("Ekran kilidi", if ((getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure) "Var" else "Yok")
            .row("USB hata ayıklama", if (Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1) "AÇIK" else "kapalı")
            .row("Geliştirici seçenekleri", if (Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1) "AÇIK" else "kapalı")
            .row("SELinux", sh("getenforce"))
            .row("Verified boot", sh("getprop ro.boot.verifiedbootstate"))
            .row("Şifreleme", sh("getprop ro.crypto.state"))
            .row("ro.debuggable", sh("getprop ro.debuggable"))
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Termal (canlı, çok hızlı)
    // ──────────────────────────────────────────────────────────
    private fun renderThermal() {
        val peak = HashMap<String, Double>()
        val low = HashMap<String, Double>()

        // Büyük stat kartları
        val statRow1 = statRow()
        val cpuTv = statCard(statRow1, s("st_cpu"), if (lang == "en") "N/A" else "Yok", pal.danger)
        val gpuTv = statCard(statRow1, s("st_gpu"), if (lang == "en") "N/A" else "Yok", pal.warn)
        val batTv = statCard(statRow1, s("st_bat"), if (lang == "en") "N/A" else "Yok", pal.ok)
        content.addView(statRow1)

        // Zone kartı
        val cZones = makeCard(s("st_zones"), "📊")
        val (thermalStatusTv, _) = cZones.rowLive(if (lang == "en") "Android thermal status" else "Android termal durumu", thermalStatusLabel(this, lang))
        val note = TextView(this).apply {
            text = if (lang == "en") "Actual temperatures are read from accessible thermal zones, hwmon sensors or Android's thermal service when available. Android/OEM permissions may hide CPU/GPU sensors. The system thermal status above is not a temperature reading." else "Gerçek sıcaklıklar erişilebilen thermal zone, hwmon veya Android termal servisinden okunur. Android/üretici izinleri CPU/GPU sensörlerini gizleyebilir. Yukarıdaki sistem termal durumu bir sıcaklık değeri değildir."
            textSize = 11f
            setTextColor(pal.sub)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(6), 0, dp(8))
        }
        cZones.body.addView(note)
        val zonesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cZones.body.addView(zonesContainer)
        var zoneViews = mutableListOf<Triple<String, TextView, TextView>>()
        var lastZones = "__initial__"

        liveUpdaters.add {
            val zones = thermalZones()
            val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
            val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
            val batT = batteryTemp()
            thermalStatusTv.text = inlineUiText(thermalStatusLabel(this@MainActivity, lang), lang)
            thermalStatusTv.setTextColor(when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE -> pal.danger
                else -> pal.ok
            })
            listOf("cpu" to cpuT, "gpu" to gpuT, "bat" to batT).forEach { (k, v) ->
                if (v != null) {
                    peak[k] = max(peak[k] ?: v, v)
                    low[k] = min(low[k] ?: v, v)
                }
            }
            fun up(tv: TextView, t: Double?, k: String) {
                if (t == null) { tv.text = if (lang == "en") "N/A" else "Yok"; tv.setTextColor(pal.sub); return }
                tv.text = "%.1f°".format(t)
                tv.setTextColor(tempColor(t))
            }
            up(cpuTv, cpuT, "cpu"); up(gpuTv, gpuT, "gpu"); up(batTv, batT, "bat")

            // Zone listesi (yapı değişirse yeniden oluştur)
            val displayZones = zones.sortedBy { it.zone }
            val sig = displayZones.joinToString { it.zone }
            if (sig != lastZones) {
                lastZones = sig
                zonesContainer.removeAllViews()
                zoneViews.clear()
                if (zones.isEmpty()) {
                    zonesContainer.addView(TextView(this@MainActivity).apply {
                        text = if (lang == "en") "No readable CPU/GPU thermal sensors were exposed. Battery temperature may still be available separately. Unavailable does not mean 0°C." else "CPU/GPU için okunabilir termal sensör sunulmuyor. Pil sıcaklığı ayrı olarak yine de gösterilebilir. Erişilemeyen değer 0°C anlamına gelmez."
                        textSize = 12f
                        setTextColor(pal.sub)
                        setLineSpacing(dp(3).toFloat(), 1f)
                        setPadding(0, dp(4), 0, dp(8))
                    })
                }
                displayZones.forEach { z ->
                    val r = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(0, dp(6), 0, dp(6))
                    }
                    val kTv = TextView(this@MainActivity).apply {
                        text = "${z.zone}  (${z.type.take(18)})"
                        textSize = 12f; setTextColor(pal.sub)
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    }
                    val vTv = TextView(this@MainActivity).apply {
                        text = "%.1f °C".format(z.temp)
                        textSize = 13f; setTypeface(null, Typeface.BOLD)
                        setTextColor(tempColor(z.temp))
                    }
                    r.addView(kTv); r.addView(vTv)
                    zonesContainer.addView(r)
                    zoneViews.add(Triple(z.zone, kTv, vTv))
                }
            } else {
                // Sadece sıcaklık değerlerini güncelle
                displayZones.forEachIndexed { idx, z ->
                    zoneViews.getOrNull(idx)?.let { (_, _, vTv) ->
                        vTv.text = "%.1f °C".format(z.temp)
                        vTv.setTextColor(tempColor(z.temp))
                    }
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Canlı sensörler
    // ──────────────────────────────────────────────────────────
    private fun renderLive() {
        liveVals.clear()
        val c = makeCard(s("tab_live"), "📊")
        val tv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12.5f
            setTextColor(pal.text)
            setTextIsSelectable(true)
        }
        c.body.addView(tv)
        startLiveSensors()

        liveUpdaters.add {
            if (liveVals.isEmpty()) return@add
            tv.text = liveVals.entries.joinToString("\n\n") { "${it.key}\n   ${it.value}" }
        }
    }

    private fun startLiveSensors() {
        sm.unregisterListener(this)
        intArrayOf(
            Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY, Sensor.TYPE_PRESSURE,
            Sensor.TYPE_GRAVITY, Sensor.TYPE_AMBIENT_TEMPERATURE, Sensor.TYPE_RELATIVE_HUMIDITY,
            Sensor.TYPE_ROTATION_VECTOR
        ).forEach { t -> sm.getDefaultSensor(t)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        liveVals[e.sensor.stringType.substringAfterLast('.') + " • " + e.sensor.name] =
            e.values.joinToString("   ") { "%.3f".format(it) }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Yük Testi
    // ──────────────────────────────────────────────────────────
    private fun renderStress() {
        val c = makeCard(if (lang == "en") "Performance Lab" else "Performans Laboratuvarı", "🔥")
        val intro = TextView(this).apply {
            text = if (lang == "en") "Run CPU and GPU workloads while watching live thermals. Tests stop automatically on high temperature or severe Android thermal status." else "CPU ve GPU yükünü gerçek zamanlı sıcaklıklarla izle. Sıcaklık yükselirse veya Android kritik termal durum bildirirse test otomatik durur."
            textSize = 12f
            setTextColor(pal.sub)
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        c.body.addView(intro)

        val durationLabel = TextView(this).apply {
            textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(pal.text)
            setPadding(0, dp(14), 0, dp(4))
        }
        c.body.addView(durationLabel)
        c.body.addView(SeekBar(this).apply {
            max = 34
            progress = 10 // 60 seconds: 10 + 10 * 5
            selectedStressSeconds = 60
            durationLabel.text = (if (lang == "en") "Duration: " else "Süre: ") + "$selectedStressSeconds s"
            progressTintList = ColorStateList.valueOf(pal.accent)
            thumbTintList = ColorStateList.valueOf(pal.accent2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    selectedStressSeconds = 10 + p * 5
                    durationLabel.text = (if (lang == "en") "Duration: " else "Süre: ") + "$selectedStressSeconds s"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        val intensityLabel = TextView(this).apply {
            textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(pal.text)
            setPadding(0, dp(10), 0, dp(4))
        }
        c.body.addView(intensityLabel)
        c.body.addView(SeekBar(this).apply {
            max = 75
            progress = 50 // 75 percent
            progressTintList = ColorStateList.valueOf(pal.accent2)
            thumbTintList = ColorStateList.valueOf(pal.accent2)
            fun updateLabel(p: Int) {
                selectedStressIntensity = (25 + p) / 100f
                val cores = max(1, ceil(Runtime.getRuntime().availableProcessors() * selectedStressIntensity).toInt())
                intensityLabel.text = (if (lang == "en") "Load: " else "Yük: ") + "${(selectedStressIntensity * 100).toInt()}%  •  $cores/${Runtime.getRuntime().availableProcessors()} CPU"
                stressGpuView?.setLoadIntensity(selectedStressIntensity)
            }
            updateLabel(progress)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) = updateLabel(p)
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        val gpuTitle = TextView(this).apply {
            text = if (lang == "en") "Live GPU shader" else "Canlı GPU shader"
            textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(pal.sub)
            setPadding(0, dp(12), 0, dp(6))
        }
        c.body.addView(gpuTitle)
        val gpu = GpuStressView(this)
        stressGpuView = gpu
        gpu.setLoadIntensity(selectedStressIntensity)
        c.body.addView(gpu, LinearLayout.LayoutParams(-1, dp(168)).apply { bottomMargin = dp(8) })
        gpu.onResume()

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(pal.accent)
            progressBackgroundTintList = ColorStateList.valueOf(pal.stroke)
        }
        stressProgress = progress
        c.body.addView(progress, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(12); bottomMargin = dp(8) })

        val statusTv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(pal.text)
            setPadding(0, dp(8), 0, dp(8))
            text = if (lang == "en") "Ready • ${selectedStressSeconds}s • ${(selectedStressIntensity * 100).toInt()}% load" else "Hazır • ${selectedStressSeconds} sn • Yük ${(selectedStressIntensity * 100).toInt()}%"
            minHeight = dp(82)
        }
        stressStatus = statusTv
        c.body.addView(statusTv)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(styledBtn(if (lang == "en") "⚡ CPU test" else "⚡ CPU testi", pal.accent) { startStress("cpu") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        row1.addView(styledBtn(if (lang == "en") "🎮 GPU test" else "🎮 GPU testi", pal.accent2) { startStress("gpu") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        c.body.addView(row1)
        c.body.addView(styledBtn(if (lang == "en") "🔥 Combined test" else "🔥 Birleşik test", pal.warn) { startStress("both") })
        c.body.addView(styledBtn(if (lang == "en") "■ Stop test" else "■ Testi durdur", pal.danger) { stopStress(if (lang == "en") "Stopped by user." else "Kullanıcı tarafından durduruldu.") })

        val safety = TextView(this).apply {
            text = if (lang == "en") "Safety: keep the phone uncovered and unplugged. This tool cannot force temperature sensors to be available on every device." else "Güvenlik: telefonu örtme ve şarjdan çıkar. Her cihazda CPU/GPU derece sensörleri uygulamalara açılmaz."
            textSize = 11f; setTextColor(pal.sub); setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(8), 0, 0)
        }
        c.body.addView(safety)
    }

    private fun startStress(mode: String) {
        if (stressRunning) return
        val zones = thermalZones()
        val cpuTemp = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
        val gpuTemp = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
        val battery = batteryTemp()
        if ((battery != null && battery >= 43.0) || ((cpuTemp ?: 0.0) >= 85.0) || ((gpuTemp ?: 0.0) >= 85.0)) {
            stressStatus?.text = if (lang == "en") "Safety lock: device is already hot. Let it cool before testing." else "Güvenlik kilidi: cihaz zaten sıcak. Testten önce soğumasını bekle."
            stressStatus?.setTextColor(pal.danger)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
                stressStatus?.text = if (lang == "en") "Safety lock: Android reports severe thermal status." else "Güvenlik kilidi: Android yüksek termal durum bildiriyor."
                stressStatus?.setTextColor(pal.danger)
                return
            }
        }

        stressRunning = true
        stressMode = mode
        stressStart = SystemClock.elapsedRealtime()
        val runSeconds = selectedStressSeconds
        val runIntensity = selectedStressIntensity
        stressCpuPeak = cpuTemp; stressGpuPeak = gpuTemp; stressBatteryPeak = battery
        gpuError = null
        val cores = Runtime.getRuntime().availableProcessors()
        val workerCount = max(1, ceil(cores * runIntensity).toInt()).coerceAtMost(cores)
        val useGpu = mode == "gpu" || mode == "both"
        val useCpu = mode == "cpu" || mode == "both"
        stressGpuView?.setLoadEnabled(useGpu, runIntensity)

        if (useCpu) repeat(workerCount) { worker ->
            val t = Thread({
                var x = 0.73 + worker * 0.01
                val random = Random(worker + SystemClock.elapsedRealtime().toInt())
                while (stressRunning && !Thread.currentThread().isInterrupted) {
                    var i = 0
                    while (i < 2048 && stressRunning && !Thread.currentThread().isInterrupted) {
                        x = kotlin.math.sin(x * 1.0000001) * kotlin.math.cos(x * 0.9999999) + random.nextDouble() * 1e-7
                        i++
                    }
                    cpuSink = x // keep the work observable so the JIT cannot discard it
                }
            }, "PhoneInfo-CPU-$worker").apply { priority = Thread.NORM_PRIORITY }
            stressThreads.add(t)
            t.start()
        }

        stressStatus?.setTextColor(pal.text)
        stressProgress?.progress = 0
        stressUpdater?.let { ticker.removeCallbacks(it) }
        stressUpdater = object : Runnable {
            override fun run() {
                if (!stressRunning) return
                val elapsedMs = SystemClock.elapsedRealtime() - stressStart
                val elapsedSeconds = elapsedMs / 1000
                val liveZones = thermalZones()
                val cTemp = liveZones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                    ?: liveZones.filter { zoneKind(it) == "other" }.filter { it.type.contains("soc", true) || it.type.contains("tsens", true) }.maxByOrNull { it.temp }?.temp
                val gTemp = liveZones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
                val bTemp = batteryTemp()
                if (cTemp != null) stressCpuPeak = max(stressCpuPeak ?: cTemp, cTemp)
                if (gTemp != null) stressGpuPeak = max(stressGpuPeak ?: gTemp, gTemp)
                if (bTemp != null) stressBatteryPeak = max(stressBatteryPeak ?: bTemp, bTemp)
                val totalMs = runSeconds * 1000L
                stressProgress?.progress = ((elapsedMs.toDouble() / totalMs) * 1000).toInt().coerceIn(0, 1000)

                val builder = StringBuilder()
                builder.append(if (lang == "en") "● RUNNING" else "● ÇALIŞIYOR").append("  [").append(mode.uppercase(Locale.ROOT)).append("]\n")
                builder.append("⏱ ").append(if (lang == "en") "Elapsed" else "Geçen süre").append(": ").append(elapsedSeconds).append(" / ").append(runSeconds).append(" s\n")
                builder.append("⚙ CPU workers: ").append(if (useCpu) workerCount else 0).append(" / ").append(cores).append("\n")
                builder.append("🎮 GPU shader: ").append(if (useGpu) if (gpuError == null) "ACTIVE" else "ERROR" else "IDLE").append("\n\n")
                fun line(label: String, temperature: Double?) {
                    builder.append(label.padEnd(10)).append(temperature?.let { "%.1f °C".format(it) } ?: if (lang == "en") "Not exposed" else "Sensör yok").append("\n")
                }
                line("CPU", cTemp); line("GPU", gTemp); line(if (lang == "en") "Battery" else "Pil", bTemp)
                builder.append("\n").append(if (lang == "en") "Thermal status: " else "Termal durum: ").append(thermalStatusLabel(this@MainActivity, lang))
                if (gpuError != null && useGpu) builder.append("\nGPU: ").append(gpuError)
                stressStatus?.text = builder.toString()

                val thermalStatusSevere = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                    (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
                val stopReason = when {
                    bTemp != null && bTemp >= 44.0 -> if (lang == "en") "Battery reached 44°C safety limit." else "Pil sıcaklığı 44°C güvenlik sınırına ulaştı."
                    max(cTemp ?: 0.0, gTemp ?: 0.0) >= 88.0 -> if (lang == "en") "CPU/GPU reached 88°C safety limit." else "CPU/GPU sıcaklığı 88°C güvenlik sınırına ulaştı."
                    thermalStatusSevere -> if (lang == "en") "Android reports severe thermal status; load stopped." else "Android yüksek termal durum bildirdi; yük durduruldu."
                    gpuError != null && useGpu -> (if (lang == "en") "GPU shader failed: " else "GPU shader hatası: ") + gpuError
                    elapsedMs >= totalMs -> if (lang == "en") "Test completed." else "Test tamamlandı."
                    else -> null
                }
                if (stopReason != null) {
                    stopStress(stopReason)
                } else {
                    ticker.postDelayed(this, 750L)
                }
            }
        }
        ticker.post(stressUpdater!!)
    }

    private fun stopStress(reason: String? = null) {
        val hadRun = stressRunning
        stressRunning = false
        stressUpdater?.let { ticker.removeCallbacks(it) }
        stressUpdater = null
        stressThreads.forEach { runCatching { it.interrupt() } }
        stressThreads.clear()
        stressGpuView?.setLoadEnabled(false, selectedStressIntensity)
        if (hadRun && reason != null) {
            val isSafety = reason.contains("44°C") || reason.contains("88°C") || reason.contains("thermal", true) || reason.contains("termal", true) || reason.contains("safety", true) || reason.contains("Güvenlik", true)
            stressStatus?.text = (if (isSafety) "🛑 " else "✓ ") + reason + "\n" +
                (if (lang == "en") "Peak temperatures: CPU " else "En yüksek sıcaklıklar: CPU ") + (stressCpuPeak?.let { "%.1f°C".format(it) } ?: "—") +
                " • GPU " + (stressGpuPeak?.let { "%.1f°C".format(it) } ?: "—") +
                " • " + (if (lang == "en") "Battery " else "Pil ") + (stressBatteryPeak?.let { "%.1f°C".format(it) } ?: "—")
            stressStatus?.setTextColor(if (isSafety) pal.warn else pal.ok)
            if (isSafety && current == "stress") Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
        } else if (!hadRun && reason != null) {
            stressStatus?.text = reason
        }
    }

    private fun styledBtn(label: String, color: Int, onClick: () -> Unit): Button {
        val highlight = if (color == pal.warn || color == pal.danger) Color.WHITE else Color.WHITE
        return Button(this).apply {
            text = inlineUiText(label, lang)
            isAllCaps = false
            textSize = 13.5f
            letterSpacing = 0.01f
            setTypeface(null, Typeface.BOLD)
            setTextColor(highlight)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(color, if (color == pal.accent) pal.accent2 else color)).apply {
                cornerRadius = dp(15).toFloat()
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                animate().scaleX(0.98f).scaleY(0.98f).setDuration(65).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }.start()
                onClick()
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(6); bottomMargin = dp(6)
            }
        }
    }

    private inner class GpuStressView(ctx: Context) : GLSurfaceView(ctx), GLSurfaceView.Renderer {
        @Volatile private var active = false
        @Volatile private var intensity = 0.75f
        private var program = 0
        private var positionLoc = -1
        private var timeLoc = -1
        private var loadLoc = -1
        private var startT = SystemClock.elapsedRealtime()
        private val verts: FloatBuffer = ByteBuffer.allocateDirect(3 * 2 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(floatArrayOf(-1f, -1f, 3f, -1f, -1f, 3f)); position(0) }

        init {
            setEGLContextClientVersion(2)
            preserveEGLContextOnPause = true
            setRenderer(this)
            renderMode = RENDERMODE_WHEN_DIRTY
            setBackgroundColor(Color.BLACK)
        }

        fun setLoadIntensity(value: Float) {
            intensity = value.coerceIn(0.25f, 1f)
            requestRender()
        }

        fun setLoadEnabled(enabled: Boolean, value: Float = intensity) {
            intensity = value.coerceIn(0.25f, 1f)
            active = enabled
            renderMode = if (enabled) RENDERMODE_CONTINUOUSLY else RENDERMODE_WHEN_DIRTY
            requestRender()
        }

        private fun compileShader(kind: Int, source: String): Int {
            val shader = GLES20.glCreateShader(kind)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val status = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                gpuError = GLES20.glGetShaderInfoLog(shader)?.take(240) ?: "Shader compile failed"
                GLES20.glDeleteShader(shader)
                return 0
            }
            return shader
        }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            gpuError = null
            val vs = "attribute vec2 p; void main(){ gl_Position=vec4(p,0.0,1.0); }"
            val fs = """
                precision mediump float;
                uniform float uTime;
                uniform float uLoad;
                void main() {
                    vec2 q = gl_FragCoord.xy * 0.008;
                    float a = 0.0;
                    for (int i = 0; i < 128; i++) {
                        float fi = float(i);
                        if (fi > uLoad * 127.0) break;
                        float v = sin(q.x * fi * 0.027 + uTime) * cos(q.y * fi * 0.019 - uTime);
                        a += v + sqrt(abs(sin(fi) + 1.0)) * 0.004;
                    }
                    float pulse = 0.5 + 0.5 * sin(a * 0.03 + uTime);
                    gl_FragColor = vec4(0.04 + pulse * 0.08, 0.12 + pulse * 0.23, 0.20 + pulse * 0.35, 1.0);
                }
            """.trimIndent()
            val vertex = compileShader(GLES20.GL_VERTEX_SHADER, vs)
            val fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fs)
            if (vertex == 0 || fragment == 0) return
            program = GLES20.glCreateProgram()
            GLES20.glAttachShader(program, vertex)
            GLES20.glAttachShader(program, fragment)
            GLES20.glLinkProgram(program)
            val linked = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
            if (linked[0] == 0) {
                gpuError = GLES20.glGetProgramInfoLog(program)?.take(240) ?: "GPU program link failed"
                GLES20.glDeleteProgram(program)
                program = 0
                return
            }
            positionLoc = GLES20.glGetAttribLocation(program, "p")
            timeLoc = GLES20.glGetUniformLocation(program, "uTime")
            loadLoc = GLES20.glGetUniformLocation(program, "uLoad")
            startT = SystemClock.elapsedRealtime()
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            if (!active || program == 0) {
                GLES20.glClearColor(0.035f, 0.055f, 0.09f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                return
            }
            GLES20.glUseProgram(program)
            GLES20.glEnableVertexAttribArray(positionLoc)
            verts.position(0)
            GLES20.glVertexAttribPointer(positionLoc, 2, GLES20.GL_FLOAT, false, 0, verts)
            GLES20.glUniform1f(timeLoc, (SystemClock.elapsedRealtime() - startT) / 1000f)
            GLES20.glUniform1f(loadLoc, intensity)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            GLES20.glDisableVertexAttribArray(positionLoc)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Araçlar
    // ──────────────────────────────────────────────────────────
    private fun renderTools() {
        val c = makeCard(s("tab_tools"), "🧪")
        c.body.addView(styledBtn(s("tools_vib"), pal.accent) { vibrate() })
        c.body.addView(styledBtn(s("tools_torch"), pal.accent) { toggleTorch() })
        c.body.addView(styledBtn(s("tools_beep"), pal.accent) {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 400)
        })
        c.body.addView(styledBtn(s("tools_color"), pal.accent2) { colorTest() })
        c.body.addView(styledBtn(s("tools_touch"), pal.accent2) { touchTest() })
        c.body.addView(styledBtn(s("tools_cpubench"), pal.warn) { cpuBench() })
        c.body.addView(styledBtn(s("tools_disk"), pal.warn) { diskBench() })
        c.body.addView(styledBtn(s("tools_settings"), pal.sub) { settingsMenu() })
        c.body.addView(styledBtn(s("tools_copy"), pal.ok) {
            val r = fullReport()
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", r))
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show()
        })
        c.body.addView(styledBtn(s("tools_share"), pal.ok) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, fullReport().take(200000)), "Share"))
        })

        val c2 = makeCard(s("tools_brightness"), "💡")
        c2.body.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    val lp = window.attributes
                    lp.screenBrightness = max(p, 1) / 100f
                    window.attributes = lp
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0,200,100,200,100,500), -1))
        else v.vibrate(500)
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return
            torch = !torch; cm.setTorchMode(id, torch)
        } catch (e: Throwable) { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() }
    }

    private fun colorTest() {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val cols = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.GRAY)
        var i = 0
        val v = View(this).apply {
            setBackgroundColor(cols[0])
            setOnClickListener { i++; if (i >= cols.size) dlg.dismiss() else setBackgroundColor(cols[i]) }
        }
        dlg.setContentView(v)
        dlg.window?.decorView?.systemUiVisibility =
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        dlg.show()
    }

    inner class TouchView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 44f }
        private val pts = HashMap<Int, PointF>()
        private var maxPts = 0
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) pts.clear()
            else { pts.clear(); for (i in 0 until e.pointerCount) pts[e.getPointerId(i)] = PointF(e.getX(i), e.getY(i)); maxPts = max(maxPts, e.pointerCount) }
            invalidate(); return true
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(Color.BLACK); p.color = Color.WHITE
            c.drawText("Now: ${pts.size}  Max: $maxPts", 20f, 90f, p)
            p.color = Color.CYAN
            pts.values.forEach { c.drawCircle(it.x, it.y, 90f, p) }
        }
    }
    private fun touchTest() {
        Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
            setContentView(TouchView(this@MainActivity)); show()
        }
    }

    private fun work(iterations: Int = 1_000_000): Long {
        var x = 0x1234ABCDL
        for (i in 1..iterations) {
            x = x xor (x shl 13)
            x = x xor (x ushr 7)
            x = (x xor (x shl 17)) + i
        }
        return x
    }

    private fun cpuBench() {
        val started = SystemClock.elapsedRealtime()
        val progress = ProgressDialog(this).apply {
            setMessage(if (lang == "en") "Running a short CPU benchmark…" else "Kısa CPU testi çalışıyor…")
            setCancelable(false)
            show()
        }
        Thread {
            val n = Runtime.getRuntime().availableProcessors().coerceAtMost(8)
            val t0 = System.nanoTime()
            val singleChecksum = work(800_000)
            val single = (System.nanoTime() - t0) / 1_000_000.0
            val multiStart = System.nanoTime()
            val workers = (0 until n).map { worker -> Thread { cpuSink = work(800_000 + worker * 100).toDouble() }.also { it.start() } }
            workers.forEach { it.join() }
            val multi = (System.nanoTime() - multiStart) / 1_000_000.0
            val score = (800_000.0 * n / (multi / 1000.0)).toLong()
            runOnUiThread {
                progress.dismiss()
                val elapsed = SystemClock.elapsedRealtime() - started
                AlertDialog.Builder(this)
                    .setTitle(if (lang == "en") "CPU benchmark" else "CPU Benchmark")
                    .setMessage((if (lang == "en") "Single core: " else "Tek çekirdek: ") + "%.0f ms\n".format(single) +
                        (if (lang == "en") "Multi core ($n): " else "Çok çekirdek ($n): ") + "%.0f ms\n".format(multi) +
                        (if (lang == "en") "Throughput score: " else "İşlem puanı: ") + score + "\n" +
                        (if (lang == "en") "Checksum: " else "Kontrol değeri: ") + singleChecksum + "\n" +
                        (if (lang == "en") "Elapsed: " else "Geçen süre: ") + "${elapsed} ms")
                    .setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun diskBench() {
        Thread {
            try {
                val f = File(cacheDir, "bench.bin"); val buf = ByteArray(1 shl 20) { it.toByte() }; val mb = 64
                var t = System.nanoTime()
                java.io.FileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.fd.sync() }
                val w = mb / ((System.nanoTime() - t) / 1e9)
                t = System.nanoTime()
                java.io.FileInputStream(f).use { i -> while (i.read(buf) > 0) { } }
                val r = mb / ((System.nanoTime() - t) / 1e9)
                f.delete()
                runOnUiThread { Toast.makeText(this, "W: %.0f MB/s\nR: %.0f MB/s".format(w, r), Toast.LENGTH_LONG).show() }
            } catch (e: Throwable) { runOnUiThread { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun settingsMenu() {
        val items = if (lang == "en") listOf(
            "Device info" to Settings.ACTION_DEVICE_INFO_SETTINGS,
            "Developer options" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "Battery saver" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Wireless" to Settings.ACTION_WIRELESS_SETTINGS,
            "Display" to Settings.ACTION_DISPLAY_SETTINGS,
            "Storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
            "Apps" to Settings.ACTION_APPLICATION_SETTINGS
        ) else listOf(
            "Cihaz bilgisi" to Settings.ACTION_DEVICE_INFO_SETTINGS,
            "Geliştirici seçenekleri" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "Pil tasarrufu" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Kablosuz" to Settings.ACTION_WIRELESS_SETTINGS,
            "Ekran" to Settings.ACTION_DISPLAY_SETTINGS,
            "Depolama" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
            "Uygulamalar" to Settings.ACTION_APPLICATION_SETTINGS
        )
        AlertDialog.Builder(this).setItems(items.map { it.first }.toTypedArray()) { _, w ->
            try { startActivity(Intent(items[w].second)) } catch (e: Throwable) {}
        }.show()
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ayarlar
    // ──────────────────────────────────────────────────────────
    private fun renderSettings() {
        // Görünüm
        val c1 = makeCard(s("st_appearance"), "🎨")
        val darkRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        darkRow.addView(TextView(this).apply {
            text = s("st_dark"); textSize = 14f
            setTextColor(pal.text)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        darkRow.addView(Switch(this).apply {
            isChecked = dark
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("dark", checked).apply()
                dark = checked
                recreate()
            }
        })
        c1.body.addView(darkRow)

        // Dil
        val c2 = makeCard(s("st_lang"), "🌐")
        val langRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
        }
        langRow.addView(styledBtn("Türkçe", if (lang == "tr") pal.accent else pal.card2) {
            prefs.edit().putString("lang", "tr").apply(); recreate()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        langRow.addView(styledBtn("English", if (lang == "en") pal.accent else pal.card2) {
            prefs.edit().putString("lang", "en").apply(); recreate()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        c2.body.addView(langRow)

        // Yenileme hızı
        val c3 = makeCard(s("st_refresh"), "⚡")
        val rt = TextView(this).apply {
            text = "%.1f sn".format(refreshMs / 1000.0)
            textSize = 18f; setTypeface(null, Typeface.BOLD)
            setTextColor(pal.accent)
            setPadding(0, dp(6), 0, dp(6))
        }
        c3.body.addView(rt)
        c3.body.addView(TextView(this).apply {
            text = s("st_refresh_hint"); textSize = 11f; setTextColor(pal.sub)
        })
        c3.body.addView(SeekBar(this).apply {
            max = 19
            progress = ((refreshMs - 100) / 100).toInt().coerceIn(0, 19)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    refreshMs = (100 + p * 100).toLong()
                    rt.text = "%.1f sn".format(refreshMs / 1000.0)
                    prefs.edit().putLong("refresh", refreshMs).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        // Hakkında
        val c4 = makeCard(s("st_about"), "ℹ")
        c4.body.addView(TextView(this).apply {
            text = s("st_about_body")
            textSize = 13f; setTextColor(pal.sub)
            setLineSpacing(dp(4).toFloat(), 1f)
        })
    }

    // ──────────────────────────────────────────────────────────
    //  Rapor
    // ──────────────────────────────────────────────────────────
    private fun fullReport(): String {
        val sb = StringBuilder()
        sb.append(if (lang == "en") "════ PhoneInfo v4.0 Report ════\n" else "════ PhoneInfo v4.0 Raporu ════\n")
        sb.append(if (lang == "en") "Date: " else "Tarih: ").append(Date()).append("\n\n")
        sb.append(if (lang == "en") "── Identity ──\n" else "── Kimlik ──\n")
        sb.append("${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")
        sb.append(if (lang == "en") "── Thermal ──\n" else "── Termal ──\n")
        thermalZones().sortedByDescending { it.temp }.forEach {
            sb.append("%-24s %.1f °C\n".format(it.type.take(24), it.temp))
        }
        sb.append(if (lang == "en") "\n── CPU ──\n" else "\n── CPU ──\n")
        val n = Runtime.getRuntime().availableProcessors()
        sb.append((if (lang == "en") "Cores: " else "Çekirdek: ") + "$n\n")
        for (i in 0 until n) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            sb.append("CPU$i: ${mhz(rd(b + "scaling_cur_freq"))}\n")
        }
        sb.append("\n── RAM ──\n")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        sb.append((if (lang == "en") "Total: " else "Toplam: ") + "${fmt(mi.totalMem)}\n" + (if (lang == "en") "Free: " else "Boş: ") + "${fmt(mi.availMem)}\n")
        return sb.toString()
    }
}