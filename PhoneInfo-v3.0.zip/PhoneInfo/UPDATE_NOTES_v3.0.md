# PhoneInfo v3.0

## What's new

- Updated dark-first visual system with gradient cards, animated page transitions, animated tabs, button press feedback and haptic selection feedback.
- New home dashboard row for CPU core count, battery level and battery temperature.
- GPU workload now renders a visible OpenGL ES shader surface instead of the old 1x1 hidden view.
- CPU stress test checks its stop flag regularly; tests have adjustable load and duration.
- Stress tests stop on high battery/CPU/GPU temperature, Android severe thermal status, shader failure or the selected time limit.
- Thermal discovery now checks both `/sys/class/thermal` and `/sys/class/hwmon` and identifies more common OEM CPU/GPU labels.
- Displays Android thermal service status separately from actual temperature readings. CPU/GPU temperature values are not fabricated when the vendor does not expose those sensors.
- CPU benchmark uses a bounded arithmetic workload and displays single-core and multi-core timing.
- App version raised to 3.0 (versionCode 4).

## Build

Use `build-v3.yml` as `.github/workflows/build.yml` in the repository, upload `PhoneInfo-v3.0.zip` to the repository root, commit, then check Actions for the `PhoneInfo-v3.0-apk` artifact.

Note: this environment did not have Android SDK/Gradle dependencies cached and has no network access, so a full Android APK build could not be run here. Please use GitHub Actions for the actual compile/device validation.
