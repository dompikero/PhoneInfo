# PhoneInfo v3.0 — major update

- Modernized cards and controls with a cyan/violet visual system, entrance transitions, tab selection animations, haptic feedback and press animations.
- Added the CPU core count, battery level and battery temperature summary on the device home screen.
- Fixed the GPU stress path: the previous implementation rendered into a 1×1 pixel hidden dialog; the new one uses a visible OpenGL ES surface with adjustable shader work.
- Reworked CPU stress workers to stop cooperatively, and added configurable 10–180 second duration and 25–100% load.
- Added safety auto-stop for battery temperature at 44°C, CPU/GPU sensor readings at 88°C, Android severe thermal status, GPU shader errors, manual stop, tab changes and backgrounding.
- Added broader thermal discovery via thermal_zone and hwmon; the app no longer pretends CPU/GPU Celsius readings exist when Android/OEM hides those sensors.
- Improved CPU benchmark feedback and updated the app icon/version to 3.0.

The actual Android APK compile still needs to be run by GitHub Actions or Android Studio because this build environment has neither a configured Android SDK nor network access to obtain Gradle dependencies.
