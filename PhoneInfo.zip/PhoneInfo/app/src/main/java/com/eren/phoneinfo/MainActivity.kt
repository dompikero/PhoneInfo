package com.eren.phoneinfo

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.hardware.camera2.*
import android.media.*
import android.net.*
import android.net.wifi.WifiManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.*
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.widget.*
import java.io.File
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.*
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

// ═══════════════════════════ Yardımcılar ═══════════════════════════
private fun rd(p: String): String? = try { File(p).readText().trim() } catch (e: Throwable) { null }
private fun sh(c: String): String = try {
    Runtime.getRuntime().exec(arrayOf("sh", "-c", c)).inputStream.bufferedReader().readText().trim()
} catch (e: Throwable) { "" }
private fun mhz(s: String?) = s?.toLongOrNull()?.let { "${it / 1000} MHz" } ?: "-"
private fun ip(i: Int) = "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
private fun fmt(b: Long): String { val u = arrayOf("B","KB","MB","GB","TB"); var v = b.toDouble(); var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }; return "%.2f %s".format(v, u[i]) }
private fun dur(ms: Long): String { val s = ms / 1000
    return "${s/86400}g ${s/3600%24}s ${s/60%60}dk ${s%60}sn" }

// ═══════════════════════════ Termal ═══════════════════════════
data class Tz(val name: String, val type: String, val temp: Double)

private fun readThermalZones(): List<Tz> {
    val out = mutableListOf<Tz>()
    val seen = HashSet<String>()
    val bases = listOf("/sys/class/thermal", "/sys/devices/virtual/thermal")
    for (base in bases) {
        val dir = File(base)
        if (!dir.isDirectory) continue
        dir.listFiles()?.forEach { f ->
            if (!f.name.startsWith("thermal_zone")) return@forEach
            if (!seen.add(f.name)) return@forEach
            val type = rd(f.path + "/type") ?: return@forEach
            val raw = rd(f.path + "/temp")?.toDoubleOrNull() ?: return@forEach
            val t = if (abs(raw) > 200) raw / 1000.0 else raw
            if (t < -30 || t > 200) return@forEach
            out.add(Tz(f.name, type, t))
        }
    }
    return out
}

private fun zoneKind(z: Tz): String {
    val t = z.type.lowercase()
    return when {
        t.contains("gpu") || t.contains("g3d") || t.contains("kgsl") ||
                t.contains("mali") || t.contains("adreno") || t.contains("gpuss") -> "gpu"
        t.contains("batt") || t.contains("bms") -> "bat"
        t.contains("cpu") || t.contains("soc") || t.contains("tsens") ||
                t.contains("cluster") || t.contains("big") || t.contains("little") ||
                t.contains("ap") || t.contains("core") -> "cpu"
        else -> "other"
    }
}

private fun extraGpuTemp(): Double? {
    val paths = listOf(
        "/sys/class/kgsl/kgsl-3d0/temp",
        "/sys/class/kgsl/kgsl-3d0/devfreq/temp",
        "/sys/kernel/gpu/gpu_temp",
        "/sys/devices/platform/mali.0/temp",
        "/sys/devices/virtual/thermal/thermal_zone0/temp",
        "/sys/module/mali/parameters/mali_gpu_temp"
    )
    for (p in paths) {
        val v = rd(p)?.toDoubleOrNull() ?: continue
        val t = if (abs(v) > 200) v / 1000.0 else v
        if (t in 0.0..150.0) return t
    }
    return null
}

// ═══════════════════════════ Dil ═══════════════════════════
object L {
    private val tr = mapOf(
        "app" to "PhoneInfo",
        "tab_device" to "Cihaz", "tab_display" to "Ekran", "tab_cpu" to "CPU",
        "tab_battery" to "Pil", "tab_net" to "Ağ", "tab_sensors" to "Sensör",
        "tab_camera" to "Kamera", "tab_apps" to "Uygulama", "tab_system" to "Sistem",
        "tab_live" to "Canlı", "tab_thermal" to "Sıcaklık", "tab_stress" to "Yük Testi",
        "tab_tools" to "Araçlar", "tab_settings" to "Ayarlar",
        "thermal_cpu" to "İşlemci", "thermal_gpu" to "Grafik (GPU)", "thermal_bat" to "Pil",
        "thermal_now" to "Şu an", "thermal_min" to "En düşük", "thermal_max" to "En yüksek",
        "thermal_all" to "Tüm termal bölgeler",
        "thermal_none" to "Bu cihazda termal sensör okunamıyor (kısıtlama).",
        "thermal_status" to "Sistem termal durumu",
        "stress_title" to "Yük Testi",
        "stress_cpu" to "CPU Yük Testi", "stress_gpu" to "GPU Yük Testi",
        "stress_both" to "Birleşik (CPU + GPU)", "stress_stop" to "DURDUR",
        "stress_duration" to "Süre (saniye)",
        "stress_idle" to "Hazır. Bir test başlatın.",
        "stress_running" to "Test çalışıyor…",
        "stress_done" to "Test tamamlandı",
        "stress_peak" to "Zirve sıcaklıklar",
        "stress_start" to "BAŞLAT",
        "tools_vib" to "Titreşim", "tools_torch" to "Fener",
        "tools_beep" to "Bip sesi", "tools_color" to "Ölü piksel testi",
        "tools_touch" to "Çoklu dokunma", "tools_cpu" to "CPU benchmark",
        "tools_disk" to "Depo hız testi", "tools_shortcuts" to "Ayar kısayolları",
        "tools_copy" to "Raporu kopyala", "tools_share" to "Raporu paylaş",
        "tools_brightness" to "Bu uygulama için parlaklık",
        "st_lang" to "Dil", "st_about" to "Hakkında",
        "st_about_body" to "PhoneInfo v2.0\nCihaz bilgisi, sıcaklık izleme ve yük testi.",
        "st_recreate" to "Dil değiştirildi, uygulama yeniden başlatılıyor…",
        "first_lang" to "Dil / Language",
        "copy_done" to "Kopyalandı"
    )
    private val en = mapOf(
        "app" to "PhoneInfo",
        "tab_device" to "Device", "tab_display" to "Display", "tab_cpu" to "CPU",
        "tab_battery" to "Battery", "tab_net" to "Network", "tab_sensors" to "Sensors",
        "tab_camera" to "Camera", "tab_apps" to "Apps", "tab_system" to "System",
        "tab_live" to "Live", "tab_thermal" to "Thermal", "tab_stress" to "Stress",
        "tab_tools" to "Tools", "tab_settings" to "Settings",
        "thermal_cpu" to "CPU", "thermal_gpu" to "GPU", "thermal_bat" to "Battery",
        "thermal_now" to "Now", "thermal_min" to "Min", "thermal_max" to "Max",
        "thermal_all" to "All thermal zones",
        "thermal_none" to "Thermal sensors not readable on this device (restricted).",
        "thermal_status" to "System thermal status",
        "stress_title" to "Stress Test",
        "stress_cpu" to "CPU Stress", "stress_gpu" to "GPU Stress",
        "stress_both" to "Combined (CPU + GPU)", "stress_stop" to "STOP",
        "stress_duration" to "Duration (seconds)",
        "stress_idle" to "Ready. Start a test.",
        "stress_running" to "Test running…",
        "stress_done" to "Test complete",
        "stress_peak" to "Peak temperatures",
        "stress_start" to "START",
        "tools_vib" to "Vibrate", "tools_torch" to "Torch",
        "tools_beep" to "Beep", "tools_color" to "Dead pixel test",
        "tools_touch" to "Multi-touch", "tools_cpu" to "CPU benchmark",
        "tools_disk" to "Storage speed", "tools_shortcuts" to "Settings shortcuts",
        "tools_copy" to "Copy report", "tools_share" to "Share report",
        "tools_brightness" to "Brightness (app only)",
        "st_lang" to "Language", "st_about" to "About",
        "st_about_body" to "PhoneInfo v2.0\nDevice info, thermal monitor and stress test.",
        "st_recreate" to "Language changed, restarting…",
        "first_lang" to "Language / Dil",
        "copy_done" to "Copied"
    )
    fun g(l: String, k: String): String = (if (l == "en") en else tr)[k] ?: k
}

// ═══════════════════════════ MainActivity ═══════════════════════════
@Suppress("DEPRECATION", "MissingPermission", "HardwareIds", "NewApi")
class MainActivity : Activity(), SensorEventListener {

    // ── Renkler ──
    private val C_BG       = 0xFFF2F4F7.toInt()
    private val C_CARD     = 0xFFFFFFFF.toInt()
    private val C_PRIMARY  = 0xFF4CAF50.toInt()
    private val C_PRIM_DK  = 0xFF2E7D32.toInt()
    private val C_ACCENT   = 0xFF34C759.toInt()
    private val C_TEXT     = 0xFF1A1D21.toInt()
    private val C_SUB      = 0xFF6B7280.toInt()
    private val C_WARN     = 0xFFFF9800.toInt()
    private val C_DANGER   = 0xFFF44336.toInt()
    private val C_BLUE     = 0xFF2196F3.toInt()

    // ── Görünüm ──
    private lateinit var contentArea: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabBar: LinearLayout
    private lateinit var titleTv: TextView
    private var currentTab = ""

    // ── Sistem ──
    private lateinit var sm: SensorManager
    private lateinit var prefs: SharedPreferences
    private var lang = "tr"
    private var torch = false

    // ── Termal ──
    private val ui = Handler(Looper.getMainLooper())
    private var thermalRunning = false
    private val peaks = HashMap<String, Double>()
    private val mins  = HashMap<String, Double>()
    private var tempCpuTv: TextView? = null
    private var tempGpuTv: TextView? = null
    private var tempBatTv: TextView? = null
    private var tempCpuSub: TextView? = null
    private var tempGpuSub: TextView? = null
    private var tempBatSub: TextView? = null
    private var zoneContainer: LinearLayout? = null

    // ── Yük testi ──
    private var stressRunning = false
    private val stressThreads = mutableListOf<Thread>()
    private var stressStart = 0L
    private var stressStatusTv: TextView? = null
    private var gpuDialog: Dialog? = null
    private var stressMetrics: LinearLayout? = null
    private var stressDuration = 60

    // ── Canlı sensör ──
    private val liveVals = LinkedHashMap<String, String>()
    private var liveTv: TextView? = null
    private var lastUiTick = 0L

    private fun s(k: String) = L.g(lang, k)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("phoneinfo", MODE_PRIVATE)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        lang = prefs.getString("lang", "") ?: ""
        if (lang.isEmpty()) askLangFirst() else buildUi()
    }

    private fun askLangFirst() {
        AlertDialog.Builder(this)
            .setTitle(s("first_lang"))
            .setCancelable(false)
            .setItems(arrayOf("Türkçe", "English")) { _, i ->
                lang = if (i == 0) "tr" else "en"
                prefs.edit().putString("lang", lang).apply()
                buildUi()
            }.show()
    }

    // ═══════════════ Ana UI kurulumu ═══════════════
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
        }

        // ── Başlık çubuğu ──
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(10))
        }
        titleTv = TextView(this).apply {
            text = s("app")
            setTextColor(C_TEXT)
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val settingsBtn = TextView(this).apply {
            text = "⚙"
            textSize = 22f
            setTextColor(C_PRIM_DK)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { showTab(s("tab_settings")) }
        }
        topBar.addView(titleTv)
        topBar.addView(settingsBtn)
        root.addView(topBar)

        // ── Sekmeler ──
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabs = listOf(
            s("tab_device"), s("tab_display"), s("tab_cpu"), s("tab_battery"),
            s("tab_net"), s("tab_sensors"), s("tab_camera"), s("tab_apps"),
            s("tab_system"), s("tab_live"), s("tab_thermal"), s("tab_stress"),
            s("tab_tools"), s("tab_settings")
        )
        tabs.forEach { t ->
            tabBar.addView(tabButton(t) { showTab(t) })
        }
        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(8), 0, dp(8), dp(6))
            addView(tabBar)
        }
        root.addView(tabScroll)

        // ── İçerik alanı ──
        contentArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(C_BG)
            addView(contentArea)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 23) {
            val p = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_PHONE_STATE
            )
            if (Build.VERSION.SDK_INT >= 31) p.add("android.permission.BLUETOOTH_CONNECT")
            requestPermissions(p.toTypedArray(), 1)
        }

        showTab(s("tab_device"))
    }

    private fun tabButton(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 13f
            setTextColor(C_PRIM_DK)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(if (text == currentTab) C_PRIMARY else C_CARD)
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0x22000000)
            }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = lp
            setOnClickListener { action() }
        }
    }

    private fun refreshTabs() {
        (0 until tabBar.childCount).forEach { i ->
            val v = tabBar.getChildAt(i)
            if (v is Button) {
                val active = v.text == currentTab
                v.background = GradientDrawable().apply {
                    setColor(if (active) C_PRIMARY else C_CARD)
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), 0x22000000)
                }
                v.setTextColor(if (active) Color.WHITE else C_PRIM_DK)
            }
        }
    }

    // ═══════════════ Sekme yönlendirme ═══════════════
    private fun showTab(name: String) {
        // eski sekme temizliği
        if (currentTab == s("tab_live")) stopLive()
        if (currentTab == s("tab_thermal") || currentTab == s("tab_stress")) stopThermal()
        stopStress()

        currentTab = name
        refreshTabs()
        contentArea.removeAllViews()   // ⬅️ KRİTİK: her seferinde temizle

        when (name) {
            s("tab_device")   -> showInfo(s("tab_device")) { device() }
            s("tab_display")  -> showInfo(s("tab_display")) { display() }
            s("tab_cpu")      -> showInfo(s("tab_cpu")) { cpu() }
            s("tab_battery")  -> showInfo(s("tab_battery")) { battery() }
            s("tab_net")      -> showInfo(s("tab_net")) { net() }
            s("tab_sensors")  -> showInfo(s("tab_sensors")) { sensors() }
            s("tab_camera")   -> showInfo(s("tab_camera")) { camera() }
            s("tab_apps")     -> showInfo(s("tab_apps")) { apps() }
            s("tab_system")   -> showInfo(s("tab_system")) { systemInfo() }
            s("tab_live")     -> showLive()
            s("tab_thermal")  -> showThermalPage()
            s("tab_stress")   -> showStressPage()
            s("tab_tools")    -> showToolsPage()
            s("tab_settings") -> showSettingsPage()
        }
        (contentArea.parent as? ScrollView)?.scrollTo(0, 0)
    }

    override fun onPause() {
        super.onPause()
        stopLive(); stopThermal(); stopStress()
    }
    override fun onResume() {
        super.onResume()
        if (currentTab == s("tab_live")) startLive()
        if (currentTab == s("tab_thermal")) startThermal()
    }

    // ═══════════════ Yardımcı view builders ═══════════════
    private fun card(title: String? = null, accent: Int = C_PRIMARY): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(C_CARD)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0x11000000)
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(dp(10), dp(6), dp(10), dp(6))
            layoutParams = lp
        }
        if (title != null) {
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            head.addView(View(this).apply {
                background = GradientDrawable().apply {
                    setColor(accent); cornerRadius = dp(3).toFloat()
                }
                layoutParams = LinearLayout.LayoutParams(dp(4), dp(18)).apply { rightMargin = dp(10) }
            })
            head.addView(TextView(this).apply {
                text = title
                setTextColor(C_PRIM_DK)
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
            })
            card.addView(head)
            card.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(10)) })
        }
        return card
    }

    private fun kvRow(label: String, value: String, valueColor: Int = C_TEXT): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, dp(5))
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(C_SUB)
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = value
                setTextColor(valueColor)
                textSize = 13f
                gravity = Gravity.END
                setTypeface(null, Typeface.BOLD)
            })
        }
    }

    private fun tempCard(title: String, accent: Int): Triple<LinearLayout, TextView, TextView> {
        val c = card(title, accent)
        val bigVal = TextView(this).apply {
            text = "--"
            setTextColor(C_TEXT)
            textSize = 34f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = ""
            setTextColor(C_SUB)
            textSize = 11f
            gravity = Gravity.CENTER
        }
        c.addView(bigVal)
        c.addView(sub)
        return Triple(c, bigVal, sub)
    }

    private fun tempColor(t: Double): Int = when {
        t < 45 -> C_ACCENT
        t < 60 -> 0xFFCDDC39.toInt()
        t < 75 -> C_WARN
        else -> C_DANGER
    }

    // ═══════════════ Bilgi sayfaları ═══════════════
    private fun showInfo(title: String, body: () -> String) {
        val c = card(title)
        val tv = TextView(this).apply {
            text = body()
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(C_TEXT)
            setTextIsSelectable(true)
        }
        c.addView(tv)
        contentArea.addView(c)
    }

    // ═══════════════ Bilgi içerikleri ═══════════════
    private fun device() = buildString {
        h("Kimlik"); kv("Üretici", Build.MANUFACTURER); kv("Marka", Build.BRAND)
        kv("Model", Build.MODEL); kv("Cihaz", Build.DEVICE); kv("Ürün", Build.PRODUCT)
        kv("Donanım", Build.HARDWARE)
        if (Build.VERSION.SDK_INT >= 31) { kv("SoC üretici", Build.SOC_MANUFACTURER); kv("SoC model", Build.SOC_MODEL) }
        kv("Android ID", Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID))
        h("Yazılım"); kv("Android", Build.VERSION.RELEASE); kv("API", Build.VERSION.SDK_INT)
        kv("Yama", Build.VERSION.SECURITY_PATCH); kv("Build ID", Build.ID)
        kv("Fingerprint", Build.FINGERPRINT); kv("Bootloader", Build.BOOTLOADER)
        kv("Radyo", Build.getRadioVersion()); kv("Build zamanı", Date(Build.TIME).toString())
        kv("Çekirdek", System.getProperty("os.version"))
        kv("ABI", Build.SUPPORTED_ABIS.joinToString())
        h("Zaman / Dil"); kv("Dil", Locale.getDefault().toString())
        kv("Saat dilimi", TimeZone.getDefault().id)
        kv("Açık kalma", dur(SystemClock.elapsedRealtime()))
        kv("Şimdi", Date().toString())
    }
    private fun StringBuilder.h(t: String) { append("\n━━ $t ━━\n") }
    private fun StringBuilder.kv(k: String, v: Any?) { append(k).append(": ").append(v ?: "-").append('\n') }

    private fun display() = buildString {
        val d = windowManager.defaultDisplay
        val dm = DisplayMetrics(); d.getRealMetrics(dm)
        val ap = resources.displayMetrics
        h("Çözünürlük")
        kv("Gerçek", "${dm.widthPixels} x ${dm.heightPixels}")
        kv("Uygulama", "${ap.widthPixels} x ${ap.heightPixels}")
        kv("Yoğunluk", "${dm.densityDpi} dpi")
        kv("xdpi / ydpi", "${"%.1f".format(dm.xdpi)} / ${"%.1f".format(dm.ydpi)}")
        val wi = dm.widthPixels / dm.xdpi; val hi = dm.heightPixels / dm.ydpi
        kv("Boyut (inç)", "%.2f".format(sqrt((wi * wi + hi * hi).toDouble())))
        kv("Font ölçeği", resources.configuration.fontScale)
        kv("HDR", resources.configuration.isScreenHdr)
        h("Yenileme")
        kv("Şu an", "${d.refreshRate} Hz")
        d.supportedModes.forEach { m ->
            kv("Mod ${m.modeId}", "${m.physicalWidth}x${m.physicalHeight} @ ${"%.1f".format(m.refreshRate)} Hz")
        }
    }

    private fun cpu() = buildString {
        h("İşlemci")
        val n = Runtime.getRuntime().availableProcessors()
        kv("Çekirdek", n)
        kv("Mimari", System.getProperty("os.arch"))
        val ci = rd("/proc/cpuinfo") ?: ""
        Regex("Hardware\\s*:\\s*(.*)").find(ci)?.groupValues?.get(1)?.let { kv("Hardware", it) }
        for (i in 0 until n) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            kv("CPU$i", "${mhz(rd(b+"scaling_cur_freq"))} / max ${mhz(rd(b+"cpuinfo_max_freq"))}")
        }
        h("RAM")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        kv("Toplam", fmt(mi.totalMem)); kv("Boş", fmt(mi.availMem))
        h("Depolama")
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            kv("Dahili", "${fmt(st.availableBytes)} boş / ${fmt(st.totalBytes)}")
        } catch (e: Throwable) {}
    }

    private fun battery() = buildString {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))!!
        val sc = i.getIntExtra("scale", 100)
        h("Pil")
        kv("Seviye", "%${i.getIntExtra("level", -1) * 100 / sc}")
        kv("Durum", mapOf(2 to "Şarj oluyor", 3 to "Boşalıyor", 4 to "Şarj yok", 5 to "Dolu")
            .getOrDefault(i.getIntExtra("status", 1), "?"))
        kv("Sağlık", mapOf(2 to "İyi", 3 to "Aşırı ısınma", 4 to "Ölü", 5 to "Aşırı voltaj", 6 to "Hata", 7 to "Soğuk")
            .getOrDefault(i.getIntExtra("health", 1), "?"))
        kv("Voltaj", "${i.getIntExtra("voltage", 0)} mV")
        kv("Sıcaklık", "${i.getIntExtra("temperature", 0) / 10.0} °C")
        kv("Teknoloji", i.getStringExtra("technology"))
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        kv("Şarj sayacı", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000} mAh")
        kv("Anlık akım", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000} mA")
    }

    private fun net() = buildString {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        h("Aktif bağlantı")
        if (n == null) kv("Durum", "Yok") else {
            cm.getNetworkCapabilities(n)?.let { c ->
                val list = mutableListOf<String>()
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) list.add("Wi-Fi")
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) list.add("Hücresel")
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) list.add("VPN")
                kv("Tür", list.joinToString())
                kv("İndirilen", "${c.linkDownstreamBandwidthKbps / 1000} Mbps")
                kv("İnternet", c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
            }
            cm.getLinkProperties(n)?.let { lp ->
                kv("Arayüz", lp.interfaceName)
                kv("DNS", lp.dnsServers.joinToString { it.hostAddress ?: "" })
            }
        }
        h("Wi-Fi")
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val wi = wm.connectionInfo
            kv("SSID", wi.ssid); kv("Sinyal", "${wi.rssi} dBm")
            kv("Hız", "${wi.linkSpeed} Mbps"); kv("Frekans", "${wi.frequency} MHz")
            kv("IP", ip(wi.ipAddress))
        } catch (e: Throwable) { kv("Wi-Fi", e.message) }
        h("Operatör")
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            kv("Operatör", tm.networkOperatorName)
            kv("SIM", tm.simOperatorName)
        } catch (e: Throwable) {}
    }

    private fun sensors() = buildString {
        val l = sm.getSensorList(Sensor.TYPE_ALL)
        append("Toplam: ${l.size}\n")
        l.forEach { s ->
            append("\n• ${s.name}\n  ${s.stringType}\n  ${s.vendor} v${s.version}\n")
            append("  aralık=${s.maximumRange}  çöz=${s.resolution}  güç=${s.power}mA\n")
        }
    }

    private fun camera() = buildString {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        kv("Kamera sayısı", cm.cameraIdList.size)
        cm.cameraIdList.forEach { id ->
            val c = cm.getCameraCharacteristics(id)
            h("Kamera $id")
            kv("Yön", when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Ön"
                CameraCharacteristics.LENS_FACING_BACK -> "Arka"
                else -> "Harici"
            })
            kv("Sensör boyutu", c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let { "${it.width}x${it.height}" })
            kv("Odak uzaklığı", c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString())
        }
    }

    private fun apps() = buildString {
        val pk = packageManager.getInstalledPackages(0)
        fun sys(p: PackageInfo) = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
        kv("Toplam", pk.size)
        kv("Sistem", pk.count { sys(it) })
        kv("Kullanıcı", pk.count { !sys(it) })
        h("Kullanıcı uygulamaları")
        pk.filter { !sys(it) }.sortedBy { it.packageName }.take(80).forEach {
            val lbl = it.applicationInfo?.let { a -> packageManager.getApplicationLabel(a) }
            append("$lbl — ${it.packageName}\n")
        }
    }

    private fun systemInfo() = buildString {
        h("Özellikler")
        packageManager.systemAvailableFeatures.mapNotNull { it.name }.sorted().take(60).forEach { append(it).append('\n') }
        h("Kodekler")
        MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.take(40).forEach { c ->
            append("${if (c.isEncoder) "[E]" else "[D]"} ${c.name}\n")
        }
        h("Güvenlik")
        kv("Root", listOf("/system/bin/su","/system/xbin/su","/sbin/su")
            .filter { File(it).exists() }.ifEmpty { listOf("yok") })
        kv("ADB", Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0))
        kv("SELinux", sh("getenforce"))
        h("getprop")
        append(sh("getprop").lines().sorted().take(60).joinToString("\n"))
    }

    // ═══════════════ Canlı sensör ═══════════════
    private fun showLive() {
        val c = card(s("tab_live"))
        liveTv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(C_TEXT)
            text = "…"
        }
        c.addView(liveTv)
        contentArea.addView(c)
        startLive()
    }

    private fun startLive() {
        liveVals.clear()
        intArrayOf(
            Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY, Sensor.TYPE_PRESSURE,
            Sensor.TYPE_GRAVITY, Sensor.TYPE_AMBIENT_TEMPERATURE,
            Sensor.TYPE_RELATIVE_HUMIDITY, Sensor.TYPE_ROTATION_VECTOR
        ).forEach { t -> sm.getDefaultSensor(t)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    }
    private fun stopLive() { sm.unregisterListener(this) }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        liveVals[e.sensor.stringType.substringAfterLast('.') + " • " + e.sensor.name] =
            e.values.joinToString("   ") { "%.3f".format(it) }
        val n = SystemClock.elapsedRealtime()
        if (n - lastUiTick < 150) return
        lastUiTick = n
        if (currentTab == s("tab_live")) {
            liveTv?.text = liveVals.entries.joinToString("\n\n") { "${it.key}\n   ${it.value}" }
        }
    }

    // ═══════════════ TERMAL SAYFASI ═══════════════
    private fun showThermalPage() {
        // CPU kartı
        val (c1, v1, s1) = tempCard(s("thermal_cpu"), C_PRIMARY)
        tempCpuTv = v1; tempCpuSub = s1
        contentArea.addView(c1)

        // GPU kartı
        val (c2, v2, s2) = tempCard(s("thermal_gpu"), C_BLUE)
        tempGpuTv = v2; tempGpuSub = s2
        contentArea.addView(c2)

        // Pil kartı
        val (c3, v3, s3) = tempCard(s("thermal_bat"), C_WARN)
        tempBatTv = v3; tempBatSub = s3
        contentArea.addView(c3)

        // Tüm bölgeler
        val c4 = card(s("thermal_all"))
        val zoneList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        zoneContainer = zoneList
        c4.addView(zoneList)
        contentArea.addView(c4)

        startThermal()
    }

    private fun startThermal() {
        if (thermalRunning) return
        thermalRunning = true
        ui.post(thermalTick)
    }
    private fun stopThermal() {
        thermalRunning = false
        ui.removeCallbacks(thermalTick)
    }

    private val thermalTick = object : Runnable {
        override fun run() {
            if (!thermalRunning) return
            val (cpuT, gpuT, batT, zones) = readTemps()

            listOf("cpu" to cpuT, "gpu" to gpuT, "bat" to batT).forEach { (k, v) ->
                if (v != null && v > 0) {
                    peaks[k] = max(peaks[k] ?: v, v)
                    mins[k]  = min(mins[k]  ?: v, v)
                }
            }

            tempCpuTv?.text = cpuT?.let { "%.1f°C".format(it) } ?: "--"
            tempCpuTv?.setTextColor(cpuT?.let { tempColor(it) } ?: C_SUB)
            tempCpuSub?.text = cpuT?.let {
                "${s("thermal_min")}: %.1f°  •  ${s("thermal_max")}: %.1f°".format(mins["cpu"], peaks["cpu"])
            } ?: ""

            tempGpuTv?.text = gpuT?.let { "%.1f°C".format(it) } ?: "--"
            tempGpuTv?.setTextColor(gpuT?.let { tempColor(it) } ?: C_SUB)
            tempGpuSub?.text = gpuT?.let {
                "${s("thermal_min")}: %.1f°  •  ${s("thermal_max")}: %.1f°".format(mins["gpu"], peaks["gpu"])
            } ?: ""

            tempBatTv?.text = batT?.let { "%.1f°C".format(it) } ?: "--"
            tempBatTv?.setTextColor(batT?.let { tempColor(it) } ?: C_SUB)
            tempBatSub?.text = batT?.let {
                "${s("thermal_min")}: %.1f°  •  ${s("thermal_max")}: %.1f°".format(mins["bat"], peaks["bat"])
            } ?: ""

            zoneContainer?.let { zc ->
                zc.removeAllViews()
                if (zones.isEmpty()) {
                    zc.addView(TextView(this@MainActivity).apply {
                        text = s("thermal_none")
                        setTextColor(C_SUB)
                        textSize = 12f
                    })
                } else {
                    zones.sortedByDescending { it.temp }.forEach { z ->
                        zc.addView(kvRow(
                            "${z.name}  ${z.type.take(18)}",
                            "%.1f°C".format(z.temp),
                            tempColor(z.temp)
                        ))
                    }
                }
            }

            ui.postDelayed(this, 1000)
        }
    }

    private data class Temps(
        val cpu: Double?, val gpu: Double?, val bat: Double?, val zones: List<Tz>
    )

    private fun readTemps(): Temps {
        val zones = readThermalZones()
        val cpu = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
            ?: zones.filter { it.type.contains("tsens", true) }.maxByOrNull { it.temp }?.temp
        val gpu = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp
            ?: extraGpuTemp()
        val bat = batteryTemp()
        return Temps(cpu, gpu, bat, zones)
    }

    private fun batteryTemp(): Double? = try {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i?.getIntExtra("temperature", 0)?.div(10.0)?.takeIf { it > -20 && it < 100 }
    } catch (e: Throwable) { null }

    // ═══════════════ YÜK TESTİ ═══════════════
    private fun showStressPage() {
        val durationCard = card(s("stress_duration"))
        val durValueTv = TextView(this).apply {
            text = "$stressDuration s"
            setTextColor(C_PRIM_DK)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val seek = SeekBar(this).apply {
            max = 295          // 5..300
            progress = stressDuration - 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    stressDuration = p + 5
                    durValueTv.text = "$stressDuration s"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        durationCard.addView(durValueTv)
        durationCard.addView(seek)
        contentArea.addView(durationCard)

        val btnCard = card()
        btnCard.addView(bigButton(s("stress_cpu"),   C_PRIMARY) { startStress("cpu") })
        btnCard.addView(bigButton(s("stress_gpu"),   C_BLUE)    { startStress("gpu") })
        btnCard.addView(bigButton(s("stress_both"),  C_WARN)    { startStress("both") })
        contentArea.addView(btnCard)

        val statusCard = card(s("stress_title"))
        stressStatusTv = TextView(this).apply {
            text = s("stress_idle")
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(C_TEXT)
        }
        statusCard.addView(stressStatusTv)
        stressMetrics = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusCard.addView(stressMetrics)
        contentArea.addView(statusCard)
    }

    private fun bigButton(text: String, color: Int, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(14).toFloat()
            }
            val lp = LinearLayout.LayoutParams(-1, dp(52))
            lp.setMargins(0, dp(4), 0, dp(4))
            layoutParams = lp
            setOnClickListener { action() }
        }
    }

    private fun startStress(mode: String) {
        if (stressRunning) return
        stressRunning = true
        stressStart = SystemClock.elapsedRealtime()
        peaks.clear(); mins.clear()

        val useCpu = mode == "cpu" || mode == "both"
        val useGpu = mode == "gpu" || mode == "both"
        val cores = Runtime.getRuntime().availableProcessors()
        val durMs = stressDuration * 1000L

        // GPU penceresi
        if (useGpu) {
            gpuDialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
                val wrapper = FrameLayout(this@MainActivity)
                val gv = GpuStressView(this@MainActivity)
                wrapper.addView(gv, FrameLayout.LayoutParams(-1, -1))
                val stopBtn = Button(this@MainActivity).apply {
                    text = s("stress_stop")
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    background = GradientDrawable().apply {
                        setColor(0xCCF44336.toInt()); cornerRadius = dp(24).toFloat()
                    }
                    setOnClickListener { stopStress() }
                }
                val lp = FrameLayout.LayoutParams(dp(140), dp(50), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                lp.bottomMargin = dp(40)
                wrapper.addView(stopBtn, lp)
                setContentView(wrapper)
                setCancelable(false)
                show()
            }
        }

        // CPU iş parçacıkları
        if (useCpu) {
            for (i in 0 until cores) {
                val t = Thread {
                    var x = 1.0 + i
                    val end = SystemClock.elapsedRealtime() + durMs
                    val rnd = Random(i)
                    while (stressRunning && SystemClock.elapsedRealtime() < end) {
                        for (j in 0 until 30000) {
                            x = Math.sin(x * 1.0000001) * Math.cos(x * 0.9999999) + rnd.nextDouble() * 1e-7
                        }
                    }
                }
                t.priority = Thread.MAX_PRIORITY
                t.start()
                stressThreads.add(t)
            }
        }

        // Sayaç
        val updater = object : Runnable {
            override fun run() {
                if (!stressRunning) return
                val el = (SystemClock.elapsedRealtime() - stressStart) / 1000
                val (cpuT, gpuT, batT, _) = readTemps()
                listOf("cpu" to cpuT, "gpu" to gpuT, "bat" to batT).forEach { (k, v) ->
                    if (v != null && v > 0) {
                        peaks[k] = max(peaks[k] ?: v, v)
                        mins[k]  = min(mins[k]  ?: v, v)
                    }
                }

                val sb = StringBuilder()
                sb.append(s("stress_running")).append("\n")
                sb.append("Süre: $el / $stressDuration s\n")
                if (useCpu) sb.append("CPU thread: $cores\n")
                if (useGpu) sb.append("GPU: aktif\n")
                stressStatusTv?.text = sb.toString()

                stressMetrics?.let { sm ->
                    sm.removeAllViews()
                    sm.addView(kvRow(s("thermal_cpu"),
                        cpuT?.let { "%.1f°C".format(it) } ?: "--",
                        cpuT?.let { tempColor(it) } ?: C_SUB))
                    sm.addView(kvRow(s("thermal_gpu"),
                        gpuT?.let { "%.1f°C".format(it) } ?: "--",
                        gpuT?.let { tempColor(it) } ?: C_SUB))
                    sm.addView(kvRow(s("thermal_bat"),
                        batT?.let { "%.1f°C".format(it) } ?: "--",
                        batT?.let { tempColor(it) } ?: C_SUB))
                }

                if (SystemClock.elapsedRealtime() - stressStart < durMs) {
                    ui.postDelayed(this, 1000)
                } else {
                    finishStress()
                }
            }
        }
        ui.post(updater)
    }

    private fun stopStress() {
        stressRunning = false
        stressThreads.forEach { runCatching { it.interrupt() } }
        stressThreads.clear()
        gpuDialog?.dismiss(); gpuDialog = null
    }

    private fun finishStress() {
        stressRunning = false
        stressThreads.forEach { runCatching { it.interrupt() } }
        stressThreads.clear()
        gpuDialog?.dismiss(); gpuDialog = null
        stressStatusTv?.text = buildString {
            append(s("stress_done")).append("\n\n")
            append(s("stress_peak")).append(":\n")
            append("  CPU: ").append(peaks["cpu"]?.let { "%.1f°C".format(it) } ?: "--").append('\n')
            append("  GPU: ").append(peaks["gpu"]?.let { "%.1f°C".format(it) } ?: "--").append('\n')
            append("  BAT: ").append(peaks["bat"]?.let { "%.1f°C".format(it) } ?: "--")
        }
    }

    // GPU stress — GLSurfaceView
    private class GpuStressView(ctx: Context) : GLSurfaceView(ctx), GLSurfaceView.Renderer {
        private var prog = 0
        private var tLoc = 0
        private var startT = SystemClock.elapsedRealtime()
        private val verts: FloatBuffer = ByteBuffer.allocateDirect(6 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f,-1f, 3f,-1f, -1f,3f)); position(0)
            }
        init {
            setEGLContextClientVersion(2)
            setRenderer(this)
            renderMode = RENDERMODE_CONTINUOUSLY
        }
        override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
            val vs = "attribute vec2 p; void main(){ gl_Position=vec4(p,0.0,1.0); }"
            val fs = """
                precision highp float;
                uniform float uTime;
                void main(){
                    vec2 q = gl_FragCoord.xy * 0.005;
                    float a = 0.0;
                    for (int i=0;i<500;i++){
                        float fi = float(i);
                        a += sin(q.x*fi*0.02 + uTime*2.0) * cos(q.y*fi*0.023 - uTime*1.5);
                        a += sqrt(abs(sin(fi + uTime) + 1.0)) * 0.001;
                    }
                    float r = abs(a)*0.008 + 0.3 + 0.2*sin(uTime);
                    float g = 0.5 + 0.3*cos(uTime*0.7);
                    float b = 0.7 + 0.2*sin(uTime*1.3);
                    gl_FragColor = vec4(r, g, b, 1.0);
                }
            """.trimIndent()
            val v = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER).also {
                GLES20.glShaderSource(it, vs); GLES20.glCompileShader(it)
            }
            val f = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER).also {
                GLES20.glShaderSource(it, fs); GLES20.glCompileShader(it)
            }
            prog = GLES20.glCreateProgram().also {
                GLES20.glAttachShader(it, v); GLES20.glAttachShader(it, f); GLES20.glLinkProgram(it)
            }
            tLoc = GLES20.glGetUniformLocation(prog, "uTime")
            GLES20.glClearColor(0.05f, 0.08f, 0.12f, 1f)
        }
        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { GLES20.glViewport(0,0,w,h) }
        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(prog)
            val a = GLES20.glGetAttribLocation(prog, "p")
            GLES20.glEnableVertexAttribArray(a)
            GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, verts)
            GLES20.glUniform1f(tLoc, (SystemClock.elapsedRealtime() - startT) / 1000f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            GLES20.glDisableVertexAttribArray(a)
        }
    }

    // ═══════════════ ARAÇLAR ═══════════════
    private fun showToolsPage() {
        val c = card(s("tab_tools"))
        fun addTool(t: String, f: () -> Unit) {
            c.addView(bigButton(t, 0xFFF2F4F7.toInt()) {
                f()
            }.apply { setTextColor(C_PRIM_DK) })
        }
        addTool(s("tools_vib"))       { vibrate() }
        addTool(s("tools_torch"))     { toggleTorch() }
        addTool(s("tools_beep"))      { ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 400) }
        addTool(s("tools_color"))     { colorTest() }
        addTool(s("tools_touch"))     { touchTest() }
        addTool(s("tools_cpu"))       { cpuBench() }
        addTool(s("tools_disk"))      { diskBench() }
        addTool(s("tools_shortcuts")) { settingsMenu() }
        addTool(s("tools_copy")) {
            val r = fullReport()
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("report", r))
            Toast.makeText(this, s("copy_done"), Toast.LENGTH_SHORT).show()
        }
        addTool(s("tools_share")) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, fullReport().take(200_000)), "Share"))
        }
        contentArea.addView(c)

        val bright = card(s("tools_brightness"))
        bright.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    val lp = window.attributes
                    lp.screenBrightness = max(p, 1) / 100f
                    window.attributes = lp
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
        contentArea.addView(bright)
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0,200,100,200,100,500), -1))
        else v.vibrate(500)
    }
    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torch = !torch
            cm.setTorchMode(id, torch)
        } catch (e: Throwable) {}
    }
    private fun colorTest() {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val cols = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.GRAY)
        var i = 0
        val v = View(this).apply {
            setBackgroundColor(cols[0])
            setOnClickListener { i++; if (i >= cols.size) dlg.dismiss() else setBackgroundColor(cols[i]) }
        }
        dlg.setContentView(v); dlg.show()
    }
    private fun touchTest() {
        Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
            setContentView(TouchView(this@MainActivity)); show()
        }
    }
    inner class TouchView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 44f }
        private val pts = HashMap<Int, PointF>()
        private var maxPts = 0
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) pts.clear()
            else { pts.clear(); for (i in 0 until e.pointerCount) pts[e.getPointerId(i)] = PointF(e.getX(i), e.getY(i)); maxPts = max(maxPts, e.pointerCount) }
            invalidate(); return true
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(Color.BLACK); p.color = Color.WHITE
            c.drawText("${pts.size} / $maxPts", 20f, 90f, p)
            p.color = Color.CYAN; pts.values.forEach { c.drawCircle(it.x, it.y, 90f, p) }
        }
    }
    private fun work(): Int { var c = 0; for (n in 2..400_000) { var d = 2; var p = true; while (d*d <= n) { if (n % d == 0) { p = false; break }; d++ }; if (p) c++ }; return c }
    private fun cpuBench() {
        Toast.makeText(this, "…", Toast.LENGTH_SHORT).show()
        Thread {
            val t0 = System.nanoTime(); work(); val single = (System.nanoTime() - t0) / 1_000_000
            val n = Runtime.getRuntime().availableProcessors()
            val t1 = System.nanoTime()
            List(n) { Thread { work() }.also { it.start() } }.forEach { it.join() }
            val multi = (System.nanoTime() - t1) / 1_000_000
            ui.post { Toast.makeText(this,
                "1C: $single ms\n${n}C: $multi ms\nx${"%.2f".format(single.toDouble()*n/multi)}",
                Toast.LENGTH_LONG).show() }
        }.start()
    }
    private fun diskBench() {
        Thread {
            try {
                val f = File(cacheDir, "bench.bin")
                val buf = ByteArray(1 shl 20) { it.toByte() }
                val mb = 64
                var t = System.nanoTime()
                java.io.FileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.fd.sync() }
                val w = mb / ((System.nanoTime() - t) / 1e9)
                t = System.nanoTime()
                java.io.FileInputStream(f).use { i -> while (i.read(buf) > 0) {} }
                val r = mb / ((System.nanoTime() - t) / 1e9)
                f.delete()
                ui.post { Toast.makeText(this, "W %.0f MB/s\nR %.0f MB/s".format(w, r), Toast.LENGTH_LONG).show() }
            } catch (e: Throwable) {}
        }.start()
    }
    private fun settingsMenu() {
        val items = listOf(
            "Device info" to Settings.ACTION_DEVICE_INFO_SETTINGS,
            "Developer" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "Battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Wireless" to Settings.ACTION_WIRELESS_SETTINGS,
            "Display" to Settings.ACTION_DISPLAY_SETTINGS,
            "Storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
            "Apps" to Settings.ACTION_APPLICATION_SETTINGS
        )
        AlertDialog.Builder(this).setItems(items.map { it.first }.toTypedArray()) { _, w ->
            runCatching { startActivity(Intent(items[w].second)) }
        }.show()
    }

    // ═══════════════ AYARLAR ═══════════════
    private fun showSettingsPage() {
        val c = card(s("st_lang"), C_PRIMARY)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(langButton("Türkçe", "tr"))
        row.addView(langButton("English", "en"))
        c.addView(row)
        contentArea.addView(c)

        val about = card(s("st_about"), C_BLUE)
        about.addView(TextView(this).apply {
            text = s("st_about_body")
            setTextColor(C_TEXT); textSize = 13f
        })
        contentArea.addView(about)
    }

    private fun langButton(label: String, code: String): Button {
        val active = lang == code
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (active) Color.WHITE else C_PRIM_DK)
            background = GradientDrawable().apply {
                setColor(if (active) C_PRIMARY else C_CARD)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0x22000000)
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            layoutParams = lp
            setOnClickListener {
                prefs.edit().putString("lang", code).apply()
                Toast.makeText(this@MainActivity, s("st_recreate"), Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
    }

    private fun fullReport(): String = buildString {
        append("######## DEVICE ########\n").append(device()).append('\n')
        append("######## DISPLAY ########\n").append(display()).append('\n')
        append("######## CPU ########\n").append(cpu()).append('\n')
        append("######## BATTERY ########\n").append(battery()).append('\n')
        append("######## NETWORK ########\n").append(net()).append('\n')
    }
}