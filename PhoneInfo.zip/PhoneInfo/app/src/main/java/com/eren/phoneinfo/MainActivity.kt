package com.eren.phoneinfo

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.hardware.camera2.*
import android.media.*
import android.net.*
import android.net.wifi.WifiManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.*
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.*
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

// ──────────────────────────────────────────────────────────────
//  Yardımcılar
// ──────────────────────────────────────────────────────────────
private fun rd(p: String): String? = try { File(p).readText().trim() } catch (e: Throwable) { null }
private fun sh(c: String): String = try { Runtime.getRuntime().exec(arrayOf("sh", "-c", c)).inputStream.bufferedReader().readText().trim() } catch (e: Throwable) { "" }
private fun mhz(s: String?) = s?.toLongOrNull()?.let { "${it / 1000} MHz" } ?: "-"
private fun ip(i: Int) = "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
private fun fmt(b: Long): String { val u = arrayOf("B","KB","MB","GB","TB"); var v = b.toDouble(); var i = 0; while (v >= 1024 && i < 4) { v /= 1024; i++ }; return "%.2f %s".format(v, u[i]) }
private fun dur(ms: Long): String { val s = ms / 1000; return "${s/86400}g ${s/3600%24}s ${s/60%60}dk ${s%60}sn" }

data class Tz(val zone: String, val type: String, val temp: Double)

private fun readZones(): List<Tz> {
    val list = mutableListOf<Tz>()
    File("/sys/class/thermal").listFiles()?.forEach { f ->
        if (!f.name.startsWith("thermal_zone")) return@forEach
        val type = rd(f.path + "/type") ?: f.name
        val raw = rd(f.path + "/temp")?.toDoubleOrNull() ?: return@forEach
        val t = if (Math.abs(raw) > 200) raw / 1000.0 else raw
        list.add(Tz(f.name, type, t))
    }
    return list
}

private fun zoneKind(z: Tz): String {
    val t = z.type.lowercase()
    return when {
        t.contains("gpu") || t.contains("g3d") || t.contains("kgsl") || t.contains("mali") || t.contains("adreno") -> "gpu"
        t.contains("batt") || t.contains("bms") -> "bat"
        t.contains("cpu") || t.contains("soc") || t.contains("ap") || t.contains("tsens") ||
                t.contains("core") || t.contains("cluster") || t.contains("big") || t.contains("little") -> "cpu"
        else -> "other"
    }
}

private fun extraGpuTemp(): Double? {
    val paths = listOf(
        "/sys/class/kgsl/kgsl-3d0/temp",
        "/sys/class/kgsl/kgsl-3d0/devfreq/temp",
        "/sys/class/misc/mali0/device/temp",
        "/sys/kernel/gpu/gpu_temp"
    )
    for (p in paths) {
        val v = rd(p)?.toDoubleOrNull() ?: continue
        return if (Math.abs(v) > 200) v / 1000.0 else v
    }
    return null
}

// ──────────────────────────────────────────────────────────────
//  Tema paleti
// ──────────────────────────────────────────────────────────────
data class Palette(
    val bg: Int, val card: Int, val card2: Int, val stroke: Int,
    val text: Int, val sub: Int, val accent: Int, val accent2: Int,
    val danger: Int, val warn: Int, val ok: Int
)
private fun palette(dark: Boolean) = if (dark) Palette(
    bg = 0xFF0B0E13.toInt(),
    card = 0xFF151A23.toInt(),
    card2 = 0xFF1C2230.toInt(),
    stroke = 0xFF232B3A.toInt(),
    text = 0xFFE6EDF3.toInt(),
    sub = 0xFF8B949E.toInt(),
    accent = 0xFF4FC3F7.toInt(),
    accent2 = 0xFF7C4DFF.toInt(),
    danger = 0xFFF85149.toInt(),
    warn = 0xFFFFA726.toInt(),
    ok = 0xFF3FB950.toInt()
) else Palette(
    bg = 0xFFF5F7FA.toInt(),
    card = 0xFFFFFFFF.toInt(),
    card2 = 0xFFF0F4F8.toInt(),
    stroke = 0xFFE1E7ED.toInt(),
    text = 0xFF1F2937.toInt(),
    sub = 0xFF6B7280.toInt(),
    accent = 0xFF0288D1.toInt(),
    accent2 = 0xFF5E35B1.toInt(),
    danger = 0xFFD32F2F.toInt(),
    warn = 0xFFF57C00.toInt(),
    ok = 0xFF388E3C.toInt()
)

// ──────────────────────────────────────────────────────────────
//  Dil
// ──────────────────────────────────────────────────────────────
object L {
    private val tr = mapOf(
        "subtitle" to "Cihaz Teşhis Aracı",
        "tab_device" to "Cihaz", "tab_display" to "Ekran", "tab_cpu" to "CPU",
        "tab_battery" to "Pil", "tab_net" to "Ağ", "tab_sensors" to "Sensör",
        "tab_camera" to "Kamera", "tab_features" to "Özellik", "tab_apps" to "Uygulama",
        "tab_codecs" to "Kodek", "tab_security" to "Güvenlik", "tab_thermal" to "Isı",
        "tab_live" to "Canlı", "tab_stress" to "Yük", "tab_tools" to "Araçlar",
        "tab_settings" to "Ayarlar",
        "c_identity" to "Kimlik", "c_software" to "Yazılım", "c_time" to "Zaman",
        "c_resolution" to "Çözünürlük", "c_refresh" to "Yenileme",
        "c_cpu" to "İşlemci", "c_ram" to "Bellek (RAM)", "c_storage" to "Depolama",
        "c_temp" to "Sıcaklık", "c_battery" to "Pil", "c_power" to "Güç",
        "c_network" to "Bağlantı", "c_wifi" to "Wi-Fi", "c_cell" to "Hücresel",
        "c_ifaces" to "Ağ Arayüzleri",
        "st_title" to "Ayarlar",
        "st_appearance" to "Görünüm", "st_dark" to "Karanlık Mod",
        "st_lang" to "Dil", "st_refresh" to "Yenileme Hızı",
        "st_refresh_hint" to "Canlı verilerin güncellenme sıklığı",
        "st_about" to "Hakkında",
        "st_about_body" to "PhoneInfo v2.1\nModern cihaz teşhis aracı.\n\nTermal izleme, CPU/GPU yük testleri, sensör verileri ve çok daha fazlası.",
        "first_lang_title" to "Dil seçin / Choose language",
        "st_cpu" to "İşlemci (CPU)", "st_gpu" to "Grafik (GPU)", "st_bat" to "Pil",
        "st_now" to "Şu an", "st_min" to "Min", "st_max" to "Maks",
        "st_zones" to "Tüm termal bölgeler",
        "st_none" to "Termal sensör bulunamadı.",
        "st_stress_cpu" to "CPU Yük Testi", "st_stress_gpu" to "GPU Yük Testi",
        "st_stress_both" to "Birleşik Yük Testi", "st_stress_stop" to "Durdur",
        "st_stress_dur" to "Süre (saniye)", "st_stress_start" to "Başlat",
        "st_stress_idle" to "Hazır. Bir test başlatın.",
        "st_stress_running" to "Çalışıyor…", "st_stress_done" to "Test tamamlandı",
        "st_stress_threads" to "İş parçacığı", "st_stress_elapsed" to "Geçen süre",
        "st_stress_peak" to "Zirve sıcaklıklar",
        "tools_vib" to "📳 Titreşim", "tools_torch" to "🔦 Fener", "tools_beep" to "🔊 Bip",
        "tools_color" to "🖥 Ölü piksel", "tools_touch" to "👆 Çoklu dokunma",
        "tools_cpubench" to "⚡ CPU Benchmark", "tools_disk" to "💾 Depo Hızı",
        "tools_settings" to "⚙ Sistem Ayarları", "tools_copy" to "📋 Raporu Kopyala",
        "tools_share" to "📤 Raporu Paylaş", "tools_brightness" to "Parlaklık"
    )
    private val en = mapOf(
        "subtitle" to "Device Diagnostics Suite",
        "tab_device" to "Device", "tab_display" to "Display", "tab_cpu" to "CPU",
        "tab_battery" to "Battery", "tab_net" to "Network", "tab_sensors" to "Sensors",
        "tab_camera" to "Camera", "tab_features" to "Features", "tab_apps" to "Apps",
        "tab_codecs" to "Codecs", "tab_security" to "Security", "tab_thermal" to "Thermal",
        "tab_live" to "Live", "tab_stress" to "Stress", "tab_tools" to "Tools",
        "tab_settings" to "Settings",
        "c_identity" to "Identity", "c_software" to "Software", "c_time" to "Time",
        "c_resolution" to "Resolution", "c_refresh" to "Refresh",
        "c_cpu" to "Processor", "c_ram" to "Memory (RAM)", "c_storage" to "Storage",
        "c_temp" to "Temperature", "c_battery" to "Battery", "c_power" to "Power",
        "c_network" to "Connection", "c_wifi" to "Wi-Fi", "c_cell" to "Cellular",
        "c_ifaces" to "Network Interfaces",
        "st_title" to "Settings",
        "st_appearance" to "Appearance", "st_dark" to "Dark Mode",
        "st_lang" to "Language", "st_refresh" to "Refresh Rate",
        "st_refresh_hint" to "How often live values update",
        "st_about" to "About",
        "st_about_body" to "PhoneInfo v2.1\nModern device diagnostics tool.\n\nThermal monitor, CPU/GPU stress tests, sensor data and much more.",
        "first_lang_title" to "Dil seçin / Choose language",
        "st_cpu" to "CPU", "st_gpu" to "GPU", "st_bat" to "Battery",
        "st_now" to "Now", "st_min" to "Min", "st_max" to "Max",
        "st_zones" to "All thermal zones",
        "st_none" to "No thermal sensor found.",
        "st_stress_cpu" to "CPU Stress Test", "st_stress_gpu" to "GPU Stress Test",
        "st_stress_both" to "Combined Stress Test", "st_stress_stop" to "Stop",
        "st_stress_dur" to "Duration (seconds)", "st_stress_start" to "Start",
        "st_stress_idle" to "Ready. Start a test.",
        "st_stress_running" to "Running…", "st_stress_done" to "Test complete",
        "st_stress_threads" to "Threads", "st_stress_elapsed" to "Elapsed",
        "st_stress_peak" to "Peak temperatures",
        "tools_vib" to "📳 Vibrate", "tools_torch" to "🔦 Torch", "tools_beep" to "🔊 Beep",
        "tools_color" to "🖥 Dead Pixel", "tools_touch" to "👆 Multi-touch",
        "tools_cpubench" to "⚡ CPU Benchmark", "tools_disk" to "💾 Storage Speed",
        "tools_settings" to "⚙ System Settings", "tools_copy" to "📋 Copy Report",
        "tools_share" to "📤 Share Report", "tools_brightness" to "Brightness"
    )
    fun get(lang: String, k: String): String = (if (lang == "en") en else tr)[k] ?: k
}

// ──────────────────────────────────────────────────────────────
//  MainActivity
// ──────────────────────────────────────────────────────────────
@Suppress("DEPRECATION", "MissingPermission", "HardwareIds", "NewApi")
class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private var lang = "tr"
    private var dark = true
    private var refreshMs = 500L
    private lateinit var pal: Palette

    private lateinit var sm: SensorManager
    private lateinit var content: LinearLayout
    private lateinit var tabRow: LinearLayout
    private val tabViews = linkedMapOf<String, TextView>()

    private var current = ""
    private val liveUpdaters = mutableListOf<() -> Unit>()
    private val ticker = Handler(Looper.getMainLooper())
    private var ticking = false

    private var torch = false
    private val liveVals = LinkedHashMap<String, String>()
    private var lastUi = 0L

    private var stressRunning = false
    private val stressThreads = mutableListOf<Thread>()
    private var stressStart = 0L
    private var stressMode = ""
    private var stressStatus: TextView? = null
    private var stressGpuDialog: Dialog? = null

    private fun s(k: String) = L.get(lang, k)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ──────────────────────────────────────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("phoneinfo", MODE_PRIVATE)
        lang = prefs.getString("lang", "") ?: ""
        dark = prefs.getBoolean("dark", true)
        refreshMs = prefs.getLong("refresh", 500L)
        pal = palette(dark)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        if (lang.isEmpty()) askLanguageFirst() else buildUi()
    }

    override fun onPause() { super.onPause(); stopTicker(); sm.unregisterListener(this) }
    override fun onResume() { super.onResume(); startTicker(); if (current == "live") startLiveSensors() }

    private fun askLanguageFirst() {
        AlertDialog.Builder(this)
            .setTitle("Dil seçin / Choose language")
            .setCancelable(false)
            .setItems(arrayOf("Türkçe", "English")) { _, i ->
                lang = if (i == 0) "tr" else "en"
                prefs.edit().putString("lang", lang).apply()
                buildUi()
            }.show()
    }

    // ──────────────────────────────────────────────────────────
    //  UI iskeleti
    // ──────────────────────────────────────────────────────────
    private fun buildUi() {
        pal = palette(dark)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        // Gradient header
        root.addView(buildHeader())

        // Sekmeler
        tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        })

        // İçerik
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(40))
        }
        root.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 23) {
            val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= 31) p.add("android.permission.BLUETOOTH_CONNECT")
            requestPermissions(p.toTypedArray(), 1)
        }

        buildTabs()
        selectTab("device")
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                pal.accent, pal.accent2
            )).apply {
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat())
            }
            setPadding(dp(22), dp(50), dp(22), dp(22))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = "🔍"; textSize = 34f
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(TextView(this).apply {
            text = "PhoneInfo"; textSize = 22f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        col.addView(TextView(this).apply {
            text = s("subtitle"); textSize = 12f
            setTextColor(0xCCFFFFFF.toInt())
        })
        row.addView(col)
        row.addView(TextView(this).apply {
            text = "⚙"; textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { selectTab("settings") }
        })
        h.addView(row)
        return h
    }

    private fun buildTabs() {
        val tabs = listOf(
            "device" to "⚙ " + s("tab_device"),
            "display" to "🖥 " + s("tab_display"),
            "cpu" to "⚡ " + s("tab_cpu"),
            "battery" to "🔋 " + s("tab_battery"),
            "net" to "📶 " + s("tab_net"),
            "sensors" to "📡 " + s("tab_sensors"),
            "camera" to "📷 " + s("tab_camera"),
            "features" to "✨ " + s("tab_features"),
            "apps" to "📱 " + s("tab_apps"),
            "codecs" to "🎬 " + s("tab_codecs"),
            "security" to "🔒 " + s("tab_security"),
            "thermal" to "🌡 " + s("tab_thermal"),
            "live" to "📊 " + s("tab_live"),
            "stress" to "🔥 " + s("tab_stress"),
            "tools" to "🧪 " + s("tab_tools")
        )
        tabViews.clear()
        tabRow.removeAllViews()
        tabs.forEach { (key, label) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setTextColor(pal.text)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = chipBg(false)
                setOnClickListener { selectTab(key) }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }
            }
            tabViews[key] = tv
            tabRow.addView(tv)
        }
    }

    private fun chipBg(selected: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(24).toFloat()
        setColor(if (selected) pal.accent else pal.card)
        setStroke(dp(1), if (selected) pal.accent else pal.stroke)
    }

    private fun selectTab(key: String) {
        current = key
        liveUpdaters.clear()
        tabViews.forEach { (k, v) ->
            val sel = k == key
            v.background = chipBg(sel)
            v.setTextColor(if (sel) Color.WHITE else pal.text)
        }
        content.removeAllViews()
        if (key != "live") sm.unregisterListener(this)
        when (key) {
            "device" -> renderDevice()
            "display" -> renderDisplay()
            "cpu" -> renderCpu()
            "battery" -> renderBattery()
            "net" -> renderNetwork()
            "sensors" -> renderSensors()
            "camera" -> renderCamera()
            "features" -> renderFeatures()
            "apps" -> renderApps()
            "codecs" -> renderCodecs()
            "security" -> renderSecurity()
            "thermal" -> renderThermal()
            "live" -> renderLive()
            "stress" -> renderStress()
            "tools" -> renderTools()
            "settings" -> renderSettings()
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        selectTab(current)
    }

    // ──────────────────────────────────────────────────────────
    //  Ticker (canlı güncelleme)
    // ──────────────────────────────────────────────────────────
    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!ticking) return
            for (f in liveUpdaters.toList()) runCatching { f() }
            ticker.postDelayed(this, refreshMs)
        }
    }
    private fun startTicker() { if (!ticking) { ticking = true; ticker.post(tickRunnable) } }
    private fun stopTicker() { ticking = false; ticker.removeCallbacks(tickRunnable) }

    // ──────────────────────────────────────────────────────────
    //  Kart yapıcıları
    // ──────────────────────────────────────────────────────────
    private fun makeCard(title: String, emoji: String = ""): Card {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(pal.card)
                setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (emoji.isNotEmpty()) {
            titleRow.addView(TextView(this).apply {
                text = emoji; textSize = 18f
                setPadding(0, 0, dp(10), 0)
            })
        }
        val titleTv = TextView(this).apply {
            text = title; textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(pal.text)
        }
        titleRow.addView(titleTv)
        card.addView(titleRow)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        card.addView(body)
        content.addView(card)
        return Card(body)
    }

    inner class Card(val body: LinearLayout) {
        fun row(k: String, v: String, color: Int? = null): Card {
            val r = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            r.addView(TextView(this@MainActivity).apply {
                text = k; textSize = 13f
                setTextColor(pal.sub)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            r.addView(TextView(this@MainActivity).apply {
                text = v; textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(color ?: pal.text)
            })
            body.addView(r)
            return this
        }
        fun rowLive(k: String, initial: String): Pair<TextView, Card> {
            val r = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(7), 0, dp(7))
            }
            r.addView(TextView(this@MainActivity).apply {
                text = k; textSize = 13f
                setTextColor(pal.sub)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            val tv = TextView(this@MainActivity).apply {
                text = initial; textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(pal.text)
            }
            r.addView(tv)
            body.addView(r)
            return tv to this
        }
        fun text(t: String): Card {
            body.addView(TextView(this@MainActivity).apply {
                text = t
                textSize = 11.5f
                typeface = Typeface.MONOSPACE
                setTextColor(pal.text)
                setTextIsSelectable(true)
            })
            return this
        }
        fun custom(f: (LinearLayout) -> Unit): Card { f(body); return this }
    }

    private fun statCard(parent: LinearLayout, label: String, initial: String, accent: Int): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(pal.card2)
                setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginEnd = dp(6); marginStart = dp(6)
                bottomMargin = dp(10)
            }
        }
        card.addView(TextView(this).apply {
            text = label; textSize = 11f
            setTextColor(pal.sub)
            setTypeface(null, Typeface.BOLD)
        })
        val tv = TextView(this).apply {
            text = initial; textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(accent)
            setPadding(0, dp(6), 0, 0)
        }
        card.addView(tv)
        parent.addView(card)
        return tv
    }

    private fun statRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(4); bottomMargin = dp(4)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Cihaz
    // ──────────────────────────────────────────────────────────
    private fun renderDevice() {
        val c1 = makeCard(s("c_identity"), "📱")
        c1.row("Üretici", Build.MANUFACTURER)
            .row("Marka", Build.BRAND)
            .row("Model", Build.MODEL)
            .row("Cihaz kodu", Build.DEVICE)
            .row("Ürün", Build.PRODUCT)
            .row("Kart", Build.BOARD)
            .row("Donanım", Build.HARDWARE)
        if (Build.VERSION.SDK_INT >= 31) {
            c1.row("SoC", Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL)
        }
        c1.row("Android ID", (Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "-").take(16) + "…")

        val c2 = makeCard(s("c_software"), "🤖")
        c2.row("Android", Build.VERSION.RELEASE)
            .row("API", Build.VERSION.SDK_INT.toString())
            .row("Güvenlik yaması", Build.VERSION.SECURITY_PATCH)
            .row("Build ID", Build.ID)
            .row("Fingerprint", Build.FINGERPRINT.take(24) + "…")
            .row("Bootloader", Build.BOOTLOADER)
            .row("Çekirdek", System.getProperty("os.version") ?: "-")
            .row("ABI", Build.SUPPORTED_ABIS.joinToString(", "))

        val c3 = makeCard(s("c_time"), "⏱")
        c3.row("Dil", Locale.getDefault().toString())
            .row("Saat dilimi", TimeZone.getDefault().id)
            .row("Açık kalma", dur(SystemClock.elapsedRealtime()))
            .row("Şu an", java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ekran
    // ──────────────────────────────────────────────────────────
    private fun renderDisplay() {
        val d = windowManager.defaultDisplay
        val dm = DisplayMetrics(); d.getRealMetrics(dm)
        val ap = resources.displayMetrics
        val diag = sqrt(((dm.widthPixels / dm.xdpi).toDouble().let { it * it }) + ((dm.heightPixels / dm.ydpi).toDouble().let { it * it }))

        val c1 = makeCard(s("c_resolution"), "🖥")
        c1.row("Gerçek", "${dm.widthPixels} × ${dm.heightPixels}")
            .row("Uygulama", "${ap.widthPixels} × ${ap.heightPixels}")
            .row("Yoğunluk", "${dm.densityDpi} dpi")
            .row("xdpi / ydpi", "%.1f / %.1f".format(dm.xdpi, dm.ydpi))
            .row("Ekran boyutu", "%.2f inç".format(diag))
            .row("Font ölçeği", resources.configuration.fontScale.toString())
            .row("Geniş renk gamı", if (resources.configuration.isScreenWideColorGamut) "✓" else "✗")
            .row("HDR", if (resources.configuration.isScreenHdr) "✓" else "✗")

        val c2 = makeCard(s("c_refresh"), "🔄")
        val (refTv, _) = c2.rowLive("Anlık", "%.0f Hz".format(d.refreshRate))
        d.supportedModes.forEach { m ->
            c2.row("Mod ${m.modeId}", "${m.physicalWidth}×${m.physicalHeight} @ %.1f Hz".format(m.refreshRate))
        }
        liveUpdaters.add {
            val r = windowManager.defaultDisplay.refreshRate
            refTv.text = "%.0f Hz".format(r)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: CPU (canlı kart bazlı)
    // ──────────────────────────────────────────────────────────
    private fun renderCpu() {
        val n = Runtime.getRuntime().availableProcessors()

        // CPU kart
        val cCpu = makeCard(s("c_cpu"), "⚡")
        cCpu.row("Çekirdek", n.toString())
            .row("Mimari", System.getProperty("os.arch") ?: "-")
            .row("Online", rd("/sys/devices/system/cpu/online") ?: "-")
        val cpuRows = mutableListOf<Pair<Int, TextView>>()
        for (i in 0 until n) {
            val (tv, _) = cCpu.rowLive("CPU$i", "…")
            cpuRows.add(i to tv)
        }

        // RAM kart
        val cRam = makeCard(s("c_ram"), "💾")
        val (ramUsedTv, _) = cRam.rowLive("Kullanılan", "…")
        val (ramFreeTv, _) = cRam.rowLive("Boş", "…")
        val (ramPctTv, _) = cRam.rowLive("Doluluk", "…")
        val (heapTv, _) = cRam.rowLive("Heap", "…")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        cRam.row("Toplam", fmt((ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }).totalMem))
        cRam.row("Düşük RAM cihazı", if (am.isLowRamDevice) "✓" else "✗")
        heapTv.text = "${am.memoryClass} MB"

        // Depolama kart
        val cSt = makeCard(s("c_storage"), "📦")
        val dataPath = Environment.getDataDirectory().path
        val extPath = Environment.getExternalStorageDirectory().path
        val (stDataTv, _) = cSt.rowLive("Dahili (kullanılan)", "…")
        val (stDataFree, _) = cSt.rowLive("Dahili (boş)", "…")
        val (stExtTv, _) = cSt.rowLive("Harici (boş)", "…")

        // Termal özet kart
        val cTemp = makeCard(s("c_temp"), "🌡")
        val (tCpuTv, _) = cTemp.rowLive(s("st_cpu"), "…")
        val (tGpuTv, _) = cTemp.rowLive(s("st_gpu"), "…")
        val (tBatTv, _) = cTemp.rowLive(s("st_bat"), "…")

        liveUpdaters.add {
            // CPU
            for ((i, tv) in cpuRows) {
                val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
                val cur = mhz(rd(b + "scaling_cur_freq"))
                val max = mhz(rd(b + "cpuinfo_max_freq"))
                val gov = rd(b + "scaling_governor") ?: ""
                tv.text = "$cur / $max  ($gov)"
            }
            // RAM
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            val used = mi.totalMem - mi.availMem
            val pct = used.toDouble() / mi.totalMem * 100
            ramUsedTv.text = fmt(used)
            ramFreeTv.text = fmt(mi.availMem)
            ramPctTv.text = "%.1f%%".format(pct)
            ramPctTv.setTextColor(when {
                pct < 70 -> pal.ok; pct < 88 -> pal.warn; else -> pal.danger
            })
            // Storage
            val s = android.os.StatFs(dataPath)
            val usedD = s.totalBytes - s.availableBytes
            stDataTv.text = fmt(usedD)
            stDataFree.text = fmt(s.availableBytes)
            val s2 = android.os.StatFs(extPath)
            stExtTv.text = fmt(s2.availableBytes)
            // Thermal
            val zones = readZones()
            val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                ?: zones.maxByOrNull { it.temp }?.temp
            val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
            val batT = batteryTemp()
            fun set(tv: TextView, t: Double?) {
                tv.text = t?.let { "%.1f °C".format(it) } ?: "—"
                tv.setTextColor(t?.let { tempColor(it) } ?: pal.sub)
            }
            set(tCpuTv, cpuT)
            set(tGpuTv, gpuT)
            set(tBatTv, batT)
        }
    }

    private fun tempColor(t: Double) = when {
        t < 45 -> pal.ok
        t < 60 -> 0xFFCDDC39.toInt()
        t < 75 -> pal.warn
        else -> pal.danger
    }

    private fun batteryTemp(): Double? = try {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i?.getIntExtra("temperature", 0)?.div(10.0)?.takeIf { it > 0.0 }
    } catch (e: Throwable) { null }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Pil
    // ──────────────────────────────────────────────────────────
    private fun renderBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val sc = i?.getIntExtra("scale", 100) ?: 100

        val c1 = makeCard(s("c_battery"), "🔋")
        val (lvlTv, _) = c1.rowLive("Seviye", "…")
        val (tempTv, _) = c1.rowLive("Sıcaklık", "…")
        val (voltTv, _) = c1.rowLive("Voltaj", "…")
        c1.row("Teknoloji", i?.getStringExtra("technology") ?: "-")

        val c2 = makeCard("Şarj / Akım", "⚡")
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val (curTv, _) = c2.rowLive("Anlık akım", "…")
        val (avgTv, _) = c2.rowLive("Ortalama akım", "…")
        val (counterTv, _) = c2.rowLive("Şarj sayacı", "…")
        c2.row("Durum", mapOf(2 to "Şarj oluyor", 3 to "Boşalıyor", 4 to "Şarj olmuyor", 5 to "Dolu")
            .getOrDefault(i?.getIntExtra("status", 1) ?: 1, "?"))
            .row("Sağlık", mapOf(2 to "İyi", 3 to "Aşırı ısınmış", 4 to "Ölü", 5 to "Aşırı voltaj", 6 to "Hata", 7 to "Soğuk")
                .getOrDefault(i?.getIntExtra("health", 1) ?: 1, "?"))

        val c3 = makeCard(s("c_power"), "🔌")
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        c3.row("Pil tasarrufu", if (pm.isPowerSaveMode) "AÇIK" else "kapalı")
            .row("Ekran", if (pm.isInteractive) "açık" else "kapalı")

        liveUpdaters.add {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return@add
            val lvl = b.getIntExtra("level", -1) * 100 / (b.getIntExtra("scale", 100))
            lvlTv.text = "$lvl%"
            lvlTv.setTextColor(when { lvl > 40 -> pal.ok; lvl > 15 -> pal.warn; else -> pal.danger })
            val t = b.getIntExtra("temperature", 0) / 10.0
            tempTv.text = "%.1f °C".format(t)
            tempTv.setTextColor(tempColor(t))
            voltTv.text = "${b.getIntExtra("voltage", 0)} mV"
            val c = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000
            curTv.text = "$c mA"
            avgTv.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) / 1000} mA"
            counterTv.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000} mAh"
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ağ
    // ──────────────────────────────────────────────────────────
    private fun renderNetwork() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork

        val c1 = makeCard(s("c_network"), "📶")
        if (n == null) c1.row("Durum", "Bağlantı yok")
        else {
            cm.getNetworkCapabilities(n)?.let { c ->
                val transports = listOf(
                    NetworkCapabilities.TRANSPORT_WIFI to "Wi-Fi",
                    NetworkCapabilities.TRANSPORT_CELLULAR to "Hücresel",
                    NetworkCapabilities.TRANSPORT_BLUETOOTH to "Bluetooth",
                    NetworkCapabilities.TRANSPORT_ETHERNET to "Ethernet",
                    NetworkCapabilities.TRANSPORT_VPN to "VPN"
                ).filter { c.hasTransport(it.first) }.joinToString { it.second }
                c1.row("Tür", transports)
                    .row("İndirme", "${c.linkDownstreamBandwidthKbps / 1000} Mbps")
                    .row("Yükleme", "${c.linkUpstreamBandwidthKbps / 1000} Mbps")
                    .row("İnternet", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) "✓" else "✗")
                    .row("Doğrulanmış", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "✓" else "✗")
                    .row("Sınırsız", if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) "✓" else "✗")
            }
            cm.getLinkProperties(n)?.let { lp ->
                c1.row("Arayüz", lp.interfaceName ?: "-")
                    .row("DNS", lp.dnsServers.joinToString { it.hostAddress ?: "" })
            }
        }

        val c2 = makeCard(s("c_wifi"), "📡")
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val wi = wm.connectionInfo
            c2.row("SSID", wi.ssid ?: "-")
                .row("BSSID", wi.bssid ?: "-")
                .row("Sinyal", "${wi.rssi} dBm")
                .row("Hız", "${wi.linkSpeed} Mbps")
                .row("Frekans", "${wi.frequency} MHz")
                .row("IP", ip(wi.ipAddress))
        } catch (e: Throwable) { c2.row("Hata", e.message ?: "?") }

        val c3 = makeCard(s("c_cell"), "📞")
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            c3.row("Operatör", tm.networkOperatorName ?: "-")
                .row("SIM", tm.simOperatorName ?: "-")
                .row("Ülke", tm.networkCountryIso ?: "-")
                .row("Roaming", if (tm.isNetworkRoaming) "✓" else "✗")
        } catch (e: Throwable) { c3.row("Hata", e.message ?: "?") }

        val c4 = makeCard(s("c_ifaces"), "🔌")
        NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
            val mac = ni.hardwareAddress?.joinToString(":") { "%02X".format(it) } ?: "-"
            c4.row(ni.name, "up=${if (ni.isUp) "✓" else "✗"}  mac=$mac")
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Sensörler
    // ──────────────────────────────────────────────────────────
    private fun renderSensors() {
        val list = sm.getSensorList(Sensor.TYPE_ALL)
        val c = makeCard("Sensörler (${list.size})", "📡")
        val sb = StringBuilder()
        list.forEach { s ->
            sb.append("• ${s.name}\n")
            sb.append("  ${s.stringType}\n")
            sb.append("  ${s.vendor} v${s.version}  ·  max ${s.maximumRange}  ·  ${s.power} mA\n\n")
        }
        c.text(sb.toString())
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Kamera
    // ──────────────────────────────────────────────────────────
    private fun renderCamera() {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        cm.cameraIdList.forEach { id ->
            val ch = cm.getCameraCharacteristics(id)
            val c = makeCard("Kamera $id", "📷")
            c.row("Yön", when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Ön"
                CameraCharacteristics.LENS_FACING_BACK -> "Arka"
                else -> "Harici"
            })
            c.row("Yönlendirme", "${ch.get(CameraCharacteristics.SENSOR_ORIENTATION)}°")
            c.row("Donanım seviyesi", mapOf(0 to "LIMITED", 1 to "FULL", 2 to "LEGACY", 3 to "LEVEL_3", 4 to "EXTERNAL")
                .get(ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) ?: "?")
            c.row("Odak uzaklığı", ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString() ?: "-")
            c.row("Diyafram", ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString() ?: "-")
            ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let {
                c.row("Çözünürlük", "${it.width}×${it.height} (%.1f MP)".format(it.width * it.height / 1e6))
            }
            c.row("Flaş", if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) "✓" else "✗")
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Özellikler / Uygulamalar / Kodek / Güvenlik
    // ──────────────────────────────────────────────────────────
    private fun renderFeatures() {
        val f = packageManager.systemAvailableFeatures.mapNotNull { it.name }.sorted()
        val c = makeCard("Özellikler (${f.size})", "✨")
        c.text(f.joinToString("\n"))
    }

    private fun renderApps() {
        val pk = packageManager.getInstalledPackages(0)
        fun sys(p: PackageInfo) = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
        val c1 = makeCard("Uygulama Özeti", "📱")
        c1.row("Toplam", pk.size.toString())
            .row("Sistem", pk.count { sys(it) }.toString())
            .row("Kullanıcı", pk.count { !sys(it) }.toString())
        val c2 = makeCard("Kullanıcı Uygulamaları", "👤")
        val sb = StringBuilder()
        pk.filter { !sys(it) }.sortedBy { it.packageName }.forEach {
            val name = it.applicationInfo?.let { a -> packageManager.getApplicationLabel(a) }
            sb.append("• $name\n  ${it.packageName}\n  v${it.versionName ?: "?"}\n\n")
        }
        c2.text(sb.toString())
    }

    private fun renderCodecs() {
        val c = makeCard("Medya Kodekleri", "🎬")
        val sb = StringBuilder()
        MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.sortedBy { it.name }.forEach { ci ->
            sb.append("${if (ci.isEncoder) "[ENC]" else "[DEC]"} ${ci.name}\n  ${ci.supportedTypes.joinToString()}\n\n")
        }
        c.text(sb.toString())

        val c2 = makeCard("Widevine DRM", "🔐")
        try {
            val md = MediaDrm(UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"))
            listOf("vendor", "version", "description", "securityLevel").forEach {
                c2.row(it, md.getPropertyString(it) ?: "-")
            }
            md.release()
        } catch (e: Throwable) { c2.row("Hata", e.message ?: "?") }

        val c3 = makeCard("Ses", "🔊")
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        c3.row("Örnekleme", am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) ?: "-")
            .row("Tampon", am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER) ?: "-")
            .row("Medya ses", "${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}")
    }

    private fun renderSecurity() {
        val c = makeCard("Güvenlik", "🔒")
        val roots = listOf("/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su","/data/local/bin/su").filter { File(it).exists() }
        c.row("Root izi", if (roots.isEmpty()) "Yok" else "VAR!", if (roots.isEmpty()) pal.ok else pal.danger)
            .row("Test-keys", if (Build.TAGS?.contains("test-keys") == true) "EVET" else "hayır")
            .row("Emülatör", if (Build.FINGERPRINT.contains("generic")) "Evet" else "Hayır")
            .row("Ekran kilidi", if ((getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure) "Var" else "Yok")
            .row("USB hata ayıklama", if (Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1) "AÇIK" else "kapalı")
            .row("Geliştirici seçenekleri", if (Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1) "AÇIK" else "kapalı")
            .row("SELinux", sh("getenforce"))
            .row("Verified boot", sh("getprop ro.boot.verifiedbootstate"))
            .row("Şifreleme", sh("getprop ro.crypto.state"))
            .row("ro.debuggable", sh("getprop ro.debuggable"))
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Termal (canlı, çok hızlı)
    // ──────────────────────────────────────────────────────────
    private fun renderThermal() {
        val peak = HashMap<String, Double>()
        val low = HashMap<String, Double>()

        // Büyük stat kartları
        val statRow1 = statRow()
        val cpuTv = statCard(statRow1, s("st_cpu"), "—", pal.danger)
        val gpuTv = statCard(statRow1, s("st_gpu"), "—", pal.warn)
        val batTv = statCard(statRow1, s("st_bat"), "—", pal.ok)
        content.addView(statRow1)

        // Zone kartı
        val cZones = makeCard(s("st_zones"), "📊")
        var zoneViews = mutableListOf<Triple<String, TextView, TextView>>()
        var lastZones = ""

        liveUpdaters.add {
            val zones = readZones()
            val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                ?: zones.maxByOrNull { it.temp }?.temp
            val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
            val batT = batteryTemp()
            listOf("cpu" to cpuT, "gpu" to gpuT, "bat" to batT).forEach { (k, v) ->
                if (v != null) {
                    peak[k] = max(peak[k] ?: v, v)
                    low[k] = min(low[k] ?: v, v)
                }
            }
            fun up(tv: TextView, t: Double?, k: String) {
                if (t == null) { tv.text = "—"; return }
                tv.text = "%.1f°".format(t)
                tv.setTextColor(tempColor(t))
            }
            up(cpuTv, cpuT, "cpu"); up(gpuTv, gpuT, "gpu"); up(batTv, batT, "bat")

            // Zone listesi (yapı değişirse yeniden oluştur)
            val sig = zones.joinToString { it.zone }
            if (sig != lastZones) {
                lastZones = sig
                cZones.body.removeAllViews()
                zoneViews.clear()
                zones.sortedByDescending { it.temp }.forEach { z ->
                    val r = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(0, dp(6), 0, dp(6))
                    }
                    val kTv = TextView(this@MainActivity).apply {
                        text = "${z.zone}  (${z.type.take(18)})"
                        textSize = 12f; setTextColor(pal.sub)
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    }
                    val vTv = TextView(this@MainActivity).apply {
                        text = "%.1f °C".format(z.temp)
                        textSize = 13f; setTypeface(null, Typeface.BOLD)
                        setTextColor(tempColor(z.temp))
                    }
                    r.addView(kTv); r.addView(vTv)
                    cZones.body.addView(r)
                    zoneViews.add(Triple(z.zone, kTv, vTv))
                }
            } else {
                // Sadece sıcaklık değerlerini güncelle
                zones.sortedByDescending { it.temp }.forEachIndexed { idx, z ->
                    zoneViews.getOrNull(idx)?.let { (_, _, vTv) ->
                        vTv.text = "%.1f °C".format(z.temp)
                        vTv.setTextColor(tempColor(z.temp))
                    }
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Canlı sensörler
    // ──────────────────────────────────────────────────────────
    private fun renderLive() {
        liveVals.clear()
        val c = makeCard(s("tab_live"), "📊")
        val tv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12.5f
            setTextColor(pal.text)
            setTextIsSelectable(true)
        }
        c.body.addView(tv)
        startLiveSensors()

        liveUpdaters.add {
            if (liveVals.isEmpty()) return@add
            tv.text = liveVals.entries.joinToString("\n\n") { "${it.key}\n   ${it.value}" }
        }
    }

    private fun startLiveSensors() {
        sm.unregisterListener(this)
        intArrayOf(
            Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY, Sensor.TYPE_PRESSURE,
            Sensor.TYPE_GRAVITY, Sensor.TYPE_AMBIENT_TEMPERATURE, Sensor.TYPE_RELATIVE_HUMIDITY,
            Sensor.TYPE_ROTATION_VECTOR
        ).forEach { t -> sm.getDefaultSensor(t)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        liveVals[e.sensor.stringType.substringAfterLast('.') + " • " + e.sensor.name] =
            e.values.joinToString("   ") { "%.3f".format(it) }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Yük Testi
    // ──────────────────────────────────────────────────────────
    private fun renderStress() {
        val c = makeCard(s("tab_stress"), "🔥")
        val durInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("60"); setTextColor(pal.text); setHint("60")
            setHintTextColor(pal.sub)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(pal.card2); setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val durRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        durRow.addView(TextView(this).apply {
            text = s("st_stress_dur"); setTextColor(pal.sub); textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        durRow.addView(durInput, LinearLayout.LayoutParams(dp(90), -2))
        c.body.addView(durRow)

        val statusTv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(pal.text)
            setPadding(0, dp(12), 0, 0)
        }
        stressStatus = statusTv
        statusTv.text = s("st_stress_idle")
        c.body.addView(statusTv)

        fun start(mode: String) {
            if (stressRunning) return
            val secs = (durInput.text.toString().toIntOrNull() ?: 60).coerceIn(5, 900)
            stressRunning = true; stressMode = mode
            stressStart = SystemClock.elapsedRealtime()
            val cores = Runtime.getRuntime().availableProcessors()
            val useGpu = mode == "gpu" || mode == "both"
            val useCpu = mode == "cpu" || mode == "both"

            val gpuDialog = if (useGpu) {
                Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
                    setContentView(GpuStressView(this@MainActivity))
                    window?.setLayout(dp(1), dp(1))
                    show()
                }
            } else null
            stressGpuDialog = gpuDialog

            if (useCpu) {
                for (i in 0 until cores) {
                    val t = Thread {
                        val rnd = Random(i)
                        var x = 1.0
                        val end = SystemClock.elapsedRealtime() + secs * 1000L
                        while (stressRunning && SystemClock.elapsedRealtime() < end) {
                            for (j in 0 until 50000) {
                                x = Math.sin(x * 1.0000001) * Math.cos(x * 0.9999999) + rnd.nextDouble() * 1e-7
                            }
                        }
                    }
                    t.start(); stressThreads.add(t)
                }
            }

            val updater = object : Runnable {
                override fun run() {
                    if (!stressRunning) return
                    val el = (SystemClock.elapsedRealtime() - stressStart) / 1000
                    val zones = readZones()
                    val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                        ?: zones.maxByOrNull { it.temp }?.temp
                    val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
                    val batT = batteryTemp()
                    val sb = StringBuilder()
                    sb.append("● ").append(s("st_stress_running")).append("  [").append(stressMode).append("]\n")
                    sb.append("⏱ ").append(s("st_stress_elapsed")).append(": ").append(el).append(" / ").append(secs).append(" s\n")
                    sb.append("⚙ ").append(s("st_stress_threads")).append(": ").append(if (useCpu) cores else 0).append("\n\n")
                    fun line(k: String, t: Double?) {
                        sb.append("%-10s %-12s\n".format(k, t?.let { "%.1f °C".format(it) } ?: "—"))
                    }
                    line(s("st_cpu"), cpuT); line(s("st_gpu"), gpuT); line(s("st_bat"), batT)
                    statusTv.text = sb.toString()

                    if (SystemClock.elapsedRealtime() - stressStart < secs * 1000L) {
                        ticker.postDelayed(this, refreshMs)
                    } else {
                        stressRunning = false
                        stressThreads.forEach { runCatching { it.interrupt() } }
                        stressThreads.clear()
                        stressGpuDialog?.dismiss()
                        val sb2 = StringBuilder(sb)
                        sb2.append("\n━━ ").append(s("st_stress_done")).append(" ━━\n")
                        sb2.append(s("st_stress_peak")).append(":\n")
                        sb2.append("  CPU: ").append(cpuT?.let { "%.1f °C".format(it) } ?: "—").append("\n")
                        sb2.append("  GPU: ").append(gpuT?.let { "%.1f °C".format(it) } ?: "—").append("\n")
                        sb2.append("  BAT: ").append(batT?.let { "%.1f °C".format(it) } ?: "—")
                        statusTv.text = sb2.toString()
                    }
                }
            }
            ticker.post(updater)
        }

        c.body.addView(styledBtn(s("st_stress_cpu"), pal.accent) { start("cpu") })
        c.body.addView(styledBtn(s("st_stress_gpu"), pal.accent2) { start("gpu") })
        c.body.addView(styledBtn(s("st_stress_both"), pal.danger) { start("both") })
        c.body.addView(styledBtn(s("st_stress_stop"), pal.sub) {
            stressRunning = false
            stressThreads.forEach { runCatching { it.interrupt() } }
            stressThreads.clear()
            stressGpuDialog?.dismiss()
        })
    }

    private fun styledBtn(label: String, color: Int, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(color)
            }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(6); bottomMargin = dp(6)
            }
        }
    }

    private class GpuStressView(ctx: Context) : GLSurfaceView(ctx), GLSurfaceView.Renderer {
        private var prog = 0
        private var tLoc = 0
        private var startT = 0L
        private val verts: FloatBuffer = ByteBuffer.allocateDirect(4 * 2 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(floatArrayOf(-1f,-1f, 3f,-1f, -1f,3f)); position(0) }

        init {
            setEGLContextClientVersion(2)
            setRenderer(this)
            renderMode = RENDERMODE_CONTINUOUSLY
            startT = SystemClock.elapsedRealtime()
        }
        override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
            val vs = "attribute vec2 p; void main(){ gl_Position=vec4(p,0.0,1.0); }"
            val fs = """
                precision highp float;
                uniform float uTime;
                void main(){
                    vec2 q = gl_FragCoord.xy * 0.01;
                    float a = 0.0;
                    for (int i=0;i<300;i++){
                        float fi = float(i);
                        a += sin(q.x*fi*0.01 + uTime) * cos(q.y*fi*0.013 - uTime);
                        a += sqrt(abs(sin(fi) + 1.0)) * 0.001;
                    }
                    gl_FragColor = vec4(abs(a)*0.01, 0.15, 0.25, 1.0);
                }
            """.trimIndent()
            val v = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER).also {
                GLES20.glShaderSource(it, vs); GLES20.glCompileShader(it)
            }
            val f = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER).also {
                GLES20.glShaderSource(it, fs); GLES20.glCompileShader(it)
            }
            prog = GLES20.glCreateProgram().also {
                GLES20.glAttachShader(it, v); GLES20.glAttachShader(it, f); GLES20.glLinkProgram(it)
            }
            tLoc = GLES20.glGetUniformLocation(prog, "uTime")
        }
        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { GLES20.glViewport(0,0,w,h) }
        override fun onDrawFrame(gl: GL10?) {
            GLES20.glUseProgram(prog)
            val a = GLES20.glGetAttribLocation(prog, "p")
            GLES20.glEnableVertexAttribArray(a)
            GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, verts)
            GLES20.glUniform1f(tLoc, (SystemClock.elapsedRealtime() - startT) / 1000f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            GLES20.glDisableVertexAttribArray(a)
        }
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Araçlar
    // ──────────────────────────────────────────────────────────
    private fun renderTools() {
        val c = makeCard(s("tab_tools"), "🧪")
        c.body.addView(styledBtn(s("tools_vib"), pal.accent) { vibrate() })
        c.body.addView(styledBtn(s("tools_torch"), pal.accent) { toggleTorch() })
        c.body.addView(styledBtn(s("tools_beep"), pal.accent) {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 400)
        })
        c.body.addView(styledBtn(s("tools_color"), pal.accent2) { colorTest() })
        c.body.addView(styledBtn(s("tools_touch"), pal.accent2) { touchTest() })
        c.body.addView(styledBtn(s("tools_cpubench"), pal.warn) { cpuBench() })
        c.body.addView(styledBtn(s("tools_disk"), pal.warn) { diskBench() })
        c.body.addView(styledBtn(s("tools_settings"), pal.sub) { settingsMenu() })
        c.body.addView(styledBtn(s("tools_copy"), pal.ok) {
            val r = fullReport()
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", r))
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show()
        })
        c.body.addView(styledBtn(s("tools_share"), pal.ok) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, fullReport().take(200000)), "Share"))
        })

        val c2 = makeCard(s("tools_brightness"), "💡")
        c2.body.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    val lp = window.attributes
                    lp.screenBrightness = max(p, 1) / 100f
                    window.attributes = lp
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0,200,100,200,100,500), -1))
        else v.vibrate(500)
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return
            torch = !torch; cm.setTorchMode(id, torch)
        } catch (e: Throwable) { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() }
    }

    private fun colorTest() {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val cols = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.GRAY)
        var i = 0
        val v = View(this).apply {
            setBackgroundColor(cols[0])
            setOnClickListener { i++; if (i >= cols.size) dlg.dismiss() else setBackgroundColor(cols[i]) }
        }
        dlg.setContentView(v)
        dlg.window?.decorView?.systemUiVisibility =
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        dlg.show()
    }

    inner class TouchView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 44f }
        private val pts = HashMap<Int, PointF>()
        private var maxPts = 0
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) pts.clear()
            else { pts.clear(); for (i in 0 until e.pointerCount) pts[e.getPointerId(i)] = PointF(e.getX(i), e.getY(i)); maxPts = max(maxPts, e.pointerCount) }
            invalidate(); return true
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(Color.BLACK); p.color = Color.WHITE
            c.drawText("Now: ${pts.size}  Max: $maxPts", 20f, 90f, p)
            p.color = Color.CYAN
            pts.values.forEach { c.drawCircle(it.x, it.y, 90f, p) }
        }
    }
    private fun touchTest() {
        Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
            setContentView(TouchView(this@MainActivity)); show()
        }
    }

    private fun work(): Int { var c = 0; for (n in 2..600000) { var d = 2; var p = true; while (d*d <= n) { if (n % d == 0) { p = false; break }; d++ }; if (p) c++ }; return c }

    private fun cpuBench() {
        Toast.makeText(this, "…", Toast.LENGTH_SHORT).show()
        Thread {
            val t0 = System.nanoTime(); work(); val single = (System.nanoTime() - t0) / 1_000_000
            val n = Runtime.getRuntime().availableProcessors()
            val t1 = System.nanoTime()
            List(n) { Thread { work() }.also { it.start() } }.forEach { it.join() }
            val multi = (System.nanoTime() - t1) / 1_000_000
            runOnUiThread {
                Toast.makeText(this, "1C: $single ms\n${n}C: $multi ms\nx%.2f".format(single.toDouble()*n/multi), Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun diskBench() {
        Thread {
            try {
                val f = File(cacheDir, "bench.bin"); val buf = ByteArray(1 shl 20) { it.toByte() }; val mb = 64
                var t = System.nanoTime()
                java.io.FileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.fd.sync() }
                val w = mb / ((System.nanoTime() - t) / 1e9)
                t = System.nanoTime()
                java.io.FileInputStream(f).use { i -> while (i.read(buf) > 0) { } }
                val r = mb / ((System.nanoTime() - t) / 1e9)
                f.delete()
                runOnUiThread { Toast.makeText(this, "W: %.0f MB/s\nR: %.0f MB/s".format(w, r), Toast.LENGTH_LONG).show() }
            } catch (e: Throwable) { runOnUiThread { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun settingsMenu() {
        val items = listOf(
            "Device info" to Settings.ACTION_DEVICE_INFO_SETTINGS,
            "Developer options" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "Battery saver" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Wireless" to Settings.ACTION_WIRELESS_SETTINGS,
            "Display" to Settings.ACTION_DISPLAY_SETTINGS,
            "Storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
            "Apps" to Settings.ACTION_APPLICATION_SETTINGS
        )
        AlertDialog.Builder(this).setItems(items.map { it.first }.toTypedArray()) { _, w ->
            try { startActivity(Intent(items[w].second)) } catch (e: Throwable) {}
        }.show()
    }

    // ──────────────────────────────────────────────────────────
    //  RENDER: Ayarlar
    // ──────────────────────────────────────────────────────────
    private fun renderSettings() {
        // Görünüm
        val c1 = makeCard(s("st_appearance"), "🎨")
        val darkRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        darkRow.addView(TextView(this).apply {
            text = s("st_dark"); textSize = 14f
            setTextColor(pal.text)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        darkRow.addView(Switch(this).apply {
            isChecked = dark
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("dark", checked).apply()
                dark = checked
                recreate()
            }
        })
        c1.body.addView(darkRow)

        // Dil
        val c2 = makeCard(s("st_lang"), "🌐")
        val langRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
        }
        langRow.addView(styledBtn("Türkçe", if (lang == "tr") pal.accent else pal.card2) {
            prefs.edit().putString("lang", "tr").apply(); recreate()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        langRow.addView(styledBtn("English", if (lang == "en") pal.accent else pal.card2) {
            prefs.edit().putString("lang", "en").apply(); recreate()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        c2.body.addView(langRow)

        // Yenileme hızı
        val c3 = makeCard(s("st_refresh"), "⚡")
        val rt = TextView(this).apply {
            text = "%.1f sn".format(refreshMs / 1000.0)
            textSize = 18f; setTypeface(null, Typeface.BOLD)
            setTextColor(pal.accent)
            setPadding(0, dp(6), 0, dp(6))
        }
        c3.body.addView(rt)
        c3.body.addView(TextView(this).apply {
            text = s("st_refresh_hint"); textSize = 11f; setTextColor(pal.sub)
        })
        c3.body.addView(SeekBar(this).apply {
            max = 19
            progress = ((refreshMs - 100) / 100).toInt().coerceIn(0, 19)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    refreshMs = (100 + p * 100).toLong()
                    rt.text = "%.1f sn".format(refreshMs / 1000.0)
                    prefs.edit().putLong("refresh", refreshMs).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        // Hakkında
        val c4 = makeCard(s("st_about"), "ℹ")
        c4.body.addView(TextView(this).apply {
            text = s("st_about_body")
            textSize = 13f; setTextColor(pal.sub)
            setLineSpacing(dp(4).toFloat(), 1f)
        })
    }

    // ──────────────────────────────────────────────────────────
    //  Rapor
    // ──────────────────────────────────────────────────────────
    private fun fullReport(): String {
        val sb = StringBuilder()
        sb.append("════ PhoneInfo v2.1 Raporu ════\n")
        sb.append("Tarih: ").append(Date()).append("\n\n")
        sb.append("── Kimlik ──\n")
        sb.append("${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")
        sb.append("── Termal ──\n")
        readZones().sortedByDescending { it.temp }.forEach {
            sb.append("%-24s %.1f °C\n".format(it.type.take(24), it.temp))
        }
        sb.append("\n── CPU ──\n")
        val n = Runtime.getRuntime().availableProcessors()
        sb.append("Çekirdek: $n\n")
        for (i in 0 until n) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            sb.append("CPU$i: ${mhz(rd(b + "scaling_cur_freq"))}\n")
        }
        sb.append("\n── RAM ──\n")
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        sb.append("Toplam: ${fmt(mi.totalMem)}\nBoş: ${fmt(mi.availMem)}\n")
        return sb.toString()
    }
}