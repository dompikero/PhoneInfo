package com.eren.phoneinfo

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.*
import android.graphics.*
import android.hardware.*
import android.hardware.camera2.*
import android.media.*
import android.net.*
import android.net.wifi.WifiManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.*
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import java.io.File
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.*
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.random.Random

// ────────────────────────────── yardımcılar ──────────────────────────────
private fun StringBuilder.h(t: String) { append("\n━━ ").append(t).append(" ━━\n") }
private fun StringBuilder.kv(k: String, v: Any?) { append(k).append(": ").append(v ?: "-").append('\n') }
private inline fun StringBuilder.tr(f: () -> Unit) { try { f() } catch (e: Throwable) { append("[!] ${e.javaClass.simpleName}: ${e.message}\n") } }
private inline fun safe(f: StringBuilder.() -> Unit): String { val sb = StringBuilder(); sb.tr { sb.f() }; return sb.toString() }
private fun rd(p: String): String? = try { File(p).readText().trim() } catch (e: Throwable) { null }
private fun sh(c: String): String = try { Runtime.getRuntime().exec(arrayOf("sh", "-c", c)).inputStream.bufferedReader().readText().trim() } catch (e: Throwable) { "" }
private fun mhz(s: String?) = s?.toLongOrNull()?.let { "${it / 1000} MHz" } ?: "-"
private fun ip(i: Int) = "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
private fun fmt(b: Long): String { val u = arrayOf("B","KB","MB","GB","TB"); var v = b.toDouble(); var i = 0; while (v >= 1024 && i < 4) { v /= 1024; i++ }; return "%.2f %s".format(v, u[i]) }
private fun dur(ms: Long): String { val s = ms / 1000; return "${s/86400}g ${s/3600%24}s ${s/60%60}dk ${s%60}sn" }

// ────────────────────────────── termal ──────────────────────────────
data class Tz(val zone: String, val type: String, val temp: Double)

private fun readZones(): List<Tz> {
    val list = mutableListOf<Tz>()
    File("/sys/class/thermal").listFiles()?.forEach { f ->
        if (!f.name.startsWith("thermal_zone")) return@forEach
        val type = rd(f.path + "/type") ?: f.name
        val raw = rd(f.path + "/temp")?.toDoubleOrNull() ?: return@forEach
        val t = if (Math.abs(raw) > 200) raw / 1000.0 else raw
        list.add(Tz(f.name, type, t))
    }
    return list
}

private fun zoneKind(z: Tz): String {
    val t = z.type.lowercase()
    return when {
        t.contains("gpu") || t.contains("g3d") || t.contains("kgsl") || t.contains("mali") || t.contains("adreno") -> "gpu"
        t.contains("batt") || t.contains("bms") -> "bat"
        t.contains("cpu") || t.contains("soc") || t.contains("ap") || t.contains("tsens") ||
            t.contains("core") || t.contains("cluster") || t.contains("big") || t.contains("little") -> "cpu"
        else -> "other"
    }
}

private fun extraGpuTemp(): Double? {
    val paths = listOf(
        "/sys/class/kgsl/kgsl-3d0/temp",
        "/sys/class/kgsl/kgsl-3d0/devfreq/temp",
        "/sys/class/misc/mali0/device/temp",
        "/sys/kernel/gpu/gpu_temp",
        "/sys/devices/virtual/thermal/thermal_zone0/temp"
    )
    for (p in paths) {
        val v = rd(p)?.toDoubleOrNull() ?: continue
        return if (Math.abs(v) > 200) v / 1000.0 else v
    }
    return null
}

// ────────────────────────────── dil ──────────────────────────────
object L {
    private val tr = mapOf(
        "app" to "🔍 PhoneInfo",
        "tab_device" to "Cihaz", "tab_display" to "Ekran", "tab_cpu" to "CPU/RAM/Depo",
        "tab_battery" to "Pil", "tab_net" to "Ağ", "tab_sensors" to "Sensörler",
        "tab_camera" to "Kamera", "tab_features" to "Özellikler", "tab_apps" to "Uygulamalar",
        "tab_codecs" to "Kodek/Ses", "tab_security" to "Güvenlik", "tab_props" to "getprop",
        "tab_env" to "Java/Ortam", "tab_live" to "📡 Canlı", "tab_thermal" to "🌡 Isı",
        "tab_stress" to "🔥 Yük Testi", "tab_tools" to "🧪 Araçlar", "tab_settings" to "⚙ Ayarlar",
        "st_title" to "Ayarlar", "st_lang" to "Dil", "st_lang_tr" to "Türkçe", "st_lang_en" to "İngilizce",
        "st_about" to "Hakkında", "st_about_body" to "PhoneInfo v2.0\nCihaz bilgisi, termal izleme ve stres testi aracı.",
        "st_reset_hint" to "Dil değişince uygulama yeniden başlatılır.",
        "first_lang_title" to "Dil / Language seçin",
        "th_cpu" to "İşlemci (CPU)", "th_gpu" to "Grafik (GPU)", "th_bat" to "Pil",
        "th_max" to "En yüksek", "th_min" to "En düşük", "th_now" to "Şu an", "th_zones" to "Tüm termal bölgeler",
        "th_none" to "Termal sensör bulunamadı veya erişim yok.",
        "st_stress_cpu" to "CPU yük testi", "st_stress_gpu" to "GPU yük testi",
        "st_stress_both" to "Birleşik yük testi", "st_stress_stop" to "Durdur",
        "st_stress_dur" to "Süre (saniye)", "st_stress_start" to "Başlat",
        "st_stress_idle" to "Hazır. Bir test seçin.",
        "st_stress_running" to "Çalışıyor…", "st_stress_done" to "Test tamamlandı",
        "st_stress_threads" to "İş parçacığı", "st_stress_elapsed" to "Geçen süre",
        "st_stress_report" to "Rapor", "st_stress_peak" to "Zirve sıcaklıklar",
        "tools_copy" to "📋 Tüm raporu kopyala", "tools_share" to "📤 Raporu paylaş",
        "tools_vib" to "📳 Titreşim", "tools_torch" to "🔦 Fener", "tools_beep" to "🔊 Bip",
        "tools_color" to "🖥 Ölü piksel testi", "tools_touch" to "👆 Çoklu dokunma",
        "tools_cpubench" to "⚡ CPU benchmark", "tools_disk" to "💾 Depo hız testi",
        "tools_settings" to "⚙ Ayar kısayolları", "tools_brightness" to "Parlaklık"
    )
    private val en = mapOf(
        "app" to "🔍 PhoneInfo",
        "tab_device" to "Device", "tab_display" to "Display", "tab_cpu" to "CPU/RAM/Storage",
        "tab_battery" to "Battery", "tab_net" to "Network", "tab_sensors" to "Sensors",
        "tab_camera" to "Camera", "tab_features" to "Features", "tab_apps" to "Apps",
        "tab_codecs" to "Codecs/Audio", "tab_security" to "Security", "tab_props" to "getprop",
        "tab_env" to "Java/Env", "tab_live" to "📡 Live", "tab_thermal" to "🌡 Thermal",
        "tab_stress" to "🔥 Stress Test", "tab_tools" to "🧪 Tools", "tab_settings" to "⚙ Settings",
        "st_title" to "Settings", "st_lang" to "Language", "st_lang_tr" to "Turkish", "st_lang_en" to "English",
        "st_about" to "About", "st_about_body" to "PhoneInfo v2.0\nDevice info, thermal monitor and stress test tool.",
        "st_reset_hint" to "App will restart when language changes.",
        "first_lang_title" to "Choose language / Dil seçin",
        "th_cpu" to "CPU", "th_gpu" to "GPU", "th_bat" to "Battery",
        "th_max" to "Max", "th_min" to "Min", "th_now" to "Now", "th_zones" to "All thermal zones",
        "th_none" to "No thermal sensor found or access denied.",
        "st_stress_cpu" to "CPU stress test", "st_stress_gpu" to "GPU stress test",
        "st_stress_both" to "Combined stress test", "st_stress_stop" to "Stop",
        "st_stress_dur" to "Duration (seconds)", "st_stress_start" to "Start",
        "st_stress_idle" to "Ready. Choose a test.",
        "st_stress_running" to "Running…", "st_stress_done" to "Test complete",
        "st_stress_threads" to "Threads", "st_stress_elapsed" to "Elapsed",
        "st_stress_report" to "Report", "st_stress_peak" to "Peak temperatures",
        "tools_copy" to "📋 Copy full report", "tools_share" to "📤 Share report",
        "tools_vib" to "📳 Vibrate", "tools_torch" to "🔦 Torch", "tools_beep" to "🔊 Beep",
        "tools_color" to "🖥 Dead pixel test", "tools_touch" to "👆 Multi-touch",
        "tools_cpubench" to "⚡ CPU benchmark", "tools_disk" to "💾 Storage speed",
        "tools_settings" to "⚙ Settings shortcuts", "tools_brightness" to "Brightness"
    )
    fun get(lang: String, k: String): String = (if (lang == "en") en else tr)[k] ?: k
}

// ────────────────────────────── MainActivity ──────────────────────────────
@Suppress("DEPRECATION", "MissingPermission", "HardwareIds", "NewApi")
class MainActivity : Activity(), SensorEventListener {

    private lateinit var out: TextView
    private lateinit var tools: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var tabBar: LinearLayout
    private lateinit var rootView: LinearLayout
    private lateinit var sm: SensorManager
    private lateinit var prefs: SharedPreferences

    private var lang = "tr"
    private var current = "Cihaz"
    private var torch = false
    private var lastUi = 0L
    private val liveVals = LinkedHashMap<String, String>()

    // termal izleme
    private val ui = Handler(Looper.getMainLooper())
    private var thermalRunning = false
    private val peaks = HashMap<String, Double>()
    private val mins  = HashMap<String, Double>()

    // yük testi
    private var stressRunning = false
    private var stressThreads = mutableListOf<Thread>()
    private var stressStart = 0L
    private var stressMode = ""
    private var stressTv: TextView? = null

    private fun s(k: String) = L.get(lang, k)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false
        setBackgroundColor(0xFF1E2530.toInt())
        setTextColor(0xFFE6F1FF.toInt())
        setOnClickListener { f() }
    }

    private fun tabBtn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 12f
        setPadding(dp(12), dp(6), dp(12), dp(6))
        setBackgroundColor(0xFF161B22.toInt())
        setTextColor(0xFFB3E5FC.toInt())
        setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("phoneinfo", MODE_PRIVATE)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        lang = prefs.getString("lang", "") ?: ""
        if (lang.isEmpty()) askLanguageFirst() else initUi()
    }

    private fun askLanguageFirst() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(s("first_lang_title"))
            .setCancelable(false)
            .setItems(arrayOf("Türkçe", "English")) { _, i ->
                lang = if (i == 0) "tr" else "en"
                prefs.edit().putString("lang", lang).apply()
                initUi()
            }.show()
    }

    private fun initUi() {
        val cats = linkedMapOf(
            s("tab_device") to { device() }, s("tab_display") to { display() },
            s("tab_cpu") to { cpu() }, s("tab_battery") to { battery() },
            s("tab_net") to { net() }, s("tab_sensors") to { sensors() },
            s("tab_camera") to { camera() }, s("tab_features") to { features() },
            s("tab_apps") to { apps() }, s("tab_codecs") to { codecs() },
            s("tab_security") to { security() }, s("tab_props") to { props() },
            s("tab_env") to { env() }, s("tab_live") to { "…" },
            s("tab_thermal") to { "" }, s("tab_stress") to { "" },
            s("tab_tools") to { "" }, s("tab_settings") to { "" }
        )
        current = s("tab_device")

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0E1116.toInt())
        }

        // Başlık
        val title = TextView(this).apply {
            text = s("app"); textSize = 20f; setTextColor(Color.WHITE)
            setPadding(dp(16), dp(36), dp(16), dp(6))
        }
        rootView.addView(title)

        // Sekmeler
        tabBar = LinearLayout(this)
        cats.keys.forEach { k -> tabBar.addView(tabBtn(k) { show(k, cats) }) }
        rootView.addView(HorizontalScrollView(this).apply { addView(tabBar) })

        // Araç çubuğu (yalnızca Tools sekmesinde)
        tools = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8), 0, dp(8), 0)
        }
        buildTools()

        out = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11.5f
            setTextColor(0xFFCFE8CF.toInt()); setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(40))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tools); addView(out)
        }
        scroll = ScrollView(this).apply { addView(col) }
        rootView.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(rootView)

        if (Build.VERSION.SDK_INT >= 23) {
            val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= 31) p.add("android.permission.BLUETOOTH_CONNECT")
            requestPermissions(p.toTypedArray(), 1)
        }
        show(current, cats)
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (current != s("tab_tools")) show(current, null)
    }
    override fun onPause() { super.onPause(); stopLive(); stopThermal() }
    override fun onResume() { super.onResume(); if (current == s("tab_live")) startLive(); if (current == s("tab_thermal")) startThermal() }

    private fun show(name: String, cats: Map<String, () -> String>?) {
        if (name != s("tab_live")) stopLive()
        if (name != s("tab_thermal")) stopThermal()

        current = name
        tools.visibility = if (name == s("tab_tools")) View.VISIBLE else View.GONE
        tabBar.children().forEach { v ->
            if (v is Button) v.setBackgroundColor(if (v.text == name) 0xFF2A3442.toInt() else 0xFF161B22.toInt())
        }

        when (name) {
            s("tab_thermal") -> renderThermal()
            s("tab_stress")  -> renderStress(null)
            s("tab_settings")-> renderSettings()
            s("tab_tools")   -> { out.text = ""; startThermal() }
            else -> {
                val body = cats?.get(name)?.invoke() ?: ""
                out.text = body
            }
        }
        scroll.scrollTo(0, 0)
    }

    private fun ViewGroup.children(): Sequence<View> = (0 until childCount).asSequence().map { getChildAt(it) }

    // ────────────────────────────── Canlı sensörler ──────────────────────────────
    private fun startLive() {
        liveVals.clear()
        intArrayOf(
            Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY, Sensor.TYPE_PRESSURE,
            Sensor.TYPE_GRAVITY, Sensor.TYPE_AMBIENT_TEMPERATURE, Sensor.TYPE_RELATIVE_HUMIDITY,
            Sensor.TYPE_ROTATION_VECTOR
        ).forEach { t -> sm.getDefaultSensor(t)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    }
    private fun stopLive() = sm.unregisterListener(this)
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        liveVals[e.sensor.stringType.substringAfterLast('.') + " • " + e.sensor.name] =
            e.values.joinToString("   ") { "%.3f".format(it) }
        val n = SystemClock.elapsedRealtime(); if (n - lastUi < 120) return; lastUi = n
        if (current == s("tab_live")) out.text = liveVals.entries.joinToString("\n\n") { "${it.key}\n   ${it.value}" }
    }

    // ────────────────────────────── TERMAL izleme ──────────────────────────────
    private fun startThermal() {
        if (thermalRunning) return
        thermalRunning = true
        peaks.clear(); mins.clear()
        ui.post(thermalTick)
    }
    private fun stopThermal() { thermalRunning = false; ui.removeCallbacks(thermalTick) }

    private val thermalTick = object : Runnable {
        override fun run() {
            if (!thermalRunning) return
            val zones = readZones()
            val cpu = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                ?: zones.maxByOrNull { it.temp }?.temp
            val gpu = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
            val bat = batteryTemp()
            listOf("cpu" to cpu, "gpu" to gpu, "bat" to bat).forEach { (k, v) ->
                if (v != null) {
                    peaks[k] = max(peaks[k] ?: v, v)
                    mins[k] = kotlin.math.min(mins[k] ?: v, v)
                }
            }
            if (current == s("tab_thermal") || current == s("tab_stress")) {
                // yük testi sırasında st stress ekranını güncelliyoruz
                if (current == s("tab_thermal")) out.text = thermalReport()
            }
            ui.postDelayed(this, 1000)
        }
    }

    private fun batteryTemp(): Double? = try {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i?.getIntExtra("temperature", 0)?.div(10.0)?.takeIf { it > 0.0 }
    } catch (e: Throwable) { null }

    private fun tempColor(t: Double): Int = when {
        t < 45 -> 0xFF4CAF50.toInt()
        t < 60 -> 0xFFCDDC39.toInt()
        t < 75 -> 0xFFFF9800.toInt()
        else -> 0xFFF44336.toInt()
    }

    private fun tempCard(label: String, t: Double?, max: Double?, min: Double?): String {
        val c = t?.let { tempColor(it) } ?: 0xFF888888.toInt()
        return "▌ %-14s %-8s   min %-6s  max %-6s".format(
            label,
            t?.let { "%.1f °C".format(it) } ?: "--",
            min?.let { "%.1f".format(it) } ?: "--",
            max?.let { "%.1f".format(it) } ?: "--"
        ) + "\n"
    }

    private fun thermalReport(): String {
        val zones = readZones()
        val cpu = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
            ?: zones.maxByOrNull { it.temp }?.temp
        val gpu = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
        val bat = batteryTemp()
        val sb = StringBuilder()
        sb.h(s("tab_thermal"))
        sb.append(tempCard(s("th_cpu"), cpu, peaks["cpu"], mins["cpu"]))
        sb.append(tempCard(s("th_gpu"), gpu, peaks["gpu"], mins["gpu"]))
        sb.append(tempCard(s("th_bat"), bat, peaks["bat"], mins["bat"]))
        sb.h(s("th_zones"))
        if (zones.isEmpty()) sb.append(s("th_none")).append('\n')
        else zones.sortedByDescending { it.temp }.forEach { z ->
            sb.append("%-22s %-24s %.1f °C\n".format(z.zone, z.type.take(24), z.temp))
        }
        return sb.toString()
    }

    private fun renderThermal() {
        out.text = thermalReport()
        startThermal()
    }

    // ────────────────────────────── YÜK TESTİ ──────────────────────────────
    private fun renderStress(msg: String?) {
        stressTv?.let { /* mevcut görünümü tekrar kur */ }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }

        val durInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("60"); setTextColor(Color.WHITE); setHint("60")
        }
        val durRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(TextView(this@MainActivity).apply { text = s("st_stress_dur") + "  "; setTextColor(Color.WHITE) })
            addView(durInput, LinearLayout.LayoutParams(dp(90), -2))
        }
        col.addView(durRow)

        val statusTv = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(0xFFCFE8CF.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        stressTv = statusTv

        fun start(mode: String) {
            if (stressRunning) return
            val secs = (durInput.text.toString().toIntOrNull() ?: 60).coerceIn(5, 900)
            stressRunning = true; stressMode = mode
            stressStart = SystemClock.elapsedRealtime()
            peaks.clear(); mins.clear()
            statusTv.text = s("st_stress_running")

            val cores = Runtime.getRuntime().availableProcessors()
            val useGpu = mode == "gpu" || mode == "both"
            val useCpu = mode == "cpu" || mode == "both"

            // GPU için ek dialog aç
            var gpuDialog: Dialog? = null
            if (useGpu) {
                gpuDialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
                    val gv = GpuStressView(this@MainActivity)
                    setContentView(gv)
                    window?.setLayout(dp(1), dp(1)) // görünmez ama render ediyor
                    show()
                }
            }

            // CPU iş parçacıkları
            if (useCpu) {
                for (i in 0 until cores) {
                    val t = Thread {
                        val rnd = Random(i)
                        var x = 1.0
                        val end = SystemClock.elapsedRealtime() + secs * 1000L
                        while (stressRunning && SystemClock.elapsedRealtime() < end) {
                            for (j in 0 until 50000) {
                                x = Math.sin(x * 1.0000001) * Math.cos(x * 0.9999999) + rnd.nextDouble() * 0.0000001
                            }
                        }
                    }
                    t.start(); stressThreads.add(t)
                }
            }

            // UI güncelleyici
            val updater = object : Runnable {
                override fun run() {
                    if (!stressRunning) return
                    val el = (SystemClock.elapsedRealtime() - stressStart) / 1000
                    val zones = readZones()
                    val cpuT = zones.filter { zoneKind(it) == "cpu" }.maxByOrNull { it.temp }?.temp
                        ?: zones.maxByOrNull { it.temp }?.temp
                    val gpuT = zones.filter { zoneKind(it) == "gpu" }.maxByOrNull { it.temp }?.temp ?: extraGpuTemp()
                    val batT = batteryTemp()
                    listOf("cpu" to cpuT, "gpu" to gpuT, "bat" to batT).forEach { (k, v) ->
                        if (v != null) {
                            peaks[k] = max(peaks[k] ?: v, v)
                            mins[k] = kotlin.math.min(mins[k] ?: v, v)
                        }
                    }
                    val sb = StringBuilder()
                    sb.append(s("st_stress_running")).append("  [").append(stressMode).append("]\n")
                    sb.append(s("st_stress_elapsed")).append(": ").append(el).append(" / ").append(secs).append(" s\n")
                    sb.append(s("st_stress_threads")).append(": ").append(if (useCpu) cores else 0).append("\n\n")
                    sb.append(tempCard(s("th_cpu"), cpuT, peaks["cpu"], mins["cpu"]))
                    sb.append(tempCard(s("th_gpu"), gpuT, peaks["gpu"], mins["gpu"]))
                    sb.append(tempCard(s("th_bat"), batT, peaks["bat"], mins["bat"]))
                    statusTv.text = sb.toString()

                    if (SystemClock.elapsedRealtime() - stressStart < secs * 1000L) {
                        ui.postDelayed(this, 1000)
                    } else {
                        stressRunning = false
                        stressThreads.forEach { runCatching { it.interrupt() } }
                        stressThreads.clear()
                        gpuDialog?.dismiss()
                        statusTv.text = statusTv.text.toString() +
                            "\n\n━━ " + s("st_stress_done") + " ━━\n" +
                            s("st_stress_peak") + ":\n" +
                            "  CPU: " + (peaks["cpu"]?.let { "%.1f °C".format(it) } ?: "--") + "\n" +
                            "  GPU: " + (peaks["gpu"]?.let { "%.1f °C".format(it) } ?: "--") + "\n" +
                            "  BAT: " + (peaks["bat"]?.let { "%.1f °C".format(it) } ?: "--")
                    }
                }
            }
            ui.post(updater)
        }

        col.addView(btn(s("st_stress_cpu")) { start("cpu") })
        col.addView(btn(s("st_stress_gpu")) { start("gpu") })
        col.addView(btn(s("st_stress_both")) { start("both") })
        col.addView(btn(s("st_stress_stop")) {
            stressRunning = false
            stressThreads.forEach { runCatching { it.interrupt() } }
            stressThreads.clear()
        })

        col.addView(TextView(this).apply { text = "\n" })
        col.addView(statusTv)
        statusTv.text = msg ?: s("st_stress_idle")

        // out'u gizleyip col'u göster
        out.visibility = View.GONE
        (out.parent as LinearLayout).addView(col)
        // yeniden çizen bir referans
        rootView.post { }
    }

    // GPU stress için GLSurfaceView
    private class GpuStressView(ctx: Context) : GLSurfaceView(ctx), GLSurfaceView.Renderer {
        private var prog = 0
        private var tLoc = 0
        private var startT = 0L
        private val verts: FloatBuffer = ByteBuffer.allocateDirect(4 * 2 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(floatArrayOf(-1f,-1f, 3f,-1f, -1f,3f)); position(0) }

        init {
            setEGLContextClientVersion(2)
            setRenderer(this)
            renderMode = RENDERMODE_CONTINUOUSLY
            startT = SystemClock.elapsedRealtime()
        }

        override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
            val vs = """
                attribute vec2 p; void main(){ gl_Position=vec4(p,0.0,1.0); }
            """.trimIndent()
            val fs = """
                precision highp float;
                uniform float uTime;
                void main(){
                    vec2 q = gl_FragCoord.xy * 0.01;
                    float a = 0.0;
                    for (int i=0;i<250;i++){
                        float fi = float(i);
                        a += sin(q.x*fi*0.01 + uTime) * cos(q.y*fi*0.013 - uTime);
                        a += sqrt(abs(sin(fi) + 1.0)) * 0.001;
                    }
                    gl_FragColor = vec4(abs(a)*0.01, 0.15, 0.25, 1.0);
                }
            """.trimIndent()
            val v = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER).also {
                GLES20.glShaderSource(it, vs); GLES20.glCompileShader(it)
            }
            val f = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER).also {
                GLES20.glShaderSource(it, fs); GLES20.glCompileShader(it)
            }
            prog = GLES20.glCreateProgram().also {
                GLES20.glAttachShader(it, v); GLES20.glAttachShader(it, f); GLES20.glLinkProgram(it)
            }
            tLoc = GLES20.glGetUniformLocation(prog, "uTime")
        }
        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { GLES20.glViewport(0,0,w,h) }
        override fun onDrawFrame(gl: GL10?) {
            GLES20.glUseProgram(prog)
            val a = GLES20.glGetAttribLocation(prog, "p")
            GLES20.glEnableVertexAttribArray(a)
            GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, verts)
            GLES20.glUniform1f(tLoc, (SystemClock.elapsedRealtime() - startT) / 1000f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            GLES20.glDisableVertexAttribArray(a)
        }
    }

    // ────────────────────────────── AYARLAR ──────────────────────────────
    private fun renderSettings() {
        out.visibility = View.VISIBLE
        val sb = StringBuilder()
        sb.h(s("st_title"))
        sb.append(s("st_lang")).append(": ").append(if (lang == "tr") s("st_lang_tr") else s("st_lang_en")).append("\n\n")
        out.text = sb.toString()

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn(s("st_lang_tr")) {
            prefs.edit().putString("lang", "tr").apply(); recreate()
        })
        row.addView(btn(s("st_lang_en")) {
            prefs.edit().putString("lang", "en").apply(); recreate()
        })
        (out.parent as LinearLayout).addView(row)
        out.append("\n" + s("st_reset_hint") + "\n")
        out.append("\n" + s("st_about_body") + "\n")
    }

    // ────────────────────────────── Araçlar ──────────────────────────────
    private fun buildTools() {
        fun add(t: String, f: () -> Unit) = tools.addView(btn(t, f))
        add(s("tools_vib")) { vibrate() }
        add(s("tools_torch")) { toggleTorch() }
        add(s("tools_beep")) { ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 400) }
        add(s("tools_color")) { colorTest() }
        add(s("tools_touch")) { touchTest() }
        add(s("tools_cpubench")) { cpuBench() }
        add(s("tools_disk")) { diskBench() }
        add(s("tools_settings")) { settingsMenu() }
        add(s("tools_copy")) {
            val r = fullReport()
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", r))
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show()
        }
        add(s("tools_share")) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, fullReport().take(200000)), "Share"))
        }
        tools.addView(TextView(this).apply { text = s("tools_brightness"); setTextColor(Color.WHITE) })
        tools.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                    val lp = window.attributes; lp.screenBrightness = max(p, 1) / 100f; window.attributes = lp
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
    }

    private fun fullReport(): String {
        val parts = listOf(
            s("tab_device") to device(), s("tab_display") to display(), s("tab_cpu") to cpu(),
            s("tab_battery") to battery(), s("tab_net") to net(), s("tab_sensors") to sensors(),
            s("tab_camera") to camera(), s("tab_features") to features(), s("tab_apps") to apps(),
            s("tab_codecs") to codecs(), s("tab_security") to security(), s("tab_env") to env(),
            s("tab_thermal") to thermalReport()
        )
        return parts.joinToString("\n\n") { "######## ${it.first} ########\n${it.second}" }
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0,200,100,200,100,500), -1))
        else v.vibrate(500)
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return
            torch = !torch; cm.setTorchMode(id, torch)
        } catch (e: Throwable) { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() }
    }

    private fun colorTest() {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val cols = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.GRAY)
        var i = 0
        val v = View(this).apply {
            setBackgroundColor(cols[0])
            setOnClickListener { i++; if (i >= cols.size) dlg.dismiss() else setBackgroundColor(cols[i]) }
        }
        dlg.setContentView(v)
        dlg.window?.decorView?.systemUiVisibility =
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        dlg.show()
    }

    inner class TouchView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 44f }
        private val pts = HashMap<Int, PointF>()
        private var maxPts = 0
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) pts.clear()
            else { pts.clear(); for (i in 0 until e.pointerCount) pts[e.getPointerId(i)] = PointF(e.getX(i), e.getY(i)); maxPts = max(maxPts, e.pointerCount) }
            invalidate(); return true
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(Color.BLACK); p.color = Color.WHITE
            c.drawText("Now: ${pts.size}   Max: $maxPts", 20f, 90f, p)
            p.color = Color.CYAN; pts.values.forEach { c.drawCircle(it.x, it.y, 90f, p) }
        }
    }
    private fun touchTest() {
        Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
            setContentView(TouchView(this@MainActivity)); show()
        }
    }

    private fun work(): Int { var c = 0; for (n in 2..600000) { var d = 2; var p = true; while (d*d <= n) { if (n % d == 0) { p = false; break }; d++ }; if (p) c++ }; return c }

    private fun cpuBench() {
        Toast.makeText(this, "…", Toast.LENGTH_SHORT).show()
        Thread {
            val t0 = System.nanoTime(); work(); val single = (System.nanoTime() - t0) / 1_000_000
            val n = Runtime.getRuntime().availableProcessors()
            val t1 = System.nanoTime()
            List(n) { Thread { work() }.also { it.start() } }.forEach { it.join() }
            val multi = (System.nanoTime() - t1) / 1_000_000
            ui.post {
                Toast.makeText(this,
                    "1C: $single ms\n${n}C: $multi ms\nx${"%.2f".format(single.toDouble()*n/multi)}",
                    Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun diskBench() {
        Thread {
            try {
                val f = File(cacheDir, "bench.bin"); val buf = ByteArray(1 shl 20) { it.toByte() }; val mb = 64
                var t = System.nanoTime()
                java.io.FileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.fd.sync() }
                val w = mb / ((System.nanoTime() - t) / 1e9)
                t = System.nanoTime()
                java.io.FileInputStream(f).use { i -> while (i.read(buf) > 0) { } }
                val r = mb / ((System.nanoTime() - t) / 1e9)
                f.delete()
                ui.post { Toast.makeText(this, "W: %.0f MB/s\nR: %.0f MB/s".format(w, r), Toast.LENGTH_LONG).show() }
            } catch (e: Throwable) { ui.post { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun settingsMenu() {
        val items = listOf(
            "Device info" to Settings.ACTION_DEVICE_INFO_SETTINGS,
            "Developer options" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "Battery saver" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Wireless" to Settings.ACTION_WIRELESS_SETTINGS,
            "Display" to Settings.ACTION_DISPLAY_SETTINGS,
            "Storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
            "Apps" to Settings.ACTION_APPLICATION_SETTINGS
        )
        AlertDialog.Builder(this).setItems(items.map { it.first }.toTypedArray()) { _, w ->
            try { startActivity(Intent(items[w].second)) } catch (e: Throwable) {}
        }.show()
    }

    // ────────────────────────────── Bilgi sayfaları ──────────────────────────────
    private fun device() = safe {
        h("Identity"); kv("Manufacturer", Build.MANUFACTURER); kv("Brand", Build.BRAND); kv("Model", Build.MODEL)
        kv("Device", Build.DEVICE); kv("Product", Build.PRODUCT); kv("Board", Build.BOARD); kv("Hardware", Build.HARDWARE)
        if (Build.VERSION.SDK_INT >= 31) { kv("SoC vendor", Build.SOC_MANUFACTURER); kv("SoC model", Build.SOC_MODEL) }
        kv("Android ID", Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID))
        kv("Device name", Settings.Global.getString(contentResolver, "device_name"))
        h("Software"); kv("Android", Build.VERSION.RELEASE); kv("API", Build.VERSION.SDK_INT)
        kv("Security patch", Build.VERSION.SECURITY_PATCH); kv("Codename", Build.VERSION.CODENAME)
        kv("Incremental", Build.VERSION.INCREMENTAL); kv("Build ID", Build.ID); kv("Display", Build.DISPLAY)
        kv("Type", Build.TYPE); kv("Tags", Build.TAGS); kv("Fingerprint", Build.FINGERPRINT)
        kv("Bootloader", Build.BOOTLOADER); kv("Radio", Build.getRadioVersion()); kv("Build time", Date(Build.TIME))
        kv("Kernel", System.getProperty("os.version")); kv("/proc/version", rd("/proc/version"))
        kv("ABIs", Build.SUPPORTED_ABIS.joinToString()); kv("64-bit ABIs", Build.SUPPORTED_64_BIT_ABIS.joinToString())
        h("Time / Locale"); kv("Locale", Locale.getDefault()); kv("TimeZone", TimeZone.getDefault().id)
        kv("Uptime", dur(SystemClock.elapsedRealtime())); kv("Now", Date())
    }

    private fun display() = safe {
        val d = windowManager.defaultDisplay
        val dm = DisplayMetrics(); d.getRealMetrics(dm)
        val ap = resources.displayMetrics
        h("Resolution"); kv("Real", "${dm.widthPixels} x ${dm.heightPixels}"); kv("App area", "${ap.widthPixels} x ${ap.heightPixels}")
        kv("Density", "${dm.densityDpi} dpi (x${dm.density})"); kv("xdpi/ydpi", "${dm.xdpi}/${dm.ydpi}")
        kv("Font scale", resources.configuration.fontScale); kv("Rotation", d.rotation)
        kv("Wide gamut", resources.configuration.isScreenWideColorGamut); kv("HDR", resources.configuration.isScreenHdr)
        h("Refresh"); kv("Current", "${d.refreshRate} Hz")
        d.supportedModes.forEach { m -> kv("Mode ${m.modeId}", "${m.physicalWidth}x${m.physicalHeight} @ ${"%.1f".format(m.refreshRate)} Hz") }
    }

    private fun cpu() = safe {
        h("CPU"); val n = Runtime.getRuntime().availableProcessors()
        kv("Cores", n); kv("Online", rd("/sys/devices/system/cpu/online")); kv("Arch", System.getProperty("os.arch"))
        for (i in 0 until n) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            kv("CPU$i", "${mhz(rd(b + "scaling_cur_freq"))} (min ${mhz(rd(b + "cpuinfo_min_freq"))} / max ${mhz(rd(b + "cpuinfo_max_freq"))})")
        }
        h("RAM"); val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        kv("Total", fmt(mi.totalMem)); kv("Free", fmt(mi.availMem)); kv("Low mem", mi.lowMemory)
        kv("Heap", "${am.memoryClass} MB / large ${am.largeMemoryClass} MB")
        h("Storage")
        for ((ad, p) in listOf("Data" to Environment.getDataDirectory().path, "External" to Environment.getExternalStorageDirectory().path))
            tr { val st = StatFs(p); kv(ad, "${fmt(st.availableBytes)} free / ${fmt(st.totalBytes)}") }
        h("Thermal zones"); readZones().forEach { kv(it.type, "%.1f °C".format(it.temp)) }
    }

    private fun battery() = safe {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))!!
        val sc = i.getIntExtra("scale", 100)
        h("Battery"); kv("Level", "%${i.getIntExtra("level", -1) * 100 / sc}")
        kv("Status", mapOf(2 to "Charging", 3 to "Discharging", 4 to "Not charging", 5 to "Full").getOrDefault(i.getIntExtra("status", 1), "?"))
        kv("Health", mapOf(2 to "Good", 3 to "Overheat", 4 to "Dead", 5 to "Over voltage", 6 to "Failure", 7 to "Cold").getOrDefault(i.getIntExtra("health", 1), "?"))
        kv("Voltage", "${i.getIntExtra("voltage", 0)} mV"); kv("Temperature", "${i.getIntExtra("temperature", 0) / 10.0} °C")
        kv("Technology", i.getStringExtra("technology"))
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        kv("Charge counter", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000} mAh")
        kv("Current now", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000} mA")
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        h("Power"); kv("Save mode", pm.isPowerSaveMode); kv("Interactive", pm.isInteractive)
    }

    private fun net() = safe {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        h("Active"); if (n == null) kv("State", "none") else {
            cm.getNetworkCapabilities(n)?.let { c ->
                kv("Transports", listOf(
                    NetworkCapabilities.TRANSPORT_WIFI to "Wi-Fi", NetworkCapabilities.TRANSPORT_CELLULAR to "Cellular",
                    NetworkCapabilities.TRANSPORT_BLUETOOTH to "BT", NetworkCapabilities.TRANSPORT_ETHERNET to "Eth",
                    NetworkCapabilities.TRANSPORT_VPN to "VPN").filter { c.hasTransport(it.first) }.joinToString { it.second })
                kv("Internet", c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                kv("Validated", c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
            }
        }
        h("Wi-Fi"); tr {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val wi = wm.connectionInfo
            kv("SSID", wi.ssid); kv("BSSID", wi.bssid); kv("RSSI", "${wi.rssi} dBm")
            kv("Speed", "${wi.linkSpeed} Mbps"); kv("Freq", "${wi.frequency} MHz"); kv("IP", ip(wi.ipAddress))
        }
        h("Telephony"); tr {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            kv("Operator", tm.networkOperatorName); kv("SIM", tm.simOperatorName); kv("Country", tm.networkCountryIso)
            kv("Roaming", tm.isNetworkRoaming)
        }
        h("Interfaces"); NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
            kv(ni.name, "up=${ni.isUp} mtu=${ni.mtu} mac=${ni.hardwareAddress?.joinToString(":") { "%02X".format(it) }}")
        }
    }

    private fun sensors() = safe {
        val l = sm.getSensorList(Sensor.TYPE_ALL); append("Total: ${l.size}\n")
        l.forEach { s ->
            append("\n• ${s.name}\n  type=${s.stringType} vendor=${s.vendor} v${s.version}\n")
            append("  range=${s.maximumRange} res=${s.resolution} power=${s.power}mA delay=${s.minDelay}µs\n")
        }
    }

    private fun camera() = safe {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        kv("IDs", cm.cameraIdList.joinToString())
        cm.cameraIdList.forEach { id ->
            val c = cm.getCameraCharacteristics(id); h("Camera $id")
            kv("Facing", when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Front"; CameraCharacteristics.LENS_FACING_BACK -> "Back"; else -> "External" })
            kv("Orientation", c.get(CameraCharacteristics.SENSOR_ORIENTATION))
            kv("HW level", mapOf(0 to "LIMITED", 1 to "FULL", 2 to "LEGACY", 3 to "LEVEL_3", 4 to "EXTERNAL")
                .get(c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)))
            kv("Focal", c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString())
            kv("Aperture", c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString())
            kv("Sensor", c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let { "${it.width}x${it.height}" })
        }
    }

    private fun features() = safe {
        val f = packageManager.systemAvailableFeatures.mapNotNull { it.name }.sorted()
        h("Features (${f.size})"); f.forEach { append(it).append('\n') }
    }

    private fun apps() = safe {
        val pk = packageManager.getInstalledPackages(0)
        fun sys(p: PackageInfo) = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
        kv("Total", pk.size); kv("System", pk.count { sys(it) }); kv("User", pk.count { !sys(it) })
        h("User apps")
        pk.filter { !sys(it) }.sortedBy { it.packageName }.forEach {
            append("${it.applicationInfo?.let { a -> packageManager.getApplicationLabel(a) }} — ${it.packageName} v${it.versionName}\n")
        }
    }

    private fun codecs() = safe {
        h("MediaCodecs")
        MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.sortedBy { it.name }.forEach { c ->
            append("${if (c.isEncoder) "[ENC]" else "[DEC]"} ${c.name} ${c.supportedTypes.joinToString()}\n")
        }
        h("Widevine"); tr {
            val md = MediaDrm(UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"))
            listOf("vendor","version","description","securityLevel").forEach { kv(it, md.getPropertyString(it)) }
            md.release()
        }
        h("Audio"); val am = getSystemService(AUDIO_SERVICE) as AudioManager
        kv("Sample rate", am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE))
        kv("Frames/buffer", am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER))
    }

    private fun security() = safe {
        h("Security")
        kv("Root", listOf("/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su","/data/local/bin/su")
            .filter { File(it).exists() }.ifEmpty { listOf("no") })
        kv("Test-keys", Build.TAGS?.contains("test-keys"))
        kv("Emulator?", Build.FINGERPRINT.contains("generic"))
        kv("Secure lock", (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure)
        kv("ADB", Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0))
        kv("SELinux", sh("getenforce")); kv("Verified boot", sh("getprop ro.boot.verifiedbootstate"))
        kv("Encryption", sh("getprop ro.crypto.state")); kv("ro.debuggable", sh("getprop ro.debuggable"))
    }

    private fun props() = safe { append(sh("getprop").lines().sorted().joinToString("\n")) }

    private fun env() = safe {
        h("App"); kv("UID", android.os.Process.myUid()); kv("PID", android.os.Process.myPid())
        kv("filesDir", filesDir); kv("cacheDir", cacheDir)
        h("Java props"); System.getProperties().entries.sortedBy { it.key.toString() }.forEach { append("${it.key} = ${it.value}\n") }
        h("/proc/mounts"); append(rd("/proc/mounts")).append('\n')
    }
}